//
//  IOSChartStockDataDay5Line.h
//  Chart
//
//  Created by zhang hailong on 13-5-22.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <Chart/Chart.h>

@interface IOSChartStockDataDay5Line : IOSChartStockData

@property(nonatomic,retain) IBOutlet id source;

@end
