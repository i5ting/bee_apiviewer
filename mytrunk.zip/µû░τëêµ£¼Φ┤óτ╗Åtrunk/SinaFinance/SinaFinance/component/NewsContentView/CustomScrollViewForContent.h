//
//  CustomScrollViewForContent.h
//  SinaNewsHD
//
//  Created by du zhe on 10-10-31.
//  Copyright 2010 sina. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomScrollViewForContent : UIView {
	NSArray *images;
	UIScrollView *scrollView;
	UILabel *label;

}
@property (nonatomic, retain)NSArray *images;
@property (nonatomic, assign)UIScrollView *scrollView;
@property (nonatomic, assign)UILabel *label;

- (void)addLabelView;
@end
