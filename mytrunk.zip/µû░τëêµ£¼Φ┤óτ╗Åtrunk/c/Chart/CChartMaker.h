//
//  CChartMaker.h
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef CChart_CChartMaker_h
#define CChart_CChartMaker_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>
    
    typedef struct _CChartMarkeMemory {
        CChartString type;
        CChartUInteger length;
        void * data;
    } CChartMakerMemory;
    
    typedef struct _CChartMarker {
        CChartMakerMemory * memorys;
        CChartUInteger length;
        CChartUInteger size;
    } CChartMaker;
    
    void CChartMakerDelete(CChartMaker * const marker);
    
    void * CChartMakerCreate(CChartMaker * const marker,CChartString type,CChartUInteger length);

    CChartString CChartMakerCreateString(CChartMaker * const marker,CChartString string);
    
#define CChartMakerCreate(maker,type,count)    (type *)CChartMakerCreate((maker),#type,sizeof(type) * (count))
    
    
    
#ifdef __cplusplus
}
#endif

#endif
