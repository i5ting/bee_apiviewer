//
//  IOSChartLayer.h
//  IOSChart
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/EAGLDrawable.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import <QuartzCore/QuartzCore.h>

#include <Chart/CChart.h>
#include <Chart/IOSChart.h>

@interface IOSChartLayer : CAEAGLLayer

@property(nonatomic,readonly) CChartContext cContext;
@property(nonatomic,assign) CGFloat scale;
@property(nonatomic,retain) IOSChart * chart;

-(void) setNeedsRender;

-(void) tick;

@end
