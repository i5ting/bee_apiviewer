//
//  CChartStock.h
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef CChart_CChartStock_h
#define CChart_CChartStock_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>
#include <Chart/CChartData.h>
    
    
    struct _CChartStock;
    struct _CChartStockForm;
    struct _CChartStockFormItem;
    
    typedef struct _CChartStockLabel{
        CChartFloat fontSize;
        CChartColor color;
        CChartString text;
    } CChartStockLabel;

    typedef struct _CChartStockFormItem{
        CChart base;
        struct _CChartStockForm * form;
    } CChartStockFormItem;
    
    typedef struct _CChartStockFormItemLineValue{
        CChartFloat value;
    } CChartStockFormItemLineValue;
    
    typedef struct _CChartStockFormItemLine{
        CChartStockFormItem base;
        CChartFloat width;
        CChartColor color;
        CChartString dataKey;
        CChartStockFormItemLineValue * values;
    } CChartStockFormItemLine;
    
    typedef struct _CChartStockFormItemKLineValue{
        CChartFloat value;
        CChartFloat startValue;
        CChartFloat minValue;
        CChartFloat maxValue;
        CChartColor colorValue;
    } CChartStockFormItemKLineValue;
    
    typedef struct _CChartStockFormItemKLine{
        CChartStockFormItem base;
        CChartFloat width;
        CChartString dataKey;
        CChartStockFormItemKLineValue * values;
        CChartColor fallColor;
        CChartColor riseColor;
    } CChartStockFormItemKLine;
    
    typedef struct _CChartStockFormItemPillarValue{
        CChartFloat value;
        CChartColor colorValue;
    } CChartStockFormItemPillarValue;
    
    typedef struct _CChartStockFormItemPillar{
        CChartStockFormItem base;
        CChartFloat width;
        CChartString dataKey;
        CChartStockFormItemPillarValue * values;
        CChartColor fallColor;
        CChartColor riseColor;
    } CChartStockFormItemPillar;
    
    typedef union  _CChartStockFormItemUnion{
        CChart chart;
        CChartStockFormItem item;
        CChartStockFormItemLine line;
        CChartStockFormItemKLine kline;
        CChartStockFormItemPillar pillar;
    } CChartStockFormItemUnion;
    
    typedef struct _CChartStockFormItemList{
        CChartStockFormItemUnion * values;
        CChartUInteger length;
    } CChartStockFormItemList;
    
    
    typedef struct _CChartStockFormValue{
        CChartFloat xValue;
        CChartFloat yValue;
        CChartString xText;
        CChartString yText;
    } CChartStockFormValue;
    
    typedef struct _CChartStockFormTipValue{
        CChartFloat xValue;
        CChartFloat yValue;
        CChartFloat fontSize;
        CChartColor color;
        CChartString text;
        CChartColor lineColor;
    } CChartStockFormTipValue;
    
    typedef struct _CChartStockFormRow{
        CChartStockLabel leftLabel;
        CChartStockLabel rightLabel;
        CChartFloat value;
    } CChartStockFormRow;
    
    typedef struct _CChartStockFormColumn{
        CChartStockLabel label;
        CChartFloat value;
    } CChartStockFormColumn;
    
    typedef struct _CChartStockFormFocusValue {
        CChartPoint location;
        struct {
            CChartColor color;
            CChartFloat width;
        } xLine;
        struct {
            CChartColor color;
            CChartFloat width;
        } yLine;
        struct {
            CChartColor color;
            CChartFloat fontSize;
            CChartColor textColor;
        } xLabel;
        struct {
            CChartColor color;
            CChartFloat fontSize;
            CChartColor textColor;
        } yLabel;
    } CChartStockFormFocusValue;
    
    typedef struct _CChartStockForm{
        CChart base;
        struct _CChartStock * stock;
        CChartRelativeRect rect;
        CChartStockFormItemList items;
        CChartColor backgroundColor;
        CChartColor borderColor;
        CChartFloat borderWidth;
        CChartColor lineColor;
        CChartFloat lineWidth;
        
        CChartString dataKey;
        
        CChartFloat minXValue;
        CChartFloat minYValue;
        CChartFloat maxXValue;
        CChartFloat maxYValue;
        
        CChartStockFormValue * xValues;
        CChartUInteger length;
        
        CChartStockFormRow * rows;
        CChartUInteger rowCount;
        
        CChartStockFormColumn * columns;
        CChartUInteger columnCount;
        
        CChartColor fallColor;
        CChartColor riseColor;
        CChartColor curColor;
        CChartColor timeColor;
        CChartFloat fontSize;
        
        CChartStockFormTipValue minTipValue;
        CChartStockFormTipValue maxTipValue;
        
        CChartStockFormFocusValue focusValue;
        
    } CChartStockForm;
    
    typedef struct _CChartStockFormList{
        CChartStockForm * values;
        CChartUInteger length;
    } CChartStockFormList;
    
    typedef struct _CChartStockFocusValue{
        CChartPoint location;
    } CChartStockFocusValue;
    
    typedef struct _CChartStock{
        CChart base;
        CChartStockFormList forms;
        CChartStockFocusValue focusValue;
    } CChartStock;
    
    extern CChartClass CChartStockClass;
    
    extern CChartClass CChartStockFormClass;
    
    extern CChartClass CChartStockFormItemLineClass;
    
    extern CChartClass CChartStockFormItemKLineClass;
    
    extern CChartClass CChartStockFormItemPillarClass;
    
#ifdef __cplusplus
}
#endif

#endif
