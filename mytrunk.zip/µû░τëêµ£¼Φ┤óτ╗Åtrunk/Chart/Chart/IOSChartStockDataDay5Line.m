//
//  IOSChartStockDataDay5Line.m
//  Chart
//
//  Created by zhang hailong on 13-5-22.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartStockDataDay5Line.h"

@interface IOSChartStockDataDay5Line(){
    NSDateFormatter * _dateFormatter;
}

@end

@implementation IOSChartStockDataDay5Line

@synthesize source = _source;

-(id) init{
    if((self = [super init])){
        _dateFormatter = [[NSDateFormatter alloc] init];
    }
    return self;
}

-(void) dealloc{
    [_dateFormatter release];
    [_source release];
    [super dealloc];
}

-(CChartStockData *) cData{
    CChartStockData * data = [super cData];
    if(data->data == NULL){
        
        CChartStockDataProperty propertys[] = {
            {"price",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
            {"avg_price",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
            {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
        };
        
        CChartStockDataCreate(data, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
        
        struct {
            CChartStockDataProperty * price;
            CChartStockDataProperty * avg_price;
            CChartStockDataProperty * volume;
            CChartStockDataProperty * timestamp;
        } Propertys = {
            CChartStockDataGetProperty(data, "price"),
            CChartStockDataGetProperty(data, "avg_price"),
            CChartStockDataGetProperty(data, "volume"),
            CChartStockDataGetProperty(data, "timestamp"),
        };
        
        [_dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"];
        
        int size = 0;
        
        for(int i=0;i<5;i++){
            id items =  [self.source dataObjectForKey:[NSString stringWithFormat:@"@%d",i]];
            size += [items count];
        }
        
        CChartStockDataSetDataSize(data, size);
        
        int index = 0;
        CChartDateTime timestamp = CChartDateTimeEmpty;
        CChartStockDataItem dataItem;
        
        data->preValue = CCHART_NAN;
        
        NSCalendar * calendar = [NSCalendar currentCalendar];
        
        static struct {
            CChartTime startTime;
            CChartTime endTime;
            CChartTime stepTime;
        } times[] = {
            {{9,30,0},{11,30,0},{0,1,0}},
            {{13,0,0},{15,0,0},{0,1,0}},
        };
        
        
        for(int i=0;i<5;i++){
            id items =  [self.source dataObjectForKey:[NSString stringWithFormat:@"@%d",i]];
            for(id item in items){
                
                NSString * day = [item valueForKey:@"date"];
                
                if([day isKindOfClass:[NSString class]]){
                    NSDate * date = [_dateFormatter dateFromString:day];
                    NSDateComponents * comp = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit fromDate:date];
                    
                    timestamp.date.year = comp.year;
                    timestamp.date.month = comp.month;
                    timestamp.date.day = comp.day;
                    timestamp.date.week = comp.weekday;
                    
                }
                
                id v = [item valueForKey:@"prevclose"];
                
                if(v && data->preValue == CCHART_NAN){
                    data->preValue = [v floatValue];
                }
                
                int n = index % 242;
                int k = 0;
                timestamp.time = times[k].startTime;
                
                while(n >0){
                    timestamp.time = CChartTimeAdd(timestamp.time, times[k].stepTime);
                    if(CChartTimeEqual(timestamp.time,times[k].endTime) ){
                        k ++;
                    }
                    n --;
                }
                
                dataItem = CChartStockDataItemAtIndex(data, index ++);
                
                CChartStockDataItemSetPropertyDateTimeValue(data, Propertys.timestamp, dataItem, timestamp);
                CChartStockDataItemSetPropertyFloatValue(data, Propertys.price, dataItem, [[item valueForKey:@"price"] floatValue]);
                CChartStockDataItemSetPropertyFloatValue(data, Propertys.avg_price, dataItem, [[item valueForKey:@"avg_price"] floatValue]);
                CChartStockDataItemSetPropertyFloatValue(data, Propertys.volume, dataItem, [[item valueForKey:@"volume"] floatValue]);

            }
        }
        
        CChartStockDataSetRange(data, 0, 242 * 5,5);
    }
    return data;
}


@end
