//
//  UIImage+.h
//  SinaFinance
//
//  Created by sang alfred on 9/19/12.
//
//

#import <Foundation/Foundation.h>

@interface UIImage (plus)

- (id) initWithName:(NSString *)name;
+ (UIImage *) imageWithName:(NSString *)name;

@end