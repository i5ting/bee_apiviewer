//
//  IOSChart.m
//  IOSChart
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChart.h"

#include <OpenGLES/ES1/gl.h>
#include <OpenGLES/ES1/glext.h>

@implementation IOSChart

@synthesize left = _left;
@synthesize right = _right;
@synthesize top = _top;
@synthesize bottom = _bottom;
@synthesize width = _width;
@synthesize height = _height;
@synthesize delegate = _delegate;

-(void) dealloc{
    [_left release];
    [_right release];
    [_top release];
    [_bottom release];
    [_width release];
    [_height release];
    [super dealloc];
}

static CChartFloat IOSChartFloatValue(id value){
    if(value == nil){
        return -1;
    }
    if([value isKindOfClass:[NSString class]]){
        if([value hasSuffix:@"%"]){
            return [value floatValue] / 100.0;
        }
    }
    return [value floatValue];
}

-(CChartRect) frame:(CChartContext *) chartContext{
    
    CChartRelativeRect r = {
        { IOSChartFloatValue(_left)
            , IOSChartFloatValue(_top)
            , IOSChartFloatValue(_right)
            , IOSChartFloatValue(_bottom)},
        {IOSChartFloatValue(_width)
            , IOSChartFloatValue(_height)}
    };
    
    return CChartRectMakeRelative(CChartRectMake(0.0f,0.0f,chartContext->viewport.width * chartContext->scale, chartContext->viewport.height * chartContext->scale)
                                  , r);
}

-(void) drawChart:(CChartContext *)chartContext{
    
}


-(void) scrollBegin{
    
}

-(void) scrollValueChanged:(CGPoint) value{
    
}

-(void) scrollEnd{
    
}

-(void) focusBegin:(CGPoint) value{
    
}

-(void) focusValueChanged:(CGPoint) value{
    
}

-(void) focusEnd{
    
}

-(void) scaleBegin{
    
}

-(void) scaleValueChanged:(CGFloat) scale{
    
}

-(void) scaleEnd{
    
}

@end

static void CChartLabelClassDraw(CChartContext * context,CChartLabel * chart,CChartRect rect){
    
    if(context && chart && chart->fontSize >0 && chart->text){
        
        NSString * text = [NSString stringWithCString:chart->text encoding:NSUTF8StringEncoding];
        
        UIFont * font = [UIFont systemFontOfSize:chart->fontSize];
        
        UIColor * textColor = [UIColor colorWithRed:chart->color.r green:chart->color.g blue:chart->color.b alpha:chart->color.a];
        
        CGSize size = [text sizeWithFont:font];
        
        int width = size.width / context->scale + 0.99999;
        int height = size.height / context->scale + 0.99999;
        
        int length = width * height * 4;
        
        CGColorSpaceRef rgbSpace = CGColorSpaceCreateDeviceRGB();
        
        if(context->label.data == NULL){
            context->label.length = length;
            context->label.data = malloc(length);
        }
        else if(length > context->label.length){
            context->label.data = realloc(context->label.data, length);
            context->label.length = length;
        }
        
        memset(context->label.data, 0, length);
        
        CGContextRef ctx = CGBitmapContextCreate(context->label.data, width, height, 8, 4 * width, rgbSpace, kCGImageAlphaPremultipliedLast );
        
        CGContextTranslateCTM(ctx, 0.0, height);
        
        CGContextScaleCTM(ctx, 1.0 / context->scale, -1.0 / context->scale);
        
        
        CGContextSetFillColorWithColor(ctx, [textColor CGColor]);
        CGContextSetStrokeColorWithColor(ctx, [textColor CGColor]);
        
        UIGraphicsPushContext(ctx);
        
        [text drawAtPoint:CGPointMake(0, 0) withFont:font];
        
        UIGraphicsPopContext();
        
        if(context->label.texture == 0){
        
            glGenTextures(1, &context->label.texture);

            glBindTexture(GL_TEXTURE_2D, context->label.texture);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            
        }
        else{
            glBindTexture(GL_TEXTURE_2D, context->label.texture);
        }
        
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, CGBitmapContextGetData(ctx));

        struct {
            CChartPoint location;
            CChartPoint txtCoord;
        } elements[4] = {
            {{0.0f,0.0f},{0.0f,0.0f}},
            {{0.0f,0.0f},{1.0f,0.0f}},
            {{0.0f,0.0f},{1.0f,1.0f}},
            {{0.0f,0.0f},{0.0f,1.0f}},
        };
        
        CChartFloat w = size.width / context->scale / context->viewport.width;
        CChartFloat h = size.height / context->scale / context->viewport.height;
        CChartFloat x = CChartContextRelativeOfWidth(context, rect.origin.x + chart->location.x * rect.size.width);
        CChartFloat y = CChartContextRelativeOfHeight(context, rect.origin.y + chart->location.y * rect.size.height);
        
        if((chart->mode & CChartLabelModeTop)){
            elements[0].location.y = y + h;
            elements[1].location.y = y + h;
            elements[2].location.y = y;
            elements[3].location.y = y;
        }
        else if((chart->mode & CChartLabelModeBottom)){
            elements[0].location.y = y;
            elements[1].location.y = y;
            elements[2].location.y = y - h;
            elements[3].location.y = y - h;
        }
        else{
            elements[0].location.y = y + h / 2.0f;
            elements[1].location.y = y + h / 2.0f;
            elements[2].location.y = y - h / 2.0f;
            elements[3].location.y = y - h / 2.0f;
        }
        
        if((chart->mode & CChartLabelModeLeft)){
            
            if(x - w < 0.0f){
                x = w;
            }
            
            elements[0].location.x = x - w ;
            elements[1].location.x = x;
            elements[2].location.x = x;
            elements[3].location.x = x - w ;
        }
        else if((chart->mode & CChartLabelModeRight)){
            elements[0].location.x = x ;
            elements[1].location.x = x + w;
            elements[2].location.x = x + w;
            elements[3].location.x = x;
        }
        else{
            elements[0].location.x = x - w / 2.0f;
            elements[1].location.x = x + w / 2.0f;
            elements[2].location.x = x + w / 2.0f;
            elements[3].location.x = x - w / 2.0f;
        }
        
        glActiveTexture(GL_TEXTURE0 );
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, context->label.texture);
        
        glClientActiveTexture(GL_TEXTURE0);
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        
        glVertexPointer(2, GL_FLOAT, sizeof(elements[0]), &elements->location);
        
        glTexCoordPointer(2, GL_FLOAT, sizeof(elements[0]), &elements->txtCoord);
        
        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        
        glDisable(GL_TEXTURE_2D);
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        
        CGContextRelease(ctx);
        
        CGColorSpaceRelease(rgbSpace);

    }
}

CChartClass CChartLabelClass = {(CChartDraw)CChartLabelClassDraw,sizeof(CChartLabel)};

CChartSize CChartLabelSize(CChartString text,CChartFloat fontSize){
    
    if(text && fontSize >0){
        
        NSString * txt = [NSString stringWithCString:text encoding:NSUTF8StringEncoding];
        
        UIFont * font = [UIFont systemFontOfSize:fontSize];
        
        CGSize size = [txt sizeWithFont:font];
        
        return CChartSizeMake(size.width, size.height);
    }
    
    return CChartSizeMake(0, 0);
}
