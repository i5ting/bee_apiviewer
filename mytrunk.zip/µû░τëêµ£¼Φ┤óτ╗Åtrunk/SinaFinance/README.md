


##tab


bee generate scaffold __BOARD_NAME

bee generate board __BOARD_NAME
bee generate message __BOARD_NAME_MESSAGE
bee generate view __BOARD_NAME_VIEW
bee generate model __BOARD_NAME



