//
//  StockInfoChartViewController.m
//  SinaFinance
//
//  Created by zhang hailong on 13-6-24.
//
//

#import "StockInfoChartViewController.h"

#include <Chart/CChartStockData.h>


@interface StockInfoChartViewController (){

}

@end

@implementation StockInfoChartViewController

@synthesize symbol=  _symbol;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_chartView release];
    [_dataSource release];
    [_symbol release];
    [_tabButtons release];
    [_stocks release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setChartView:nil];
    [self setDataSource:nil];
    [self setTabButtons:nil];
    [self setStocks:nil];
    [super viewDidUnload];
}

-(CChartStockData *) IOSChartStockData:(IOSChartStock *) chartStock{
    
    NSInteger index = [_stocks indexOfObject:chartStock];
    
    switch (index) {
        case 0:
            return [_dataSource realtime:self.symbol];
            break;
        case 1:
            return [_dataSource dayK:self.symbol];
            break;
        case 2:
            return [_dataSource weekK:self.symbol];
            break;
        case 3:
            return [_dataSource monthK:self.symbol];
            break;
        default:
            break;
    }
    
    return nil;
}

-(void) reloadData:(NSString *) symbol{
    [symbol retain];
    [_symbol release];
    _symbol = symbol;
    [_chartView setNeedsRender];
}

- (IBAction)tabAction:(id)sender {
    NSInteger index = [_tabButtons indexOfObject:sender];
    if(index != NSNotFound){
        [_chartView setChart:[_stocks objectAtIndex:index]];
        [_chartView setNeedsRender];
        for(UIButton * button in _tabButtons){
            [button setSelected:button == sender];
        }
    }
}

@end
