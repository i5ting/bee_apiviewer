//
//  CChartStock.c
//  Chart
//
//  Created by zhang hailong on 13-5-15.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStock.h"

struct _CChartStockStylePropertys CChartStockStylePropertys ={
    {"forms",CChartStylePropertyTypeStyle,sizeof(CChartStyle)},
    {"rect",CChartStylePropertyTypeRect,sizeof(CChartRelativeRect)},
    {"backgroundColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"borderColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"borderWidth",CChartStylePropertyTypeFloat,sizeof(CChartFloat)},
    {"lineWidth",CChartStylePropertyTypeFloat,sizeof(CChartFloat)},
    {"focusColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"focusLabelColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"labelColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"fillColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"fontSize",CChartStylePropertyTypeFloat,sizeof(CChartFloat)},
    {
        {"value",CChartStylePropertyTypeString,32},
        {"volume",CChartStylePropertyTypeString,32},
        {"openValue",CChartStylePropertyTypeString,32},
        {"lowValue",CChartStylePropertyTypeString,32},
        {"highValue",CChartStylePropertyTypeString,32},
        {"avgValue",CChartStylePropertyTypeString,32},
        {"timestamp",CChartStylePropertyTypeString,32},
    },
};


struct _CChartStockFormStylePropertys CChartStockFormStylePropertys = {
    {"drawFun",CChartStylePropertyTypePtr,sizeof(void *)},
    {"rect",CChartStylePropertyTypeRect,sizeof(CChartRelativeRect)},
    {"backgroundColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"borderColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"borderWidth",CChartStylePropertyTypeFloat,sizeof(CChartFloat)},
    {"gridColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"gridWidth",CChartStylePropertyTypeFloat,sizeof(CChartFloat)},
    {"fontSize",CChartStylePropertyTypeFloat,sizeof(CChartFloat)},
    {"curColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"fallColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"riseColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"labelColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"lineWidth",CChartStylePropertyTypeFloat,sizeof(CChartFloat)},
    {"focusColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"focusLabelColor",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"columnType",CChartStylePropertyTypeString,32},
    {"lineColor1",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"lineColor2",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"lineColor3",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"lineColor4",CChartStylePropertyTypeColor,sizeof(CChartColor)},
    {"lineColor5",CChartStylePropertyTypeColor,sizeof(CChartColor)},
};

CChartStyleClass CChartStockStyleClass = {
    (const CChartStyleProperty *)&CChartStockStylePropertys,sizeof(CChartStockStylePropertys) / sizeof(CChartStyleProperty)
};

CChartStyleClass CChartStockFormStyleClass = {
    (const CChartStyleProperty *)&CChartStockFormStylePropertys,sizeof(CChartStockFormStylePropertys) / sizeof(CChartStyleProperty)
};



void CChartStockClassInitialize(){
    
    CChartStyleClassInitialize(&CChartStockStyleClass);
    
    CChartStyleClassInitialize(&CChartStockFormStyleClass);
    
}

void CChartStockDataBind(CChartStock * const stock,CChartStyle * style,CChartStockData * data){
    
    CChartStyleItem item = CChartStyleItemAtIndex(style, 0);
    
    stock->style = style;
    stock->styleIndex = 0;
    stock->data = data;
    
    if(data){
        stock->dataPropertys.value = CChartStockDataGetProperty(data, CChartStyleItemStringValue(style, item, &CChartStockStylePropertys.dataKeys.value, "close"));
        stock->dataPropertys.openValue = CChartStockDataGetProperty(data, CChartStyleItemStringValue(style, item, &CChartStockStylePropertys.dataKeys.openValue, "open"));
        stock->dataPropertys.lowValue = CChartStockDataGetProperty(data, CChartStyleItemStringValue(style, item, &CChartStockStylePropertys.dataKeys.lowValue, "low"));
        stock->dataPropertys.highValue = CChartStockDataGetProperty(data, CChartStyleItemStringValue(style, item, &CChartStockStylePropertys.dataKeys.highValue, "high"));
        stock->dataPropertys.avgValue = CChartStockDataGetProperty(data, CChartStyleItemStringValue(style, item, &CChartStockStylePropertys.dataKeys.avgValue, "avg_price"));
        stock->dataPropertys.volume = CChartStockDataGetProperty(data, CChartStyleItemStringValue(style, item, &CChartStockStylePropertys.dataKeys.volume, "volume"));
        stock->dataPropertys.timestamp = CChartStockDataGetProperty(data, CChartStyleItemStringValue(style, item, &CChartStockStylePropertys.dataKeys.timestamp, "timestamp"));
    }
    else{
        stock->dataPropertys.value
        = stock->dataPropertys.openValue
        = stock->dataPropertys.lowValue
        = stock->dataPropertys.highValue
        = stock->dataPropertys.avgValue
        = stock->dataPropertys.volume
        = stock->dataPropertys.timestamp = NULL;
    }
}

static void CChartStockLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect){
    
    if(context && chart && chart->data){
        int i;
        CChartStyle * forms ,* form;
        CChartDraw drawFun;
        CChartRect r;
        CChartFloat x,y;
        CChartClass clazz = {NULL,sizeof(CChartStockLayer)};
        CChartStockLayer formLayer = {{&clazz},NULL,0,chart->data,{0.0f,0.0f},chart->dataPropertys};
        CChartStyleItem item = CChartStyleItemAtIndex(chart->style, chart->styleIndex);
        CChartRect rr = CChartRectMakeRelative(rect, CChartStyleItemRectValue(chart->style, item, &CChartStockStylePropertys.rect));
        CChartPoint linePoints[2] = {{0.0f,0.0f},{0.0f,0.0f}};
        CChartLine line = {{&CChartLineClass},{linePoints,sizeof(linePoints) / sizeof(CChartPoint)}
            ,CChartStyleItemFloatValue(chart->style, item, & CChartStockStylePropertys.lineWidth,0.0f)
            ,CChartStyleItemColorValue(chart->style, item, & CChartStockStylePropertys.focusColor)};
        CChartTipLabel tipLabel = {{&CChartTipLabelClass}};
        CChartPoint focusLocation;
        CChartStockDataItem dataItem;
        CChartDateTime timestamp = {{0,0,0},{0,0,0}};
        char text[128];
        CChartSize textSize;
        
        x = rect.size.width * chart->focusLocation.x;
        y = rect.size.height * chart->focusLocation.y;
        
        forms = CChartStyleItemStyleValue(chart->style, item, &CChartStockStylePropertys.forms);
        
        if(forms && forms->clazz && forms->length){
            for(i=0;i<forms->length;i++){
                
                form = CChartStyleItemAtIndex(forms, i);
                
                r = CChartRectMakeRelative(rr, CChartStyleItemRectValue(forms, form, &CChartStockFormStylePropertys.rect));
                
                drawFun = CChartStyleItemPtrValue(forms, form, &CChartStockFormStylePropertys.drawFun);
                
                if(drawFun){
                    
                    clazz.draw = drawFun;
                    formLayer.focusLocation = CChartPointMake((x - r.origin.x ) / r.size.width, (y - r.origin.y) / r.size.height);
                    formLayer.style = forms;
                    formLayer.styleIndex = i;
                    
                    CChartContextDraw(context, (CChart *) &formLayer, r);
                }

            }
        }
        
        focusLocation.x = (x - rr.origin.x) / rr.size.width;
        focusLocation.y = (y - rr.origin.y) / rr.size.height;
        
        if(focusLocation.x >=0.0f && focusLocation.x <= 1.0f){
            
            i = focusLocation.x * chart->data->length;
            
            if(i >=0 && i < chart->data->length){
                
                dataItem = CChartStockDataItemAtIndex(chart->data, i + chart->data->location);

                linePoints[0].x = linePoints[1].x = CChartStockDataXValue(chart->data, i);
                linePoints[0].y = 0.0f;
                linePoints[1].y = 1.0f;
                
                CChartContextDraw(context, (CChart *) & line, rr);
                
                
                tipLabel.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockStylePropertys.fontSize, 0.0f);
                tipLabel.color = CChartStyleItemColorValue(chart->style, item, &CChartStockStylePropertys.focusLabelColor);
                tipLabel.fillColor = CChartStyleItemColorValue(chart->style, item, &CChartStockStylePropertys.focusColor);
                tipLabel.lineWidth = 1;
                tipLabel.distance = 0.0f;
                
                tipLabel.location.x = CChartStockDataXValue(chart->data,chart->data->minValueIndex - chart->data->location ) ;
                tipLabel.location.y = CChartStockDataYValue(chart->data,chart->data->minValue);
                
                timestamp = CChartStockDataItemPropertyDateTimeValue(chart->data, chart->dataPropertys.timestamp, dataItem, CChartDateTimeEmpty);
                
                if(timestamp.date.year){
                    if(timestamp.time.hour){
                        CChartDateTimeToString(timestamp,CChartDateTimeUnitDate | CChartDateTimeUnitHour | CChartDateTimeUnitMinute,text);
                    }
                    else if(timestamp.date.week){
                        CChartDateTimeToString(timestamp,CChartDateTimeUnitDate | CChartDateTimeUnitWeek,text);
                    }
                    else{
                        CChartDateTimeToString(timestamp,CChartDateTimeUnitDate,text);
                    }
                }
                else{
                    CChartDateTimeToString(timestamp,CChartDateTimeUnitTime,text);
                }
                
                tipLabel.text = text;
                tipLabel.location.x = CChartStockDataXValue(chart->data, i);
                tipLabel.location.y = 1.0f;
                
                textSize = CChartLabelSize(tipLabel.text, tipLabel.fontSize);
                textSize = CChartContextRelativeSize(context, textSize);
                
                tipLabel.mode = CChartLabelModeTop | CChartLabelModeVertical;
                
                if(tipLabel.location.x + textSize.width / 2.0f > 0.98f){
                    tipLabel.mode |= CChartLabelModeLeft;
                }
                else if(tipLabel.location.x - textSize.width / 2.0f < 0.02f){
                    tipLabel.mode |= CChartLabelModeRight;
                }
                
                CChartContextDraw(context, (CChart *) & tipLabel, rr);
            }
        }
    }
}


CChartClass CChartStockClass = {(CChartDraw) CChartStockLayerDraw,sizeof(CChartStockLayer)};



void CChartStockFormColumnsDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect,CChartBoolean hasLabel){
    if(context && chart && chart->style){
        CChartStyleItem item = CChartStyleItemAtIndex(chart->style, chart->styleIndex);
        CChartPoint linePoints[2] = {{0.0f,0.0f},{0.0f,0.0f}};
        CChartLine line = {{&CChartLineClass},{linePoints,sizeof(linePoints) / sizeof(CChartPoint)}
            ,CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.gridWidth, 0.0f)
            ,CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.gridColor)};
        CChartLabel label = {{&CChartLabelClass}};
        CChartDateTime timestamp ;
        CChartStockDataItem dataItem;
        CChartSize textSize;
        CChartFloat x;
        CChartString columnType = CChartStyleItemStringValue(chart->style, item, & CChartStockFormStylePropertys.columnType, "");
        
        int i,months = chart->data->columns.months,monthCount = 0,preMonthCount = 0,c;
        char text[128];
        
        label.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.labelColor);
        label.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
    
        if(strcmp(columnType, "real-time") ==0){
            {
                char columns[][16] = {
                    "09:30","10:30","11:30/13:00","14:00","15:00"
                };
                
                c = sizeof(columns) / sizeof(columns[0]);
                
                for(i=0;i<c;i++){
                    
                    linePoints[0].y = 0.0f;
                    linePoints[1].y = 1.0f;
                    linePoints[0].x = linePoints[1].x = i * 0.25;
                    
                    CChartContextDraw(context, (CChart *) &line, rect);
                    
                    if(hasLabel){
                        label.text = columns[i];
                        label.location.y = linePoints[0].y;
                        
                        label.location.x = linePoints[0].x;
                        
                        if(i ==0){
                            label.mode = CChartLabelModeRight | CChartLabelModeBottom;
                        }
                        else if(i == c -1){
                            label.mode = CChartLabelModeLeft | CChartLabelModeBottom;
                        }
                        else{
                            label.mode = CChartLabelModeBottom;
                        }
                        
                        CChartContextDraw(context, (CChart *) & label, rect);
                    }
                    
                }
            }
        }
        else if(strcmp(columnType, "day5") ==0){
            {
                for(i=0;i<6;i++){
                    
                    linePoints[0].y = 0.0f;
                    linePoints[1].y = 1.0f;
                    linePoints[0].x = linePoints[1].x = i * 0.20;
                    
                    CChartContextDraw(context, (CChart *) &line, rect);
                    
                    if(hasLabel && i < 5){
                        
                        dataItem = CChartStockDataItemAtIndex(chart->data, i % 240);
                        timestamp = CChartStockDataItemPropertyDateTimeValue(chart->data, chart->dataPropertys.timestamp, dataItem, CChartDateTimeEmpty);
                        
                        if(!CChartDateTimeEqual(timestamp, CChartDateTimeEmpty, CChartDateTimeUnitYear | CChartDateTimeUnitMonth | CChartDateTimeUnitDay)){
                            
                            CChartDateTimeToString(timestamp, CChartDateTimeUnitDate | CChartDateTimeUnitWeek, text);
                            
                            label.text = text;
                            label.location.y = linePoints[0].y;
                            label.location.x = linePoints[0].x + 0.1;
                            label.mode = CChartLabelModeBottom;
                            
                            CChartContextDraw(context, (CChart *) & label, rect);
                        }
                        
                    }
                    

                }
            }
        }
        else{
            if(months < 1){
                months = 1;
            }
            
            for(i=0;i<chart->data->length;i++){
                
                dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location+ i);
                timestamp = CChartStockDataItemPropertyDateTimeValue(chart->data, chart->dataPropertys.timestamp, dataItem, CChartDateTimeEmpty);
                
                monthCount = timestamp.date.year * 12 + timestamp.date.month;
                
                if(preMonthCount == 0){
                    preMonthCount = monthCount;
                }
                else if(monthCount !=preMonthCount && monthCount % months == 0){
                    linePoints[0].y = 0.0f;
                    linePoints[1].y = 1.0f;
                    linePoints[0].x = linePoints[1].x = CChartStockDataXValue(chart->data, i);
                    
                    CChartContextDraw(context, (CChart *) &line, rect);
                    
                    if(hasLabel){
                        
                        CChartDateTimeToString(timestamp, CChartDateTimeUnitYear | CChartDateTimeUnitMonth , text);
                        label.text = text;
                        label.location.y = 0.0f;
                        label.location.x = linePoints[0].x ;
                        label.mode = CChartLabelModeBottom;
                        
                        x = linePoints[0].x * rect.size.width;
                        
                        textSize = CChartLabelSize(text, label.fontSize);
                        
                        if(x - textSize.width / 2.0 >=0 && x + textSize.width / 2.0 < rect.size.width){
                        
                            CChartContextDraw(context, (CChart *) & label, rect);
                        }
                        
                    }
                    
                    preMonthCount = monthCount;
                }
            }
        }
        
    }
}

void CChartStockMALabelFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect){
   
    {
        if(context && chart && chart->style){
            CChartStyleItem item = CChartStyleItemAtIndex(chart->style, chart->styleIndex);
            CChartFill fill = {{&CChartFillClass},CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.backgroundColor)};
            CChartBorder border = {{&CChartBorderClass},CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.borderWidth, 0.0f), CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.borderColor)};
            
            
            CChartContextDraw(context, (CChart*) &fill, rect);
            
    
            CChartContextDraw(context, (CChart*) &border, rect);
        }
    }
    
    if(context && chart && chart->data){
        
        CChartFloat dw = CChartContextRelativeOfWidth(context, 4);
        CChartLabel label = {{&CChartLabelClass},{dw,0.5f}};
        int c;
        CChartStyleItem item = CChartStyleItemAtIndex(chart->style,chart->styleIndex);
        CChartFloat v;
        CChartStockDataItem dataItem = NULL;
        CChartStyleProperty * lineColorProperty = & CChartStockFormStylePropertys.lineColor1;
        CChartStockDataProperty * prop;
        CChartSize textSize;
        char text[128];
        char floatText[128];
        
        if(chart->focusLocation.x >=0 && chart->focusLocation.x <= 1.0){
            dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location + chart->focusLocation.x * chart->data->length);
        }
        else{
            dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location + chart->data->length -1);
        }
        
        label.color = CChartStyleItemColorValue(chart->style, item, lineColorProperty);
        label.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
        label.mode = CChartLabelModeRight;
        
        c = chart->data->propertyCount;
        prop = chart->data->propertys;
        
        while(c >0){
            
            switch (prop->type) {
                case CChartStockDataPropertyTypeValueMa:
                {
                 
                    v = CChartStockDataItemPropertyFloatValue(chart->data, prop, dataItem, 0.0f);
                    CChartFloatToString(v, floatText);
                    
                    sprintf(text, "MA%d:%s",prop->value,floatText);
                    
                    label.text = text;

                    CChartContextDraw(context, (CChart *) & label, rect);
                    
                    textSize = CChartLabelSize(text,label.fontSize);
                    
                    label.location.x += textSize.width  / rect.size.width + dw;
                    
                    if(lineColorProperty != & CChartStockFormStylePropertys.lineColor5){
                        lineColorProperty ++;
                        label.color = CChartStyleItemColorValue(chart->style, item, lineColorProperty);
                    }
                }
                    break;
                default:
                    break;
            }
            
            prop ++;
            c --;
        }
    }
}
