//
//  IOSChartData.h
//  IOSChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject(IOSChartData)

-(id) dataObjectForKey:(NSString *) key;

-(id) dataObjectForKeyPath:(NSString *) keyPath;

@end
