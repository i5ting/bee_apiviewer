//
//  CChartStockVolume.c
//  Chart
//
//  Created by zhang hailong on 13-5-20.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStock.h"

void CChartStockVolumeFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect){
    
    {
        if(context && chart && chart->style){
            CChartStyleItem item = CChartStyleItemAtIndex(chart->style, chart->styleIndex);
            CChartFill fill = {{&CChartFillClass},CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.backgroundColor)};
            CChartBorder border = {{&CChartBorderClass},CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.borderWidth, 0.0f), CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.borderColor)};
            CChartLabel label = {{&CChartLabelClass}};
            
            char text[128];
            
            CChartContextDraw(context, (CChart*) &fill, rect);
            CChartFloat r = 1.0f;
            
            label.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.labelColor);
            label.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
            label.mode = CChartLabelModeLeft;
            
            if((int)(chart->data->volumeAdjust.max / 100000000000.0f)){
                label.text = "亿";
                label.location.y = 0.0f;
                label.location.x = 0.0f;
                r = 10000000000.0f;
            }
            else if((int)(chart->data->volumeAdjust.max / 100000000.0f)){
                label.text = "百万";
                label.location.y = 0.0f;
                label.location.x = 0.0f;
                r = 100000000.0f;
            }
            else{
                label.text = "万";
                label.location.y = 0.0f;
                label.location.x = 0.0f;
                r = 1000000.0f;
            }
            
            
            CChartContextDraw(context, (CChart *) & label, rect);
            
            CChartFloatToString(chart->data->volumeAdjust.max / r, text);
            
            label.text = text;
            label.location.y = 1.0f;
            label.location.x = 0.0f;
            
            CChartContextDraw(context, (CChart *) & label, rect);
            
            CChartStockFormColumnsDraw(context,chart,rect,0);
            
            CChartContextDraw(context, (CChart*) &border, rect);
        }
    }
    
    
    if(context && chart && chart->data){
        
        CChartPillar pillar = {{&CChartPillarClass}};
        int i;
        CChartFloat width = 0.8f / chart->data->length;
        CChartStyleItem item = CChartStyleItemAtIndex(chart->style, chart->styleIndex);
        CChartColor fallColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.fallColor);
        CChartColor riseColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.riseColor);
        CChartColor preColor;
        CChartFloat preValue,v;
        CChartStockDataItem dataItem;
        CChartTipLabel tipLabel = {{&CChartTipLabelClass}};
        char text[128];
        
        dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location - 1);
        
        if(dataItem){
            preValue = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.volume, dataItem, 0.0f);
            preColor = riseColor;
        }
        else{
            preValue = 0.0f;
            preColor = riseColor;
        }
        
        for(i=0;i<chart->data->length;i++){
            
            dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location + i);
            v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.volume, dataItem, CCHART_NAN);
            
            if(v != CCHART_NAN){
                
                pillar.location.x = CChartStockDataXValue(chart->data,i);
                pillar.location.y = CChartStockDataYVolume(chart->data, v);
                pillar.width = width;
                
                if(v == preValue){
                    pillar.color = preColor;
                }
                else if(v > preValue){
                    pillar.color = riseColor;
                }
                else{
                    pillar.color = fallColor;
                }
                
                preColor = pillar.color;
                preValue =v;
                
                CChartContextDraw(context, (CChart *) &pillar, rect);
                
            }
        }
        
        if(chart->focusLocation.x >=0.0f && chart->focusLocation.x <= 1.0f){
            
            i = chart->focusLocation.x * chart->data->length;
            
            if(i >=0 && i < chart->data->length){
                
                dataItem = CChartStockDataItemAtIndex(chart->data, i + chart->data->location);
                
                v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.volume, dataItem, CCHART_NAN);
                
                if(v != CCHART_NAN){
                    
                    tipLabel.fillColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.borderColor);
                    tipLabel.distance = 0.0f;
                    tipLabel.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.labelColor);
                    tipLabel.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
                    
                    if((int)(v / 10000000000.0f)){
                        CChartFloatToString(v/ 10000000000.0f,text);
                        strcat(text, " 亿");
                    }
                    else if((int)(v / 1000000.0f)){
                        CChartFloatToString(v/ 1000000.0f,text);
                        strcat(text, " 万");
                    }
                    else{
                        CChartFloatToString(v/ 1000000.0f,text);
                    }
                    
                    tipLabel.text = text;
                    tipLabel.location.y = CChartStockDataYVolume(chart->data, v);
                    tipLabel.location.x = 0.0f;
                    tipLabel.mode = CChartLabelModeLeft;
                    
                    CChartContextDraw(context, (CChart *) & tipLabel, rect);
                }
                
            }
        }
    }
}
