//
//  CChartMaker.c
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartMaker.h"


#undef CChartMakerCreate

void CChartMakerDelete(CChartMaker * const marker){
    int i=0;
    if(marker->memorys){
        for(i=0;i<marker->length;i++){
            free(marker->memorys[i].data);
        }
        free(marker->memorys);
    }
    marker->memorys = NULL;
    marker->length = 0;
    marker->size = 0;
}

void * CChartMakerCreate(CChartMaker * const marker,CChartString type,CChartUInteger length){
    CChartMakerMemory * mem = NULL;
    if(marker->size < marker->length +1){
        if(marker->memorys){
            marker->memorys = realloc(marker->memorys, (sizeof(CChartMakerMemory) * (marker->size + 20)));
        }
        else{
            marker->memorys = malloc((sizeof(CChartMakerMemory) * (marker->size + 20)));
        }
        marker->size += 20;
    }
    mem = marker->memorys + marker->length;
    marker->length ++;
    mem->length = length;
    mem->type = type;
    mem->data = malloc(length);
    memset(mem->data,0,length);
    return mem->data;
}

CChartString CChartMakerCreateString(CChartMaker * const marker,CChartString string){
    if(string){
        CChartString r = (CChartString) CChartMakerCreate(marker,"CChartString",strlen(string) + 1);
        strcpy((char *)r, string);
        return r;
    }
    return NULL;
}
