//
//  CChartData.h
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef CChart_CChartData_h
#define CChart_CChartData_h


#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>
   
    extern void CChartDataObjectPoolBegin();
    
    extern void CChartDataObjectPoolEnd();
    
    extern CChartFloat CChartDataObjectFloatValue(CChartDataObject object,CChartFloat defaultValue);
    
    extern CChartUInteger CChartDataObjectUIntegerValue(CChartDataObject object,CChartUInteger defaultValue);
    
    extern CChartString CChartDataObjectStringValue(CChartDataObject object,CChartString defaultValue);
    
    extern CChartDouble CChartDataObjectDoubleValue(CChartDataObject object,CChartDouble defaultValue);
    
    extern CChartInt64 CChartDataObjectInt64Value(CChartDataObject object,CChartInt64 defaultValue);
    
    extern CChartDataObject CChartDataObjectValueForKeyPath(CChartDataObject object,CChartString keyPath);
    
    extern CChartDataObject CChartDataObjectValueAtIndex(CChartDataObject object,CChartUInteger index);
    
    CChartFloat CChartDataObjectFloatValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartFloat defaultValue);
    
    CChartUInteger CChartDataObjectUIntegerValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartUInteger defaultValue);
    
    CChartString CChartDataObjectStringValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartString defaultValue);
    
    CChartColor CChartDataObjectColorValue(CChartDataObject object);
    
    CChartColor CChartDataObjectColorValueForKeyPath(CChartDataObject object,CChartString keyPath);
    
    CChartDouble CChartDataObjectDoubleValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartDouble defaultValue);
    
    CChartInt64 CChartDataObjectInt64ValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartInt64 defaultValue);
    
    CChartRelativeRect CChartDataObjectRelativeRectValue(CChartDataObject object);
    
    
#ifdef __cplusplus
}
#endif


#endif
