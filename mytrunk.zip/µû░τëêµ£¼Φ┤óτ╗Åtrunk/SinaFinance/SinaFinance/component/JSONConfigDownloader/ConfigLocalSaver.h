//
//  ConfigLocalSaver.h
//  SinaFinance
//
//  Created by shieh exbice on 12-6-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ConfigLocalSaver : NSObject

-(void)mergeAndSaveFromBundle;
-(BOOL)spliteAndSaveWithString:(NSString*)string;

@end
