//
//  IOSChartStockData.h
//  Chart
//
//  Created by zhang hailong on 13-5-17.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <Foundation/Foundation.h>


#include <Chart/CChartStock.h>
#include <Chart/CChartStockData.h>
#include <Chart/CChartStockStyle.h>
#include "IOSChartData.h"

@interface IOSChartStockData : NSObject

@property(nonatomic,readonly) CChartStockData * cData;

@end
