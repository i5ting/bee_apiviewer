//
//  CChartStockStyle.c
//  Chart
//
//  Created by zhang hailong on 13-5-15.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStockStyle.h"


void CChartStockStyleOpen(CChartStyle * style,CChartDataObject dataObject){
    
    CChartStyleItem item;
    CChartStyle forms = {0};
    CChartStyleCreate(style, &CChartStockStyleClass, 1);
    CChartDataObject formsDataObject,formDataObject;
    CChartUInteger length,i;
    CChartString v;
    
    item = CChartStyleItemAtIndex(style, 0);
    
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.rect, CChartDataObjectStringValueForKeyPath(dataObject, "rect", ""));
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.dataKeys.value, CChartDataObjectStringValueForKeyPath(dataObject, "dataKeys.value", "close"));
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.dataKeys.openValue, CChartDataObjectStringValueForKeyPath(dataObject, "dataKeys.openValue", "open"));
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.dataKeys.lowValue, CChartDataObjectStringValueForKeyPath(dataObject, "dataKeys.lowValue", "low"));
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.dataKeys.highValue, CChartDataObjectStringValueForKeyPath(dataObject, "dataKeys.highValue", "high"));
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.dataKeys.volume, CChartDataObjectStringValueForKeyPath(dataObject, "dataKeys.volumeValue", "volume"));
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.dataKeys.avgValue, CChartDataObjectStringValueForKeyPath(dataObject, "dataKeys.avgValue", "avg_price"));
    CChartStyleItemSetStringValue(style, item, & CChartStockStylePropertys.dataKeys.timestamp, CChartDataObjectStringValueForKeyPath(dataObject, "dataKeys.timestamp", "timestamp"));
    
    CChartStyleItemSetColorValue(style, item, & CChartStockStylePropertys.backgroundColor, CChartDataObjectColorValueForKeyPath(dataObject, "backgroundColor"));
    CChartStyleItemSetColorValue(style, item, & CChartStockStylePropertys.borderColor, CChartDataObjectColorValueForKeyPath(dataObject, "borderColor"));
    CChartStyleItemSetFloatValue(style, item, & CChartStockStylePropertys.borderWidth, CChartDataObjectFloatValueForKeyPath(dataObject, "borderWidth", 0.0f));
    CChartStyleItemSetColorValue(style, item, & CChartStockStylePropertys.focusColor, CChartDataObjectColorValueForKeyPath(dataObject, "focusColor"));
    CChartStyleItemSetColorValue(style, item, & CChartStockStylePropertys.focusLabelColor, CChartDataObjectColorValueForKeyPath(dataObject, "focusLabelColor"));
    CChartStyleItemSetFloatValue(style, item, & CChartStockStylePropertys.lineWidth, CChartDataObjectFloatValueForKeyPath(dataObject, "lineWidth", 0.0f));
    CChartStyleItemSetColorValue(style, item, & CChartStockStylePropertys.labelColor, CChartDataObjectColorValueForKeyPath(dataObject, "labelColor"));
    CChartStyleItemSetColorValue(style, item, & CChartStockStylePropertys.fillColor, CChartDataObjectColorValueForKeyPath(dataObject, "fillColor"));
    CChartStyleItemSetFloatValue(style, item, & CChartStockStylePropertys.fontSize, CChartDataObjectFloatValueForKeyPath(dataObject, "fontSize", 0.0f));
    
    formsDataObject = CChartDataObjectValueForKeyPath(dataObject, "forms");
    
    length = CChartDataObjectUIntegerValueForKeyPath(formsDataObject, "length", 0);
    
    if(length >0){
        
        CChartStyleCreate(&forms, &CChartStockFormStyleClass, length);
        
        CChartStyleItemSetStyleValue(style, item, & CChartStockStylePropertys.forms, &forms);
        
        for(i=0;i<length;i++){
            
            formDataObject = CChartDataObjectValueAtIndex(formsDataObject, i);
            
            item = CChartStyleItemAtIndex(&forms, i);
            
            CChartStyleItemSetStringValue(&forms, item, & CChartStockFormStylePropertys.rect, CChartDataObjectStringValueForKeyPath(formDataObject, "rect", ""));
            
            v = CChartDataObjectStringValueForKeyPath(formDataObject,"type",NULL);
            
            if(v){
                if(strcmp(v, "kline") == 0){
                    CChartStyleItemSetPtrValue(&forms, item, & CChartStockFormStylePropertys.drawFun, CChartStockKLineFormLayerDraw);
                }
                else if(strcmp(v, "yearline") == 0){
                    CChartStyleItemSetPtrValue(&forms, item, & CChartStockFormStylePropertys.drawFun, CChartStockYearLineFormLayerDraw);
                }
                else if(strcmp(v, "volume") == 0){
                    CChartStyleItemSetPtrValue(&forms, item, & CChartStockFormStylePropertys.drawFun, CChartStockVolumeFormLayerDraw);
                }
                else if(strcmp(v, "malabel") == 0){
                    CChartStyleItemSetPtrValue(&forms, item, & CChartStockFormStylePropertys.drawFun, CChartStockMALabelFormLayerDraw);
                }
                else if(strcmp(v, "real-time") == 0){
                    CChartStyleItemSetPtrValue(&forms, item, & CChartStockFormStylePropertys.drawFun, CChartStockRealTimeFormLayerDraw);
                }
                else if(strcmp(v, "day5") == 0){
                    CChartStyleItemSetPtrValue(&forms, item, & CChartStockFormStylePropertys.drawFun, CChartStockDay5LineFormLayerDraw);
                }
            }
            
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.backgroundColor, CChartDataObjectColorValueForKeyPath(formDataObject, "backgroundColor"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.borderColor, CChartDataObjectColorValueForKeyPath(formDataObject, "borderColor"));
            CChartStyleItemSetFloatValue(&forms, item, & CChartStockFormStylePropertys.borderWidth, CChartDataObjectFloatValueForKeyPath(formDataObject, "borderWidth", 0.0f));
            CChartStyleItemSetFloatValue(&forms, item, & CChartStockFormStylePropertys.fontSize, CChartDataObjectFloatValueForKeyPath(formDataObject, "fontSize", 9.0f));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.curColor, CChartDataObjectColorValueForKeyPath(formDataObject, "curColor"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.fallColor, CChartDataObjectColorValueForKeyPath(formDataObject, "fallColor"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.riseColor, CChartDataObjectColorValueForKeyPath(formDataObject, "riseColor"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.labelColor, CChartDataObjectColorValueForKeyPath(formDataObject, "labelColor"));
            CChartStyleItemSetFloatValue(&forms, item, & CChartStockFormStylePropertys.lineWidth, CChartDataObjectFloatValueForKeyPath(formDataObject, "lineWidth",1.0f));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.focusColor, CChartDataObjectColorValueForKeyPath(formDataObject, "focusColor"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.focusLabelColor, CChartDataObjectColorValueForKeyPath(formDataObject, "focusLabelColor"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.gridColor, CChartDataObjectColorValueForKeyPath(formDataObject, "gridColor"));
            CChartStyleItemSetFloatValue(&forms, item, & CChartStockFormStylePropertys.gridWidth, CChartDataObjectFloatValueForKeyPath(formDataObject, "gridWidth",0.0f));
            CChartStyleItemSetStringValue(&forms, item, & CChartStockFormStylePropertys.columnType, CChartDataObjectStringValueForKeyPath(formDataObject, "columnType",""));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.lineColor1, CChartDataObjectColorValueForKeyPath(formDataObject, "lineColor1"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.lineColor2, CChartDataObjectColorValueForKeyPath(formDataObject, "lineColor2"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.lineColor3, CChartDataObjectColorValueForKeyPath(formDataObject, "lineColor3"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.lineColor4, CChartDataObjectColorValueForKeyPath(formDataObject, "lineColor4"));
            CChartStyleItemSetColorValue(&forms, item, & CChartStockFormStylePropertys.lineColor5, CChartDataObjectColorValueForKeyPath(formDataObject, "lineColor5"));
        }
    }
}

