//
//  CChartStyle.h
//  Chart
//
//  Created by zhang hailong on 13-5-15.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef Chart_CChartStyle_h
#define Chart_CChartStyle_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>
   
#ifndef READONLY
#define READONLY const
#endif
    
    typedef enum _CChartStylePropertyType {
        CChartStylePropertyTypeFloat,
        CChartStylePropertyTypeColor,
        CChartStylePropertyTypeString,
        CChartStylePropertyTypeInteger,
        CChartStylePropertyTypeRect,
        CChartStylePropertyTypeStyle,
        CChartStylePropertyTypePtr,
    } CChartStylePropertyType;
    
    typedef CChartString CChartStylePropertyName;
    
    typedef struct _CChartStyleProperty{
        CChartStylePropertyName name;
        CChartStylePropertyType type;
        CChartUInteger length;
        CChartUInteger offset;
    } CChartStyleProperty;
    
    typedef struct _CChartStyleClass {
        const CChartStyleProperty * propertys;
        CChartUInteger propertyCount;
        CChartUInteger size;
    } CChartStyleClass;
    
    typedef struct _CChartStyle {
        const CChartStyleClass * clazz;
        void * READONLY data;
        CChartUInteger READONLY length;
    } CChartStyle;
    
    typedef void * CChartStyleItem;
    
    void CChartStyleClassInitialize(CChartStyleClass * const styleClass);
    
    CChartStyleProperty * CChartStyleClassGetProperty(const CChartStyleClass * styleClass,CChartString name);
    
    void CChartStyleCreate(CChartStyle * const style,const CChartStyleClass * styleClass,CChartUInteger length);
    
    void CChartStyleDelete(CChartStyle * const style);
    
    CChartStyleItem CChartStyleItemAtIndex(CChartStyle * const style,CChartInteger index);
    
    CChartFloat CChartStyleItemFloatValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartFloat defaultValue);
    
    CChartColor CChartStyleItemColorValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop);
    
    CChartString CChartStyleItemStringValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartString defaultValue);
    
    CChartInteger CChartStyleItemIntValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartInteger defaultValue);
    
    CChartStyle * CChartStyleItemStyleValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop);
    
    CChartRelativeRect CChartStyleItemRectValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop);
    
    void * CChartStyleItemPtrValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop);
    
    void CChartStyleItemSetFloatValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartFloat value);
    
    void CChartStyleItemSetColorValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartColor value);
    
    void CChartStyleItemSetStringValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartString value);
    
    void CChartStyleItemSetIntValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartInteger value);
    
    void CChartStyleItemSetStyleValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartStyle * styleValue);
    
    void CChartStyleItemSetRectValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartRelativeRect rect);
    
    void CChartStyleItemSetPtrValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,void * ptrValue);
    
#ifdef __cplusplus
}
#endif

#endif
