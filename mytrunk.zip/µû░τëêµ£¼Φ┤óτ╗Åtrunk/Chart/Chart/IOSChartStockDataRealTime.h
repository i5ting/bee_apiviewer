//
//  IOSChartStockDataRealTime.h
//  Chart
//
//  Created by zhang hailong on 13-5-17.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <Chart/Chart.h>

@interface IOSChartStockDataRealTime : IOSChartStockData

@property(nonatomic,retain) IBOutlet id source;

@end
