//
//  CChartStockData.h
//  Chart
//
//  Created by zhang hailong on 13-5-14.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef Chart_CChartStockData_h
#define Chart_CChartStockData_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>
#include <Chart/CChartStockAdjust.h>
    
#define CCHART_STOCK_DATA_VERSION 0x0001
    
    typedef enum _CChartStockDataPropertyType {
        CChartStockDataPropertyTypeValue            // 主要价格 price , close
        ,CChartStockDataPropertyTypePrice           // 辅助价格 avg_price, open ,low, high
        ,CChartStockDataPropertyTypeVolume          // 成交量
        ,CChartStockDataPropertyTypeDate
        ,CChartStockDataPropertyTypeTime
        ,CChartStockDataPropertyTypeDateTime
        ,CChartStockDataPropertyTypeValueMa         // 主要价格MA值
        ,CChartStockDataPropertyTypeVolumeMa        // 成交量MA值
    } CChartStockDataPropertyType;
    
    typedef struct _CChartStockDataProperty{
        char name[64];
        CChartStockDataPropertyType type;
        CChartUInteger size;
        CChartUInteger value;
        CChartUInteger offset;
    } CChartStockDataProperty;
    
    
    typedef void * CChartStockDataItem;
    
    typedef struct _CChartStockData{
        void * data;
        CChartStockDataProperty * propertys;
        CChartUInteger propertyCount;
        CChartUInteger itemSize;
        CChartFloat preValue;
        CChartUInteger size;
        CChartInteger location;
        CChartUInteger length;
        CChartFloat minValue;
        CChartFloat maxValue;
        CChartFloat minVolume;
        CChartFloat maxVolume;
        CChartFloat minFullValue;  // has ma
        CChartFloat maxFullValue;  // has ma
        CChartFloat minFullVolume;  // has ma
        CChartFloat maxFullVolume;  // has ma
        CChartUInteger minValueIndex;
        CChartUInteger maxValueIndex;
        CChartStockAdjustResults valueAdjust;
        CChartStockAdjustResults volumeAdjust;
        struct {
            CChartUInteger count;
            CChartInteger months;
            CChartInteger days;
        } columns;
    } CChartStockData;

    CChartStockDataProperty * CChartStockDataGetProperty(CChartStockData * const data,CChartString name);
    
    CChartFloat CChartStockDataPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartFloat defaultValue);
    
    CChartDate CChartStockDataPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDate defaultValue);
    
    CChartTime CChartStockDataPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartTime defaultValue);
    
    CChartDateTime CChartStockDataPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDateTime defaultValue);
    
    
    void CChartStockDataSetPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartFloat value);
    
    void CChartStockDataSetPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDate value);
    
    void CChartStockDataSetPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartTime value);
    
    void CChartStockDataSetPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDateTime);
 
    CChartStockDataItem CChartStockDataItemAtIndex(CChartStockData * const data,CChartInteger index);
    
    CChartFloat CChartStockDataItemPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartFloat defaultValue);
    
    CChartDate CChartStockDataItemPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDate defaultValue);
    
    CChartTime CChartStockDataItemPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartTime defaultValue);
    
    CChartDateTime CChartStockDataItemPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDateTime defaultValue);
    
    
    void CChartStockDataItemSetPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartFloat value);
    
    void CChartStockDataItemSetPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDate value);
    
    void CChartStockDataItemSetPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartTime value);
    
    void CChartStockDataItemSetPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDateTime);
    
    
    void CChartStockDataCreate(CChartStockData * const data,CChartStockDataProperty * propertys,CChartUInteger propertyCount);
    
    void CChartStockDataDelete(CChartStockData * const data);
    
    void CChartStockDataSetDataSize(CChartStockData * const data,CChartUInteger size);
    
    void CChartStockDataSetRange(CChartStockData * const data,CChartInteger location,CChartUInteger length,CChartUInteger columns);
    
    CChartFloat CChartStockDataXValue(CChartStockData * const data,CChartInteger index);
    
    CChartFloat CChartStockDataYValue(CChartStockData * const data,CChartFloat value);
    
    CChartFloat CChartStockDataYVolume(CChartStockData * const data,CChartFloat volume);
    
    CChartBoolean CChartStockDataLoadFile(CChartStockData * const data,CChartString filePath);
    
    CChartBoolean CChartStockDataSaveFile(CChartStockData * const data,CChartString filePath);
    
    CChartBoolean CChartStockDataFileValidate(CChartString filePath);
    
#ifdef __cplusplus
}
#endif

#endif
