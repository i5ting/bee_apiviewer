//
//  CChartStockAdjust.h
//  Chart
//
//  Created by zhang hailong on 13-5-16.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef Chart_CChartStockAdjust_h
#define Chart_CChartStockAdjust_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>

    typedef struct _CChartStockAdjustResults{
        CChartFloat min;
        CChartFloat max;
        CChartUInteger count;
    } CChartStockAdjustResults;
 
    CChartStockAdjustResults CChartStockAdjust(CChartFloat min,CChartFloat max,CChartFloat round,CChartBoolean isVolume);
    
    
#ifdef __cplusplus
}
#endif


#endif
