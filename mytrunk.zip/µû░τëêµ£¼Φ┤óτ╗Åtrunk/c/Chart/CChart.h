//
//  CChart.h
//  CChart
//
//  Created by zhang hailong on 13-5-6.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef CChart_CChart_h
#define CChart_CChart_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#ifdef ANDROID

#include <android/log.h>

#define CLOG(s) __android_log_print(ANDROID_LOG_DEBUG,"chart",s)

#else

#define CLOG(s) printf("%s",s)

#endif

#ifndef MIN
#define	MIN(a,b) (((a)<(b))?(a):(b))
#endif /* MIN */
#ifndef MAX
#define	MAX(a,b) (((a)>(b))?(a):(b))
#endif
    
#define CCHART_NAN  -1
    
    
    typedef float CChartFloat;
    typedef double CChartDouble;
    typedef int CChartInteger;
    typedef unsigned int CChartUInteger;
    typedef long long CChartInt64;
    typedef int CChartBoolean;
    typedef const char * CChartString;
    typedef void * CChartDataObject;
    
    extern CChartBoolean CChartTrue;
    extern CChartBoolean CChartFalse;
    
    typedef struct _CChartTime {
        short hour;
        short minute;
        int second;
    } CChartTime;
    
    CChartTime CChartTimeAdd(CChartTime time,CChartTime add);
    
    CChartBoolean CChartTimeEqual(CChartTime time1,CChartTime time2);
    
    typedef struct _CChartDate {
        short year;
        short month;
        short day;
        short week;
    } CChartDate;
    
    typedef struct _CChartDateTime {
        CChartDate date;
        CChartTime time;
    } CChartDateTime;
    
    extern CChartDateTime CChartDateTimeEmpty;
    
    enum {
        CChartDateTimeUnitNone = 0,
        CChartDateTimeUnitYear      = 1 << 0,
        CChartDateTimeUnitMonth     = 1 << 1,
        CChartDateTimeUnitDay       = 1 << 2,
        CChartDateTimeUnitWeek      = 1 << 3,
        CChartDateTimeUnitHour      = 1 << 4,
        CChartDateTimeUnitMinute    = 1 << 5,
        CChartDateTimeUnitSecond    = 1 << 6,
        CChartDateTimeUnitDate      = 0x07,
        CChartDateTimeUnitTime      = 0x70,
        CChartDateTimeUnitDateTime  = 0xff,
    };
    
    typedef CChartUInteger CChartDateTimeUnit;
    
    CChartBoolean CChartDateTimeEqual(CChartDateTime datetime1,CChartDateTime datetime2,CChartDateTimeUnit unit);
    
    CChartBoolean CChartDateTimeIsEmpty(CChartDateTime datetime);
    
    CChartInteger CChartDataTimeCompare(CChartDateTime datetime1,CChartDateTime datetime2,CChartDateTimeUnit unit);
    
    struct _CChart;
    struct _CChartContext;

    typedef struct _CChartColor{
        CChartFloat r,g,b,a;
    } CChartColor;

    typedef struct _CChartPoint{
        CChartFloat x;
        CChartFloat y;
    } CChartPoint;
    
    typedef struct _CChartSize{
        CChartFloat width;
        CChartFloat height;
    } CChartSize;
    
    typedef struct _CChartRect{
        CChartPoint origin;
        CChartSize size;
    } CChartRect;
    
    typedef struct _CChartInset {
        CChartFloat left;
        CChartFloat top;
        CChartFloat right;
        CChartFloat bottom;
    } CChartInset;
    
    typedef struct _CChartRelativeRect{
        CChartInset inset;
        CChartSize size;
    } CChartRelativeRect;
    
    typedef struct _CChartFloatList{
        CChartFloat * values;
        CChartUInteger length;
    } CChartFloatList;
    
    typedef struct _CChartPointList{
        CChartPoint * values;
        CChartUInteger length;
    } CChartPointList;
    
    typedef void (* CChartDraw) (struct _CChartContext * context,struct _CChart * chart,CChartRect rect);

    typedef struct _CChartViewport{
        CChartFloat width;
        CChartFloat height;
    } CChartViewport;

    typedef struct _CChartContext{
        CChartViewport viewport;
        CChartFloat scale;
        struct  {
            void * data;
            CChartUInteger length;
        } buffer;
        CChartBoolean needRender;
        struct {
            CChartUInteger length;
            unsigned int texture;
            void * data;
        } label;
        void * loader;
    } CChartContext;

    typedef struct _CChartClass{
        CChartDraw draw;
        CChartUInteger size;
    } CChartClass;

    typedef struct _CChart{
        CChartClass * clazz;
    } CChart;

    typedef struct _CChartPath{
        CChartPoint * points;
        CChartUInteger length;
    } CChartPath;

    typedef struct _CChartLine{
        CChart base;
        CChartPath path;
        CChartFloat width;
        CChartColor color;
    } CChartLine;

    typedef struct _CChartPillar{
        CChart base;
        CChartPoint location;
        CChartFloat width;
        CChartColor color;
    } CChartPillar;
    
    typedef struct _CChartFocus{
        CChart base;
        CChartPoint location;
        CChartFloat radius;
        CChartColor color;
    } CChartFocus;
    
    typedef struct _CChartFill{
        CChart base;
        CChartColor color;
    } CChartFill;
    
    typedef struct _CChartBorder{
        CChart base;
        CChartFloat width;
        CChartColor color;
    } CChartBorder;
    
    typedef struct _CChartKLine{
        CChart base;
        CChartPoint location;       // 收盘
        CChartFloat source;         // 开盘
        CChartFloat max;            // 最大
        CChartFloat min;            // 最小
        CChartFloat width;
        CChartColor color;
    } CChartKLine;
    
    typedef struct _CChartFillPath{
        CChart base;
        CChartPath path;
        CChartFloat toValue;
        CChartColor fromColor;
        CChartColor toColor;
    } CChartFillPath;
    
    typedef enum _CChartLabelMode {
        CChartLabelModeCenter = 0
        ,CChartLabelModeLeft = 1 << 0
        ,CChartLabelModeRight = 1 << 1
        ,CChartLabelModeTop = 1 << 2
        ,CChartLabelModeBottom = 1 << 3
        ,CChartLabelModeHorizontal = 1 << 4
        ,CChartLabelModeVertical = 1 << 5
    } CChartLabelMode;
    
    typedef struct _CChartLabel{
        CChart base;
        CChartPoint location;
        CChartLabelMode mode;
        CChartFloat fontSize;
        CChartColor color;
        CChartString text;
    } CChartLabel;
    
    typedef struct _CChartTipLabel {
        CChart base;
        CChartPoint location;
        CChartLabelMode mode;
        CChartFloat fontSize;
        CChartColor color;
        CChartString text;
        CChartColor lineColor;
        CChartColor fillColor;
        CChartFloat lineWidth;
        CChartFloat distance;
    } CChartTipLabel;

    CChartPoint CChartPointMake(CChartFloat x,CChartFloat y);

    CChartSize CChartSizeMake(CChartFloat width,CChartFloat height);

    CChartRect CChartRectMake(CChartFloat x,CChartFloat y,CChartFloat width,CChartFloat height);
    
    CChartRect CChartRectMakeRelative(CChartRect frame,CChartRelativeRect rect);

    CChartBoolean CChartRectEqual(CChartRect rect1,CChartRect rect2);
    
    CChartFloat CChartContextRelativeOfWidth(CChartContext * context,CChartFloat value);

    CChartFloat CChartContextRelativeOfHeight(CChartContext * context,CChartFloat value);

    CChartPoint CChartContextRelativePoint(CChartContext * context,CChartPoint value);
    
    CChartSize CChartContextRelativeSize(CChartContext * context,CChartSize value);

    CChartFloat CChartContextAbsoluteOfWidth(CChartContext * context,CChartFloat value);

    CChartFloat CChartContextAbsoluteOfHeight(CChartContext * context,CChartFloat value);

    CChartPoint CChartContextAbsolutePoint(CChartContext * context,CChartPoint value);
    
    void CChartFloatToString(CChartFloat value,char * text);
    
    void CChartDateTimeToString(CChartDateTime datetime,CChartDateTimeUnit unit, char * text);
    
    void CChartContextCleanup(CChartContext * context);

    void CChartContextSetBufferLength(CChartContext * context,CChartUInteger length);

    void CChartContextDraw(CChartContext * context,CChart * chart,CChartRect rect);
    
    extern CChartClass CChartLineClass;

    extern CChartClass CChartPillarClass;

    extern CChartClass CChartFocusClass;
    
    extern CChartClass CChartFillClass;
    
    extern CChartClass CChartBorderClass;
    
    extern CChartClass CChartKLineClass;
    
    extern CChartClass CChartFillPathClass;
    
    extern CChartClass CChartLabelClass;
    
    extern CChartClass CChartTipLabelClass;
    
    extern CChartSize CChartLabelSize(CChartString text,CChartFloat fontSize);

#ifdef __cplusplus
}
#endif

#endif
