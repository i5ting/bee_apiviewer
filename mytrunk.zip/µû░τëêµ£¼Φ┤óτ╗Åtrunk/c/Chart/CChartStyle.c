//
//  CChartStyle.c
//  Chart
//
//  Created by zhang hailong on 13-5-15.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#define READONLY

#include "CChartStyle.h"

void CChartStyleClassInitialize(CChartStyleClass * const styleClass){
    
    CChartStyleProperty * prop = (CChartStyleProperty *)styleClass->propertys;
    CChartUInteger length = styleClass->propertyCount;
    
    styleClass->size = 0;

    while(length >0){
        
        prop->offset = styleClass->size;
        styleClass->size += prop->length;
        prop ++;
        length --;
    }
}


void CChartStyleClassUninstall(CChartStyleClass * const styleClass){
    memset(styleClass, 0, sizeof(CChartStyleClass));
}

CChartStyleProperty * CChartStyleClassGetProperty(const CChartStyleClass * styleClass,CChartString name){
    int c = styleClass->propertyCount;
    CChartStyleProperty * prop = (CChartStyleProperty *)styleClass->propertys;
    while(c >0){
        
        if(prop->name == name || strcmp(prop->name, name) ==0){
            return prop;
        }
        prop ++;
        c --;
    }
    return NULL;
}

void CChartStyleCreate(CChartStyle * const style,const CChartStyleClass * styleClass,CChartUInteger length){
    if(styleClass && length){
        memset(style, 0, sizeof(CChartStyle));
        style->clazz = styleClass;
        style->data = malloc(styleClass->size * length);
        style->length = length;
        memset(style->data, 0, styleClass->size * length);
    }
}

void CChartStyleDelete(CChartStyle * const style){
    if(style && style->clazz && style->data){
        int i;
        CChartStyleItem item;
        CChartStyleProperty * prop;
        int c ;
        for(i=0;i<style->length;i++){
            item = CChartStyleItemAtIndex(style,i);
            prop = (CChartStyleProperty *)style->clazz->propertys;
            c = style->clazz->propertyCount;
            while(c >0){
                if(prop->type == CChartStylePropertyTypeStyle){
                    CChartStyleDelete(CChartStyleItemStyleValue(style,item,prop));
                }
                c ++;
            }
        }
        free(style->data);
        memset(style, 0, sizeof(CChartStyle));
    }
}

CChartStyleItem CChartStyleItemAtIndex(CChartStyle * const style,CChartInteger index){
    if(index >=0 && index < style->length){
        return (char *) style->data + style->clazz->size * index;
    }
    return NULL;
}

CChartFloat CChartStyleItemFloatValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartFloat defaultValue){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeFloat:
                return * (CChartFloat *) ((char *) item + prop->offset);
                break;
            case CChartStylePropertyTypeInteger:
                return * (CChartInteger *) ((char *) item + prop->offset);
                break;
            case CChartStylePropertyTypeString:
            {
                return atof((CChartString) ((char *) item + prop->offset));
            }
                break;
            default:
                break;
        }
    }
    return defaultValue;
}

CChartColor CChartStyleItemColorValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop){
    CChartColor c = {0.0f,0.0f,0.0f,0.0f};
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeColor:
                return * (CChartColor *) ((char *) item + prop->offset);
                break;
            case CChartStylePropertyTypeString:
            {
                CChartString v = (CChartString) ((char *) item + prop->offset);
                CChartInteger r = 0,g = 0,b = 0;
                CChartFloat a = 1.0f;

                sscanf(v, "#%02x%02x%02x %f",&r,&g,&b,&a);
                
                c.r = r / 255.0f;
                c.g = g / 255.0f;
                c.b = b / 255.0f;
                c.a = a;
                return c;
            }
                break;
            default:
                break;
        }
    }
    return c;
}

CChartString CChartStyleItemStringValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartString defaultValue){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeString:
            {
                return (CChartString) ((char *) item + prop->offset);
            }
                break;
            default:
                break;
        }
    }
    return defaultValue;
}

CChartInteger CChartStyleItemIntValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartInteger defaultValue){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeFloat:
                return * (CChartFloat *) ((char *) item + prop->offset);
                break;
            case CChartStylePropertyTypeInteger:
                return * (CChartInteger *) ((char *) item + prop->offset);
                break;
            case CChartStylePropertyTypeString:
            {
                return atoi((CChartString) ((char *) item + prop->offset));
            }
                break;
            default:
                break;
        }
    }
    return defaultValue;
}

CChartStyle * CChartStyleItemStyleValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeStyle:
            {
                return (CChartStyle *) ((char *) item + prop->offset);
            }
                break;
            default:
                break;
        }
    }
    return NULL;
}

CChartRelativeRect CChartStyleItemRectValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop){
    CChartRelativeRect r = {0};
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeRect:
                return * (CChartRelativeRect *) ((char *) item + prop->offset);
                break;
            default:
                break;
        }
    }
    return r;
}

void * CChartStyleItemPtrValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypePtr:
                return * (void * *) ((char *) item + prop->offset);
                break;
            default:
                break;
        }
    }
    return NULL;
}


void CChartStyleItemSetFloatValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartFloat value){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeFloat:
                * (CChartFloat *) ((char *) item + prop->offset) = value;
                break;
            case CChartStylePropertyTypeInteger:
                * (CChartInteger *) ((char *) item + prop->offset) = (CChartInteger) value;
                break;
            case CChartStylePropertyTypeString:
            {
                snprintf(((char *) item + prop->offset), prop->length,"%f",value);
            }
                break;
            default:
                break;
        }
    }
}

void CChartStyleItemSetColorValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartColor value){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeColor:
                * (CChartColor *) ((char *) item + prop->offset) = value;
                break;
            case CChartStylePropertyTypeString:
            {
                snprintf(((char *) item + prop->offset), prop->length,"#%02x%02x%02x %f"
                         ,(CChartInteger)(value.r * 0xff)
                         ,(CChartInteger)(value.g * 0xff)
                         ,(CChartInteger)(value.b * 0xff),value.a);
            }
                break;
            default:
                break;
        }
    }
}

void CChartStyleItemSetStringValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartString value){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeFloat:
                * (CChartFloat *) ((char *) item + prop->offset) = atof(value ? value : "0");
                break;
            case CChartStylePropertyTypeInteger:
                * (CChartInteger *) ((char *) item + prop->offset) = atoi(value ? value : "0");
                break;
            case CChartStylePropertyTypeColor:
            {
                CChartInteger r = 0,g = 0,b = 0;
                CChartFloat a = 1.0f;
                CChartColor c;
                
                sscanf(value ? value : "", "#%02x%02x%02x %f",&r,&g,&b,&a);
                
                c.r = r / 255.0f;
                c.g = g / 255.0f;
                c.b = b / 255.0f;
                c.a = a;
                
                * (CChartColor *) ((char *) item + prop->offset) = c;
            }
                break;
            case CChartStylePropertyTypeString:
            {
                strncpy(((char *) item + prop->offset), value ? value : "", prop->length);
            }
                break;
            case CChartStylePropertyTypeRect:
            {
                CChartRelativeRect r=  {0};
                sscanf(value ? value : "", "{{%f,%f,%f,%f},{%f,%f}}",&r.inset.left,&r.inset.top,&r.inset.right,&r.inset.bottom,&r.size.width,&r.size.height);
                * (CChartRelativeRect *) ((char *) item + prop->offset) = r;
            }
                break;
            default:
                break;
        }
    }
}

void CChartStyleItemSetIntValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartInteger value){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeFloat:
                * (CChartFloat *) ((char *) item + prop->offset) = value;
                break;
            case CChartStylePropertyTypeInteger:
                * (CChartInteger *) ((char *) item + prop->offset) = value;
                break;
            case CChartStylePropertyTypeString:
            {
                snprintf(((char *) item + prop->offset), prop->length,"%d",value);
            }
                break;
            default:
                break;
        }
    }
}

void CChartStyleItemSetStyleValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartStyle * styleValue){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeStyle:
            {
                CChartStyle * v = (CChartStyle *) ((char *) item + prop->offset);
                if(styleValue){
                    * v = * styleValue;
                }
                else{
                    memset(v, 0, sizeof(CChartStyle));
                }
            }
                break;
            default:
                break;
        }
    }
}

void CChartStyleItemSetRectValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,CChartRelativeRect rect){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypeRect:
                * (CChartRelativeRect *) ((char *) item + prop->offset) = rect;
                break;
            default:
                break;
        }
    }
}

void CChartStyleItemSetPtrValue(CChartStyle * const style,CChartStyleItem item,CChartStyleProperty * prop,void * ptrValue){
    if(style && item && prop){
        switch (prop->type) {
            case CChartStylePropertyTypePtr:
                * (void * *) ((char *) item + prop->offset) = ptrValue;
                break;
            default:
                break;
        }
    }
}

