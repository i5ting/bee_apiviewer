//
//  IOSChartStockDataMonthK.h
//  Chart
//
//  Created by zhang hailong on 13-5-20.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <Chart/Chart.h>

@interface IOSChartStockDataMonthK : IOSChartStockData

@property(nonatomic,retain) IBOutlet id source;

@end
