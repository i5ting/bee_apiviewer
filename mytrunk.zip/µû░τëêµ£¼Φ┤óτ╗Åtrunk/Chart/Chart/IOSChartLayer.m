//
//  IOSChartLayer.m
//  IOSChart
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartLayer.h"

#import "IOSChart.h"

@interface IOSChartLayer(){
}

@property(nonatomic,retain) EAGLContext * glContext;
@property(nonatomic,assign) GLuint viewFramebuffer;
@property(nonatomic,assign) GLuint viewRenderbuffer;
@property(nonatomic,assign) BOOL initFinish;

-(void) resize;

@end


@implementation IOSChartLayer

@synthesize cContext = _cContext;
@synthesize glContext = _glContext;
@synthesize viewFramebuffer = _viewFramebuffer;
@synthesize viewRenderbuffer = _viewRenderbuffer;
@synthesize chart = _chart;
@synthesize initFinish = _initFinish;

-(id) init{
    if((self = [super init])) {
        _cContext.scale = 1.0;
        
        
        self.opaque = YES;
        self.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                   [NSNumber numberWithBool:YES], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
        
        _glContext = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
        
        if (!_glContext || ![EAGLContext setCurrentContext:_glContext]) {
            NSLog(@"Failed to initialize OpenGLES context");
            exit(1);
        }
        

        glGenFramebuffers(1, &_viewFramebuffer);
        glGenRenderbuffers(1, &_viewRenderbuffer);
        
        glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
        glEnable(GL_BLEND);
        
        glEnable(GL_LINE_SMOOTH);
        
        glEnable(GL_POINT_SMOOTH);
        
        glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
        
        glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);

        
        [self resize];
    }
    return self;
}

-(void) resize{
    
    CGSize size = self.bounds.size;

    GLint width = size.width;
    GLint height = size.height;
    
    if(width >0 && height >0){
        
        glBindRenderbuffer(GL_RENDERBUFFER, _viewRenderbuffer);
        [_glContext renderbufferStorage:GL_RENDERBUFFER fromDrawable:self];
        glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &width);
        glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &height);
        
        glBindFramebuffer(GL_FRAMEBUFFER, _viewFramebuffer);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, _viewRenderbuffer);
        
        if(glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        {
            //NSLog(@"Failure with framebuffer generation");
            _initFinish = NO;
        }
        else{
            _initFinish = YES;
        }
        
        glBindRenderbuffer(GL_RENDERBUFFER, _viewRenderbuffer);
        
        _cContext.viewport.width = width;
        _cContext.viewport.height = height;
        
        glViewport(0,0,width,height);
    
        _cContext.needRender = YES;
        
    }
    
}

-(void) setFrame:(CGRect)frame{
    [super setFrame:frame];
    
    CGSize size = self.bounds.size;
    
    if(size.width != _cContext.viewport.width && size.height != _cContext.viewport.height){
        [self resize];
    }
}

-(void) setNeedsRender{
    _cContext.needRender = YES;
}

-(CGFloat) scale{
    return _cContext.scale;
}

-(void) setScale:(CGFloat)scale{
    _cContext.scale = scale;
    _cContext.needRender = YES;
    [self setTransform:CATransform3DMakeScale(scale, scale, scale)];
}

-(void) tick{
    if(_cContext.needRender && _initFinish){
        
        _cContext.needRender = NO;
        
        [EAGLContext setCurrentContext:_glContext];
    
        CGFloat r = 0.0,g = 0.0,b = 0.0,a = 0.0;
        
        if(self.backgroundColor){
            UIColor * color = [UIColor colorWithCGColor:self.backgroundColor];
            [color getRed:&r green:&g blue:&b alpha:&a];
        }
        
        glClearColor(r, g, b, a);
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        
        glLoadIdentity();
        
        glMatrixMode(GL_MODELVIEW);
        
        glTranslatef(-1.0, -1.0, 0.0);
        
        glScalef(2.0, 2.0, -1.0);
        
        [_chart drawChart:&_cContext];
        
        glBindRenderbuffer(GL_RENDERBUFFER, _viewRenderbuffer);
        [_glContext presentRenderbuffer:GL_RENDERBUFFER];
        
    }
}

-(void) dealloc{
    [_chart release];
    if(_viewFramebuffer){
        glDeleteFramebuffers(1, &_viewFramebuffer);
    }
    if(_viewRenderbuffer){
        glDeleteRenderbuffers(1, &_viewRenderbuffer);
    }
    if(_cContext.label.texture){
        glDeleteTextures(1, &_cContext.label.texture);
    }
    [_glContext release];
    if(_cContext.label.data){
        free(_cContext.label.data);
    }
    CChartContextCleanup(&_cContext);
    
    [super dealloc];
}

@end
