//
//  ArticleTitleLabel.h
//  SinaFinance
//
//  Created by fabo on 12-10-18.
//
//

#import <UIKit/UIKit.h>

@interface ArticleTitleLabel : UILabel
@property(nonatomic,retain)NSString* firstLine;

@end

@interface ClickURLBtn : UIButton
@property(nonatomic,retain)id data;
@end
