//
//  CChartStockStyle.h
//  Chart
//
//  Created by zhang hailong on 13-5-15.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef Chart_CChartStockStyle_h
#define Chart_CChartStockStyle_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>
#include <Chart/CChartStock.h>
#include <Chart/CChartData.h>

    void CChartStockStyleOpen(CChartStyle * style,CChartDataObject dataObject);
    
#ifdef __cplusplus
}
#endif

#endif
