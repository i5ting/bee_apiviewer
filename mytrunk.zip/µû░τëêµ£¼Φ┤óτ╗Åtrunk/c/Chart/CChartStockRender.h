//
//  CChartStockRender.h
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef CChart_CChartStockRender_h
#define CChart_CChartStockRender_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChartMaker.h>
#include <Chart/CChartStock.h>
    
    typedef struct _CChartStockRender{
        CChartMaker maker;
        CChartMaker dataMaker;
        CChartStock chart;
        CChartContext * context;
        CChartRect rect;
        CChartDataObject * dataObject;
    } CChartStockRender;
    

    void CChartStockRenderDelete(CChartStockRender * const render);
    
    void CChartStockRenderCreate(CChartStockRender * const render,CChartDataObject dataObject);
    
    void CChartStockRenderDataUninstall(CChartStockRender * const render);
    
    void CChartStockRenderDataInstallTimeSharing(CChartStockRender * const render,CChartContext * context,CChartRect rect,CChartDataObject dataObject);
    
    void CChartStockRenderDataInstallKLine(CChartStockRender * const render,CChartContext * context,CChartRect rect,CChartDataObject dataObject,CChartUInteger location,CChartUInteger length);
    
    CChartBoolean CChartStockRenderIsDataInstall(CChartStockRender * const render,CChartContext * context,CChartRect rect,CChartDataObject dataObject);
    
#ifdef __cplusplus
}
#endif


#endif
