//
//  IOSChartStockData.m
//  Chart
//
//  Created by zhang hailong on 13-5-17.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartStockData.h"

@interface IOSChartStockData(){
    CChartStockData _data;
}

@end

@implementation IOSChartStockData


-(CChartStockData *) cData{
    return & _data;
}

-(void) dealloc{
    CChartStockDataDelete(&_data);
    return [super dealloc];
}

@end
