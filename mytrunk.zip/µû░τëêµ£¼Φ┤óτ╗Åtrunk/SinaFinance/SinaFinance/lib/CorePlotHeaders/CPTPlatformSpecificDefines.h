
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef UIImage CPTNativeImage;
