//
//  IOSChartStockDataRealTime.m
//  Chart
//
//  Created by zhang hailong on 13-5-17.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartStockDataRealTime.h"

@implementation IOSChartStockDataRealTime

@synthesize source = _source;

-(void) dealloc{
    [_source release];
    [super dealloc];
}

-(CChartStockData *) cData{
    CChartStockData * data = [super cData];
    if(data->data == NULL){
        
        CChartStockDataProperty propertys[] = {
            {"price",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
            {"avg_price",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
            {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
        };
        
        CChartStockDataCreate(data, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
        
        id items  = [self.source dataObjectForKeyPath:@"result.data.data.min"];
        
        CChartStockDataSetDataSize(data, [items count]);
        
        CChartStockDataProperty * prop;
        int c;
        CChartDateTime timestamp = {0};
        CChartFloat v;
        
        data->preValue = [[self.source dataObjectForKeyPath:@"result.data.data.pre_price"] floatValue];
        
        for( int i=0;i< [items count];i++){
            
            id item = [items valueForKey:[NSString stringWithFormat:@"%d",i +1]];
            
            CChartStockDataItem dataItem = CChartStockDataItemAtIndex(data, i);
            
            prop = data->propertys;
            c  = data->propertyCount;
            
            while(c >0){
                
                if(prop->type == CChartStockDataPropertyTypeDateTime){
                    memset(&timestamp, 0, sizeof(timestamp));
                    NSString * day = [item valueForKey:@"mintime"];
                    if([day isKindOfClass:[NSString class]]){
                        int hour = 0,minute = 0,second = 0;
                        sscanf([day UTF8String], "%d:%d:%d",&hour,&minute,&second);
                        timestamp.time.hour = hour;
                        timestamp.time.minute = minute;
                        timestamp.time.second = second;
                        CChartStockDataItemSetPropertyDateTimeValue(data, prop, dataItem, timestamp);
                    }
                }
                else{
                    v = [[item valueForKey:[NSString stringWithCString:prop->name encoding:NSUTF8StringEncoding]] floatValue];
                    CChartStockDataItemSetPropertyFloatValue(data, prop, dataItem, v);
                }
                
                prop ++;
                c --;
            }
        }
        
        CChartStockDataSetRange(data, 0, 242,5);
    }
    return data;
}


@end
