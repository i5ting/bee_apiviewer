//
//  IOSChartStock.m
//  IOSChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartStock.h"

@interface IOSChartStock(){
    CChartStock _chart;
    CChartStyle _style;
    
    struct {
        int location;
    } scroll;
    
    struct {
        int length;
        int location;
    } scale;
}

@end

@implementation IOSChartStock

@synthesize data = _data;
@synthesize nibLayoutData = _nibLayoutData;
@synthesize disabledScroll = _disabledScroll;
@synthesize disabledScale = _disabledScale;
@synthesize disabledFocus = _disabledFocus;
@synthesize minLength = _minLength;
@synthesize maxLength = _maxLength;
@synthesize plistLayout = _plistLayout;
@synthesize dataSource = _dataSource;

+(void) initialize{
    [super initialize];
    
    CChartStockClassInitialize();
    
}

-(id) init{
    if((self = [super init])){
        _minLength = 20;
        _maxLength = 300;
    }
    return self;
}

-(void) dealloc{
    [_data release];
    [_nibLayoutData release];
    [_plistLayout release];
    CChartStyleDelete(&_style);
    [super dealloc];
}

-(CChartStockData *) loadCData{
    CChartStockData * data = nil;
    
    if(self.data == nil){
        data = [_dataSource IOSChartStockData:self];
    }
    else{
        data = [self.data cData];
    }
    
    return data;
}

-(void) drawChart:(CChartContext *)chartContext{
    
    CChartRect rect = [self frame:chartContext];
    
    CChartStockData * data = [self loadCData];
    
    CChartStyle * style = [self cStyle];
    
    if(_chart.base.clazz == NULL){
        _chart.base.clazz = & CChartStockClass;
    }
    
    if(_chart.data != data || _chart.style != style || _chart.dataPropertys.value == NULL){
        CChartStockDataBind(&_chart, style, data);
    }
    
    CChartContextDraw(chartContext, (CChart *) &_chart, rect);
}


-(CChartStock *) cChart{
    return & _chart;
}

-(CChartStyle *) cStyle{
    if(_style.clazz == NULL){
        if(_nibLayoutData == nil){
            if(_plistLayout){
                NSPropertyListFormat  format = NSPropertyListBinaryFormat_v1_0;
                self.nibLayoutData = [NSPropertyListSerialization propertyListFromData:[NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:_plistLayout ofType:@"plist"]] mutabilityOption:NSPropertyListMutableContainersAndLeaves format:&format errorDescription:nil];
            }
        }
        [self loadLayoutData:_nibLayoutData];
    }
    return & _style;
}

-(void) loadLayoutData:(id) layoutData{
    CChartStockStyleOpen(&_style, (CChartDataObject)layoutData);
}


-(void) scrollBegin{
    CChartStockData * data = [self loadCData];
    if(data && !_disabledScroll){
        scroll.location = data->location;
    }
}

-(void) scrollValueChanged:(CGPoint) value{
    CChartStockData * data = [self loadCData];
    
    if(data == NULL || _disabledScroll){
        return;
    }
    
    int location = scroll.location - value.x * data->length;
    if(location <0){
        location = 0;
    }
    if(location + data->length > data->size){
        location = data->size - data->length;
    }
    if(location != data->location){
        
        CChartStockDataSetRange(data, location, data->length, 5);
        
        if([self.delegate respondsToSelector:@selector(IOSChartSetNeedRender:)]){
            [self.delegate IOSChartSetNeedRender:self];
        }
    }
}

-(void) focusBegin:(CGPoint) value{
    
    CChartStockData * data = [self loadCData];
    
    if(data == NULL || _disabledFocus){
        return;
    }
    
    CChartStock * chart = [self cChart];
    chart->focusLocation = CChartPointMake(value.x, value.y);
    if([self.delegate respondsToSelector:@selector(IOSChartSetNeedRender:)]){
        [self.delegate IOSChartSetNeedRender:self];
    }
}

-(void) focusValueChanged:(CGPoint) value{
    
    CChartStockData * data = [self loadCData];
    
    if(data == NULL || _disabledFocus){
        return;
    }
    
    CChartStock * chart = [self cChart];
    chart->focusLocation = CChartPointMake(value.x, value.y);
    if([self.delegate respondsToSelector:@selector(IOSChartSetNeedRender:)]){
        [self.delegate IOSChartSetNeedRender:self];
    }
}

-(void) focusEnd{
    
    CChartStockData * data = [self loadCData];
    
    if(data == NULL || _disabledFocus){
        return;
    }
    
    CChartStock * chart = [self cChart];
    chart->focusLocation = CChartPointMake(-1.0f, -1.0f);
    if([self.delegate respondsToSelector:@selector(IOSChartSetNeedRender:)]){
        [self.delegate IOSChartSetNeedRender:self];
    }
}

-(void) scaleBegin{
    CChartStockData * data = [self loadCData];
    
    if(data == NULL || _disabledScale){
        return;
    }
    
    scale.length = data->length;
    scale.location = data->location;
}

-(void) scaleValueChanged:(CGFloat) value{
    
    CChartStockData * data = [self loadCData];
    
    if(data == NULL || _disabledScale){
        return;
    }
    
    int length = scale.length / value;
    
    if(length < _minLength){
        length = _minLength;
    }
    
    
    if(length > _maxLength){
        length = _maxLength;
    }
    
    int location = scale.location + scale.length - length;
    
    if(location <0){
        location =0;
    }
    
    if(location + length > data->size){
        location = data->size - length;
    }
    

    if(location != data->location || data->length != length){
        
        CChartStockDataSetRange(data, location, length, 5);
        
        if([self.delegate respondsToSelector:@selector(IOSChartSetNeedRender:)]){
            [self.delegate IOSChartSetNeedRender:self];
        }
    }
}


@end
