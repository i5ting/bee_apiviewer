//
//  IOSChartStockDataMonthK.m
//  Chart
//
//  Created by zhang hailong on 13-5-20.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartStockDataMonthK.h"

@interface IOSChartStockDataMonthK(){
    NSDateFormatter * _dateFormatter;
}

@end

@implementation IOSChartStockDataMonthK

@synthesize source = _source;

-(id) init{
    if((self = [super init])){
        _dateFormatter = [[NSDateFormatter alloc] init];
    }
    return self;
}

-(void) dealloc{
    [_source release];
    [_dateFormatter release];
    [super dealloc];
}

-(CChartStockData *) cData{
    CChartStockData * data = [super cData];
    
    if(data->data == NULL){
        
        CChartStockDataProperty propertys[] = {
            {"close",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
            {"open",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"low",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"high",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
            {"ma5",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),5},
            {"ma10",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),10},
            {"ma30",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),30},
            {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
        };
        
        CChartStockDataCreate(data, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
        
        struct {
            CChartStockDataProperty * close;
            CChartStockDataProperty * open;
            CChartStockDataProperty * low;
            CChartStockDataProperty * high;
            CChartStockDataProperty * volume;
            CChartStockDataProperty * timestamp;
        } Propertys = {
            CChartStockDataGetProperty(data, "close"),
            CChartStockDataGetProperty(data, "open"),
            CChartStockDataGetProperty(data, "low"),
            CChartStockDataGetProperty(data, "high"),
            CChartStockDataGetProperty(data, "volume"),
            CChartStockDataGetProperty(data, "timestamp"),
        };
        
        NSArray * items  = [self.source dataObjectForKeyPath:@"result.data.data"];
        
        CChartStockDataSetDataSize(data, [items count]);
        
        int size = 0;
        CChartDateTime timestamp = {0};
        
        NSCalendar * calendar = [NSCalendar currentCalendar];
        
        [_dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"];
        
        struct {
            CChartFloat close;
            CChartFloat open;
            CChartFloat low;
            CChartFloat high;
            CChartFloat volume;
            CChartDateTime timestamp;
        } Value = {CCHART_NAN,CCHART_NAN,CCHART_NAN,CCHART_NAN,CCHART_NAN,CChartDateTimeEmpty};
        
        CChartFloat v;
        
        for( int i=0;i<[items count];i++){
            
            id item = [items objectAtIndex:i];
            
            CChartStockDataItem dataItem = CChartStockDataItemAtIndex(data, size);
            
            NSString * day = [item valueForKey:@"date"];
            if([day isKindOfClass:[NSString class]]){
                
                NSDate * date = [_dateFormatter dateFromString:day];
                NSDateComponents * comp = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit fromDate:date];
                
                timestamp.date.year = comp.year;
                timestamp.date.month = comp.month;
                timestamp.date.day = comp.day;
                timestamp.date.week = comp.weekday;
                
                v = [[item valueForKey:@"open"] floatValue];
                
                if(Value.open == CCHART_NAN){
                    
                    Value.open = v;
                    Value.close = [[item valueForKey:@"close"] floatValue];
                    Value.timestamp = timestamp;
                    
                    v = [[item valueForKey:@"low"] floatValue];
                    
                    if(Value.low == CCHART_NAN){
                        Value.low = v;
                    }
                    else if(v < Value.low){
                        Value.low = v;
                    }
                    
                    v = [[item valueForKey:@"high"] floatValue];
                    
                    if(Value.high == CCHART_NAN){
                        Value.high = v;
                    }
                    else if(v > Value.high){
                        Value.high = v;
                    }
                    
                    v = [[item valueForKey:@"volume"] floatValue];
                    
                    if(Value.volume == CCHART_NAN){
                        Value.volume = v;
                    }
                    else{
                        Value.volume += v;
                    }
                    
                }
                else if(Value.timestamp.date.day < timestamp.date.day){
                    
                    v = [[item valueForKey:@"low"] floatValue];
                    
                    if(Value.low == CCHART_NAN){
                        Value.low = v;
                    }
                    else if(v < Value.low){
                        Value.low = v;
                    }
                    
                    v = [[item valueForKey:@"high"] floatValue];
                    
                    if(Value.high == CCHART_NAN){
                        Value.high = v;
                    }
                    else if(v > Value.high){
                        Value.high = v;
                    }
                    
                    v = [[item valueForKey:@"volume"] floatValue];
                    
                    if(Value.volume == CCHART_NAN){
                        Value.volume = v;
                    }
                    else{
                        Value.volume += v;
                    }
                    
                    Value.close = [[item valueForKey:@"close"] floatValue];
                    Value.timestamp = timestamp;
                }
                else {
                    
                    CChartStockDataItemSetPropertyFloatValue(data, Propertys.close, dataItem, Value.close);
                    CChartStockDataItemSetPropertyFloatValue(data, Propertys.open, dataItem, Value.open);
                    CChartStockDataItemSetPropertyFloatValue(data, Propertys.low, dataItem, Value.low);
                    CChartStockDataItemSetPropertyFloatValue(data, Propertys.high, dataItem, Value.high);
                    CChartStockDataItemSetPropertyFloatValue(data, Propertys.volume, dataItem, Value.volume);
                    CChartStockDataItemSetPropertyDateTimeValue(data, Propertys.timestamp, dataItem, Value.timestamp);
                    
                    size ++;
                    
                    Value.open = v;
                    Value.close = [[item valueForKey:@"close"] floatValue];
                    Value.timestamp = timestamp;
                    Value.low = [[item valueForKey:@"low"] floatValue];
                    Value.high = [[item valueForKey:@"high"] floatValue];
                    Value.volume = [[item valueForKey:@"volume"] floatValue];
                }
                
            }
            
        }
        
        if(Value.open != CCHART_NAN){
            CChartStockDataItem dataItem = CChartStockDataItemAtIndex(data, size);
            CChartStockDataItemSetPropertyFloatValue(data, Propertys.close, dataItem, Value.close);
            CChartStockDataItemSetPropertyFloatValue(data, Propertys.open, dataItem, Value.open);
            CChartStockDataItemSetPropertyFloatValue(data, Propertys.low, dataItem, Value.low);
            CChartStockDataItemSetPropertyFloatValue(data, Propertys.high, dataItem, Value.high);
            CChartStockDataItemSetPropertyFloatValue(data, Propertys.volume, dataItem, Value.volume);
            CChartStockDataItemSetPropertyDateTimeValue(data, Propertys.timestamp, dataItem, Value.timestamp);
            size ++;
        }
        
        CChartStockDataSetDataSize(data, size);
        
        if(size >100){
            CChartStockDataSetRange(data, size - 100, 100,5);
        }
        else{
            CChartStockDataSetRange(data, 0, size,5);
        }
        
    }
    return data;
}

@end
