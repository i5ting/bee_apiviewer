//
//  StockChartDataSource.m
//  SinaFinance
//
//  Created by zhang hailong on 13-6-24.
//
//

#import "StockChartDataSource.h"




@interface StockChartDataSource(){
    CChartStockData _realtime;
    CChartStockData _day5;
    CChartStockData _dayK;
    CChartStockData _monthK;
    CChartStockData _weekK;
    NSDateFormatter * _dateFormatter;
}

-(NSString *) dbPathForSymbol:(NSString *) symbol extension:(NSString *) extension;

@end

@implementation StockChartDataSource

-(id) init{
    if((self = [super init])){
        _dateFormatter = [[NSDateFormatter alloc] init];
    }
    return self;
}

-(void) dealloc{
    CChartStockDataDelete(&_realtime);
    CChartStockDataDelete(&_day5);
    CChartStockDataDelete(&_dayK);
    CChartStockDataDelete(&_monthK);
    CChartStockDataDelete(&_weekK);
    [_dateFormatter release];
    [super dealloc];
}

-(void) reset{
    CChartStockDataDelete(&_realtime);
    CChartStockDataDelete(&_day5);
    CChartStockDataDelete(&_dayK);
    CChartStockDataDelete(&_monthK);
    CChartStockDataDelete(&_weekK);
}

-(CChartStockData *) realtime:(NSString *) symbol{
    return & _realtime;
}

-(CChartStockData *) day5:(NSString *) symbol{
    return & _day5;
}

-(CChartStockData *) dayK:(NSString *) symbol{

    if(_dayK.itemSize == 0){
        
        NSString * dbPath = [self dbPathForSymbol:symbol extension:@"dayk"];
        if(!CChartStockDataLoadFile(&_dayK, [dbPath UTF8String])){
            CChartStockDataDelete(&_dayK);
        }
        else{
            if(_dayK.size >100){
                CChartStockDataSetRange(&_dayK, _dayK.size - 100, 100,5);
            }
            else{
                CChartStockDataSetRange(&_dayK, 0, _dayK.size,5);
            }
        }
    }

    return & _dayK;
}

-(CChartStockData *) year:(NSString *) symbol{

    return [self dayK:symbol];
}

-(CChartStockData *) weekK:(NSString *) symbol{
    
    if(_weekK.itemSize == 0){
        
        NSString * dbPath = [self dbPathForSymbol:symbol extension:@"weekk"];
        if(!CChartStockDataLoadFile(&_weekK, [dbPath UTF8String])){
            CChartStockDataDelete(&_weekK);
            
            CChartStockData * dayK = [self dayK:symbol];
            
            if(dayK->itemSize && dayK->size){
                
                CChartStockDataProperty propertys[] = {
                    {"close",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
                    {"open",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
                    {"low",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
                    {"high",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
                    {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
                    {"ma5",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),5},
                    {"ma10",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),10},
                    {"ma30",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),30},
                    {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
                };
                
                CChartStockDataCreate(&_weekK, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
                
                struct {
                    CChartStockDataProperty * close;
                    CChartStockDataProperty * open;
                    CChartStockDataProperty * low;
                    CChartStockDataProperty * high;
                    CChartStockDataProperty * volume;
                    CChartStockDataProperty * timestamp;
                } Propertys = {
                    CChartStockDataGetProperty(&_weekK, "close"),
                    CChartStockDataGetProperty(&_weekK, "open"),
                    CChartStockDataGetProperty(&_weekK, "low"),
                    CChartStockDataGetProperty(&_weekK, "high"),
                    CChartStockDataGetProperty(&_weekK, "volume"),
                    CChartStockDataGetProperty(&_weekK, "timestamp"),
                };
                
                struct {
                    CChartStockDataProperty * close;
                    CChartStockDataProperty * open;
                    CChartStockDataProperty * low;
                    CChartStockDataProperty * high;
                    CChartStockDataProperty * volume;
                    CChartStockDataProperty * timestamp;
                } DayPropertys = {
                    CChartStockDataGetProperty(dayK, "close"),
                    CChartStockDataGetProperty(dayK, "open"),
                    CChartStockDataGetProperty(dayK, "low"),
                    CChartStockDataGetProperty(dayK, "high"),
                    CChartStockDataGetProperty(dayK, "volume"),
                    CChartStockDataGetProperty(dayK, "timestamp"),
                };
                
                
                CChartStockDataSetDataSize(&_weekK, dayK->size);
                
                int size = 0;
                CChartDateTime timestamp = {0};
                
                struct {
                    CChartFloat close;
                    CChartFloat open;
                    CChartFloat low;
                    CChartFloat high;
                    CChartFloat volume;
                    CChartDateTime timestamp;
                } Value = {CCHART_NAN,CCHART_NAN,CCHART_NAN,CCHART_NAN,CCHART_NAN,CChartDateTimeEmpty};
                
                CChartFloat v;
                
                for( int i=0;i<dayK->size;i++){
                    
                    CChartStockDataItem * dayItem = CChartStockDataItemAtIndex(dayK, i);
                    
                    CChartStockDataItem dataItem = CChartStockDataItemAtIndex(&_weekK, size);
                    
                    timestamp = CChartStockDataItemPropertyDateTimeValue(dayK, DayPropertys.timestamp, dayItem, CChartDateTimeEmpty);
                    
                    v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.open, dayItem, CCHART_NAN);
                    
                    if(Value.open == CCHART_NAN){
                        
                        Value.open = v;
                        Value.close = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.close, dayItem, 0);
                        Value.timestamp = timestamp;
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.low, dayItem, CCHART_NAN);
                        
                        if(Value.low == CCHART_NAN){
                            Value.low = v;
                        }
                        else if(v < Value.low){
                            Value.low = v;
                        }
                        
                        v =  CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.high, dayItem, CCHART_NAN);
                        
                        if(Value.high == CCHART_NAN){
                            Value.high = v;
                        }
                        else if(v > Value.high){
                            Value.high = v;
                        }
                        
                        v =  CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.volume, dayItem, CCHART_NAN);
                        
                        if(Value.volume == CCHART_NAN){
                            Value.volume = v;
                        }
                        else{
                            Value.volume += v;
                        }
                        
                    }
                    else if(Value.timestamp.date.week < timestamp.date.week){
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.low, dayItem, CCHART_NAN);
                        
                        if(Value.low == CCHART_NAN){
                            Value.low = v;
                        }
                        else if(v < Value.low){
                            Value.low = v;
                        }
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.high, dayItem, CCHART_NAN);
                        
                        if(Value.high == CCHART_NAN){
                            Value.high = v;
                        }
                        else if(v > Value.high){
                            Value.high = v;
                        }
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.volume, dayItem, CCHART_NAN);
                        
                        if(Value.volume == CCHART_NAN){
                            Value.volume = v;
                        }
                        else{
                            Value.volume += v;
                        }
                        
                        Value.close = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.close, dayItem, 0);
                        Value.timestamp = timestamp;
                    }
                    else {
                        
                        CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.close, dataItem, Value.close);
                        CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.open, dataItem, Value.open);
                        CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.low, dataItem, Value.low);
                        CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.high, dataItem, Value.high);
                        CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.volume, dataItem, Value.volume);
                        CChartStockDataItemSetPropertyDateTimeValue(&_weekK, Propertys.timestamp, dataItem, Value.timestamp);
                        
                        size ++;
                        
                        Value.open = v;
                        Value.close = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.close, dayItem, 0);
                        Value.timestamp = timestamp;
                        Value.low = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.low, dayItem, 0);
                        Value.high = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.high, dayItem, 0);
                        Value.volume = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.volume, dayItem, 0);
                    }
                    
                    
                }
                
                if(Value.open != CCHART_NAN){
                    CChartStockDataItem dataItem = CChartStockDataItemAtIndex(&_weekK, size);
                    CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.close, dataItem, Value.close);
                    CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.open, dataItem, Value.open);
                    CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.low, dataItem, Value.low);
                    CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.high, dataItem, Value.high);
                    CChartStockDataItemSetPropertyFloatValue(&_weekK, Propertys.volume, dataItem, Value.volume);
                    CChartStockDataItemSetPropertyDateTimeValue(&_weekK, Propertys.timestamp, dataItem, Value.timestamp);
                    size ++;
                }
                
                CChartStockDataSetDataSize(&_weekK, size);
                
                CChartStockDataSaveFile(&_weekK, [dbPath UTF8String]);
                
            }
        }
        
        if (_weekK.itemSize) {
            if(_weekK.size >100){
                CChartStockDataSetRange(&_weekK, _weekK.size - 100, 100,5);
            }
            else{
                CChartStockDataSetRange(&_weekK, 0, _weekK.size,5);
            }
        }

    }
 
    return &_weekK;
}

-(CChartStockData *) monthK:(NSString *) symbol{
    
    if(_monthK.itemSize == 0){
        
        NSString * dbPath = [self dbPathForSymbol:symbol extension:@"monthk"];
        if(!CChartStockDataLoadFile(&_monthK, [dbPath UTF8String])){
            CChartStockDataDelete(&_monthK);
            
            CChartStockData * dayK = [self dayK:symbol];
            
            if(dayK->itemSize && dayK->size){
            
                CChartStockDataProperty propertys[] = {
                    {"close",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
                    {"open",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
                    {"low",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
                    {"high",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
                    {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
                    {"ma5",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),5},
                    {"ma10",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),10},
                    {"ma30",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),30},
                    {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
                };
                
                CChartStockDataCreate(&_monthK, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
                
                struct {
                    CChartStockDataProperty * close;
                    CChartStockDataProperty * open;
                    CChartStockDataProperty * low;
                    CChartStockDataProperty * high;
                    CChartStockDataProperty * volume;
                    CChartStockDataProperty * timestamp;
                } Propertys = {
                    CChartStockDataGetProperty(&_monthK, "close"),
                    CChartStockDataGetProperty(&_monthK, "open"),
                    CChartStockDataGetProperty(&_monthK, "low"),
                    CChartStockDataGetProperty(&_monthK, "high"),
                    CChartStockDataGetProperty(&_monthK, "volume"),
                    CChartStockDataGetProperty(&_monthK, "timestamp"),
                };
                
                struct {
                    CChartStockDataProperty * close;
                    CChartStockDataProperty * open;
                    CChartStockDataProperty * low;
                    CChartStockDataProperty * high;
                    CChartStockDataProperty * volume;
                    CChartStockDataProperty * timestamp;
                } DayPropertys = {
                    CChartStockDataGetProperty(dayK, "close"),
                    CChartStockDataGetProperty(dayK, "open"),
                    CChartStockDataGetProperty(dayK, "low"),
                    CChartStockDataGetProperty(dayK, "high"),
                    CChartStockDataGetProperty(dayK, "volume"),
                    CChartStockDataGetProperty(dayK, "timestamp"),
                };
                

                CChartStockDataSetDataSize(&_monthK, dayK->size);
                
                int size = 0;
                CChartDateTime timestamp = {0};
            
                struct {
                    CChartFloat close;
                    CChartFloat open;
                    CChartFloat low;
                    CChartFloat high;
                    CChartFloat volume;
                    CChartDateTime timestamp;
                } Value = {CCHART_NAN,CCHART_NAN,CCHART_NAN,CCHART_NAN,CCHART_NAN,CChartDateTimeEmpty};
                
                CChartFloat v;
                
                for( int i=0;i<dayK->size;i++){
                    
                    CChartStockDataItem * dayItem = CChartStockDataItemAtIndex(dayK, i);
                    
                    CChartStockDataItem dataItem = CChartStockDataItemAtIndex(&_monthK, size);
                    
                    timestamp = CChartStockDataItemPropertyDateTimeValue(dayK, DayPropertys.timestamp, dayItem, CChartDateTimeEmpty);
                    
                    v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.open, dayItem, CCHART_NAN);
                    
                    if(Value.open == CCHART_NAN){
                        
                        Value.open = v;
                        Value.close = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.close, dayItem, 0);
                        Value.timestamp = timestamp;
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.low, dayItem, CCHART_NAN);
                        
                        if(Value.low == CCHART_NAN){
                            Value.low = v;
                        }
                        else if(v < Value.low){
                            Value.low = v;
                        }
                        
                        v =  CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.high, dayItem, CCHART_NAN);
                        
                        if(Value.high == CCHART_NAN){
                            Value.high = v;
                        }
                        else if(v > Value.high){
                            Value.high = v;
                        }
                        
                        v =  CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.volume, dayItem, CCHART_NAN);
                        
                        if(Value.volume == CCHART_NAN){
                            Value.volume = v;
                        }
                        else{
                            Value.volume += v;
                        }
                        
                    }
                    else if(Value.timestamp.date.day < timestamp.date.day){
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.low, dayItem, CCHART_NAN);
                        
                        if(Value.low == CCHART_NAN){
                            Value.low = v;
                        }
                        else if(v < Value.low){
                            Value.low = v;
                        }
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.high, dayItem, CCHART_NAN);
                        
                        if(Value.high == CCHART_NAN){
                            Value.high = v;
                        }
                        else if(v > Value.high){
                            Value.high = v;
                        }
                        
                        v = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.volume, dayItem, CCHART_NAN);
                        
                        if(Value.volume == CCHART_NAN){
                            Value.volume = v;
                        }
                        else{
                            Value.volume += v;
                        }
                        
                        Value.close = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.close, dayItem, 0);
                        Value.timestamp = timestamp;
                    }
                    else {
                        
                        CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.close, dataItem, Value.close);
                        CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.open, dataItem, Value.open);
                        CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.low, dataItem, Value.low);
                        CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.high, dataItem, Value.high);
                        CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.volume, dataItem, Value.volume);
                        CChartStockDataItemSetPropertyDateTimeValue(&_monthK, Propertys.timestamp, dataItem, Value.timestamp);
                        
                        size ++;
                        
                        Value.open = v;
                        Value.close = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.close, dayItem, 0);
                        Value.timestamp = timestamp;
                        Value.low = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.low, dayItem, 0);
                        Value.high = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.high, dayItem, 0);
                        Value.volume = CChartStockDataItemPropertyFloatValue(dayK, DayPropertys.volume, dayItem, 0);
                    }

                    
                }
                
                if(Value.open != CCHART_NAN){
                    CChartStockDataItem dataItem = CChartStockDataItemAtIndex(&_monthK, size);
                    CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.close, dataItem, Value.close);
                    CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.open, dataItem, Value.open);
                    CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.low, dataItem, Value.low);
                    CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.high, dataItem, Value.high);
                    CChartStockDataItemSetPropertyFloatValue(&_monthK, Propertys.volume, dataItem, Value.volume);
                    CChartStockDataItemSetPropertyDateTimeValue(&_monthK, Propertys.timestamp, dataItem, Value.timestamp);
                    size ++;
                }
                
                CChartStockDataSetDataSize(&_monthK, size);
                
                CChartStockDataSaveFile(&_monthK, [dbPath UTF8String]);
                
            }
        }
        
        if (_monthK.itemSize) {
            if(_monthK.size >100){
                CChartStockDataSetRange(&_monthK, _monthK.size - 100, 100,5);
            }
            else{
                CChartStockDataSetRange(&_monthK, 0, _monthK.size,5);
            }
        }
        
    }

    return &_monthK;
}

-(void) installKLineData:(id) klineData symbol:(NSString *)symbol{
    
    if(![klineData isKindOfClass:[NSArray class]]){
        return;
    }
    
    NSArray * items = klineData;
    
    if(_dayK.itemSize == 0){
        
        CChartStockDataProperty propertys[] = {
            {"close",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
            {"open",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"low",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"high",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
            {"ma5",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),5},
            {"ma10",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),10},
            {"ma30",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),30},
            {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
        };
        
        CChartStockDataCreate(&_dayK, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
    }
    
    CChartStockDataSetDataSize(&_dayK, [items count]);
    
    CChartStockDataProperty * prop;
    int c;
    CChartDateTime timestamp = {0};
    
    NSCalendar * calendar = [NSCalendar currentCalendar];
    
    [_dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"];
    
    for( int i=0;i<[items count];i++){
        
        id item = [items objectAtIndex:i];
        
        CChartStockDataItem dataItem = CChartStockDataItemAtIndex(&_dayK, i);
        
        prop = _dayK.propertys;
        c  = _dayK.propertyCount;
        
        while(c >0){
            
            if(prop->type == CChartStockDataPropertyTypeDateTime){
                memset(&timestamp, 0, sizeof(timestamp));
                NSString * day = [item valueForKey:@"day"];
                if([day isKindOfClass:[NSString class]]){
                    
                    NSDate * date = [_dateFormatter dateFromString:day];
                    NSDateComponents * comp = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit fromDate:date];
                    
                    timestamp.date.year = comp.year;
                    timestamp.date.month = comp.month;
                    timestamp.date.day = comp.day;
                    timestamp.date.week = comp.weekday;
                    
                    CChartStockDataItemSetPropertyDateTimeValue(&_dayK, prop, dataItem, timestamp);
                }
            }
            else{
                
                CChartStockDataItemSetPropertyFloatValue(&_dayK, prop, dataItem, [[item valueForKey:[NSString stringWithCString:prop->name encoding:NSUTF8StringEncoding]] floatValue]);
            }
            
            prop ++;
            c --;
        }
    }
    
    
    NSFileManager * fileManager = [NSFileManager defaultManager];
    
    NSString * dbPath = [self dbPathForSymbol:symbol extension:@"dayk"];
    
    if(! CChartStockDataSaveFile(&_dayK, [dbPath UTF8String]) ){
        
        [fileManager removeItemAtPath:dbPath error:nil];
        
    }
    
    [fileManager removeItemAtPath:[self dbPathForSymbol:symbol extension:@"yeark"] error:nil];
    [fileManager removeItemAtPath:[self dbPathForSymbol:symbol extension:@"monthk"] error:nil];
    [fileManager removeItemAtPath:[self dbPathForSymbol:symbol extension:@"weekk"] error:nil];
    
    CChartStockDataDelete(&_monthK);
    CChartStockDataDelete(&_weekK);
}

-(void) installRealtimeData:(id) data symbol:(NSString *) symbol{
    
    if(![data isKindOfClass:[NSArray class]]){
        return;
    }
    
    NSArray * items = data;
    
    if(_realtime.itemSize == 0){
        
        CChartStockDataProperty propertys[] = {
            {"price",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
            {"avg_price",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
            {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
        };
        
        CChartStockDataCreate(&_realtime, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
    }
    
    CChartStockDataSetDataSize(&_realtime, [items count]);
    
    CChartStockDataProperty * prop;
    int c;
    CChartDateTime timestamp = {0};
    CChartFloat v;

    
    for( int i=0;i< [items count];i++){
        
        id item = [items objectAtIndex:i];
        
        if(i == 0){
            _realtime.preValue = [[item valueForKey:@"avg_price"] floatValue];
        }
        
        CChartStockDataItem dataItem = CChartStockDataItemAtIndex(&_realtime, i);
        
        prop = _realtime.propertys;
        c  = _realtime.propertyCount;
        
        while(c >0){
            
            if(prop->type == CChartStockDataPropertyTypeDateTime){
                memset(&timestamp, 0, sizeof(timestamp));
                NSString * day = [item valueForKey:@"time"];
                if([day isKindOfClass:[NSString class]]){
                    int hour = 0,minute = 0,second = 0;
                    sscanf([day UTF8String], "%d:%d",&hour,&minute);
                    timestamp.time.hour = hour;
                    timestamp.time.minute = minute;
                    timestamp.time.second = second;
                    CChartStockDataItemSetPropertyDateTimeValue(&_realtime, prop, dataItem, timestamp);
                }
            }
            else{
                v = [[item valueForKey:[NSString stringWithCString:prop->name encoding:NSUTF8StringEncoding]] floatValue];
                if(v <0.0f){
                    v = CCHART_NAN;
                }
                CChartStockDataItemSetPropertyFloatValue(&_realtime, prop, dataItem, v);
            }
            
            prop ++;
            c --;
        }
    }
    
    CChartStockDataSetRange(&_realtime, 0, 242,5);
    
}

-(void) installDay5Data:(id) data symbol:(NSString *) symbol{
    
    if(![data isKindOfClass:[NSArray class]]){
        return;
    }
    
    NSArray * items = data;
    
    if(_day5.itemSize == 0){

        CChartStockDataProperty propertys[] = {
            {"price",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
            {"avg_price",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
            {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
        };
        
        CChartStockDataCreate(&_day5, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
    }

    struct {
        CChartStockDataProperty * price;
        CChartStockDataProperty * avg_price;
        CChartStockDataProperty * volume;
        CChartStockDataProperty * timestamp;
    } Propertys = {
        CChartStockDataGetProperty(&_day5, "price"),
        CChartStockDataGetProperty(&_day5, "avg_price"),
        CChartStockDataGetProperty(&_day5, "volume"),
        CChartStockDataGetProperty(&_day5, "timestamp"),
    };
    
    [_dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"];
    
//    int size = 0;
//    
//    for(int i=0;i<5;i++){
//        id items =  [self.source dataObjectForKey:[NSString stringWithFormat:@"@%d",i]];
//        size += [items count];
//    }
//    
//    CChartStockDataSetDataSize(data, size);
//    
//    int index = 0;
//    CChartDateTime timestamp = CChartDateTimeEmpty;
//    CChartStockDataItem dataItem;
//    
//    data->preValue = CCHART_NAN;
//    
//    NSCalendar * calendar = [NSCalendar currentCalendar];
//    
//    static struct {
//        CChartTime startTime;
//        CChartTime endTime;
//        CChartTime stepTime;
//    } times[] = {
//        {{9,30,0},{11,30,0},{0,1,0}},
//        {{13,0,0},{15,0,0},{0,1,0}},
//    };
//    
//    
//    for(int i=0;i<5;i++){
//        id items =  [self.source dataObjectForKey:[NSString stringWithFormat:@"@%d",i]];
//        for(id item in items){
//            
//            NSString * day = [item valueForKey:@"date"];
//            
//            if([day isKindOfClass:[NSString class]]){
//                NSDate * date = [_dateFormatter dateFromString:day];
//                NSDateComponents * comp = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit fromDate:date];
//                
//                timestamp.date.year = comp.year;
//                timestamp.date.month = comp.month;
//                timestamp.date.day = comp.day;
//                timestamp.date.week = comp.weekday;
//                
//            }
//            
//            id v = [item valueForKey:@"prevclose"];
//            
//            if(v && data->preValue == CCHART_NAN){
//                data->preValue = [v floatValue];
//            }
//            
//            int n = index % 242;
//            int k = 0;
//            timestamp.time = times[k].startTime;
//            
//            while(n >0){
//                timestamp.time = CChartTimeAdd(timestamp.time, times[k].stepTime);
//                if(CChartTimeEqual(timestamp.time,times[k].endTime) ){
//                    k ++;
//                }
//                n --;
//            }
//            
//            dataItem = CChartStockDataItemAtIndex(data, index ++);
//            
//            CChartStockDataItemSetPropertyDateTimeValue(data, Propertys.timestamp, dataItem, timestamp);
//            CChartStockDataItemSetPropertyFloatValue(data, Propertys.price, dataItem, [[item valueForKey:@"price"] floatValue]);
//            CChartStockDataItemSetPropertyFloatValue(data, Propertys.avg_price, dataItem, [[item valueForKey:@"avg_price"] floatValue]);
//            CChartStockDataItemSetPropertyFloatValue(data, Propertys.volume, dataItem, [[item valueForKey:@"volume"] floatValue]);
//            
//        }
//    }
//    
//    CChartStockDataSetRange(data, 0, 242 * 5,5);
}

-(BOOL) hasKLineDataForSymbol:(NSString *) symbol{
    return CChartStockDataFileValidate( [[self dbPathForSymbol:symbol extension:@"dayk"] UTF8String]) ? YES : NO;
}

-(NSString *) dbPathForSymbol:(NSString *) symbol extension:(NSString *) extension{
    return [[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:symbol]
            stringByAppendingPathExtension:extension];
}


@end
