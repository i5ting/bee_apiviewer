//
//  CChartStockAdjust.c
//  Chart
//
//  Created by zhang hailong on 13-5-16.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStockAdjust.h"


static CChartBoolean CChartStockAdjustNotRightNum(CChartFloat num){
    CChartInteger tempH= roundf(num*100);
    if(tempH%100!=0){//not an integer
        if(tempH%10==0) tempH*=.1;//eg: 4.3=>430=>43
        if(tempH%5!=0 && tempH%2!=0)    return 1;
    }
    return 0;
}

static CChartInteger CChartStockAdjustNarrowCount(CChartInteger count,CChartBoolean isVolume){
    if(isVolume){
        while(count>5){
            if(count%2==0)  count*=.5;
            else if(count%3==0) count/=3;
            else break;
        }
    }else{
        if(count>9){
            if(count%3==0)  count/=3;
            else if(count%4==0) count*=.25;
            else if(count%2==0) count*=.5;
        }
    }
    return count;
}

CChartStockAdjustResults CChartStockAdjust(CChartFloat min,CChartFloat max,CChartFloat round,CChartBoolean isVolume){
    
    CChartStockAdjustResults rs = {min,max,0};
    CChartFloat asEqual=-0.000001;//it happends sometimes that theres 6.8 and 6.80000000001 while it's a Number. lets consider they r equal
    CChartFloat mediant=(min+max)*.5;
    CChartInteger volumeCountArr[] = {4,5,6,8,9,10,12,15,16,18,20};
    CChartInteger valueCountArr[] = {4,5,6,7,8,9,10,12,14,15,16,18,20};
    CChartInteger * countArr = isVolume?volumeCountArr :valueCountArr;
    CChartInteger cl = isVolume ? sizeof(volumeCountArr) / sizeof(CChartInteger) : sizeof(valueCountArr) / sizeof(CChartInteger);
    CChartInteger stepNumArr[] = {1,2,3,4,5,6,8};
    CChartFloat selectedMax;//isVolume?0:max;
    CChartFloat selectedMin;//isVolume?0:min;
    CChartBoolean gotResult= 0;
    CChartInteger sl = sizeof(stepNumArr) / sizeof(CChartInteger);
    CChartInteger c = 0,ct,s;
    CChartFloat distance;
    CChartFloat step,realStep;
    CChartFloat base,high,low,range,temp,maxOffset,minOffset,oldOffset,newOffset;
    CChartBoolean hasRange = 0;
    CChartInteger count = 0;
    //var distance,realStep,base,high,low,step,range,count,highStr,lowStr,ct,sl=stepNumArr.length,s;
    for(c = 0;c<cl;c++){
        //everytime init:
        gotResult=0;
        ct=countArr[c];
        distance=(max-min)/ct;
        step= pow(10,0-round);
        while(!gotResult){
            for(s=0;s<sl;s++){
                realStep=step*stepNumArr[s];
                if(realStep-distance>asEqual){//think as equal at these situations:
                    //an even number multiplies by an even will always be an even;
                    //as well as two odds multiply will always be an odd
                    //also, odd * even will be an even
                    if(ct&1){//odd:
                        base= roundf( (mediant+realStep*.5)/realStep ) *realStep;
                        high=(base+ (ct-1)*.5*realStep);
                        low =(base- (ct+1)*.5*realStep);
                    }else{//even:
                        base= roundf(mediant / realStep) *realStep;
                        high=(base+ ct*.5*realStep);
                        low= (base- ct*.5*realStep);
                    }

                    if(high-max>asEqual && low-min<asEqual){
                        gotResult=1;
                        if(low<0){//&& min>=0 //to get rid of negative result
                            high-=low;
                            low=0;
                        }
                        //console.log('result of '+ct+':',high,low,'checking...');
                        if(!hasRange){
                            range=high-low;
                            selectedMax=high;
                            selectedMin=low;
                            count=ct;
                            hasRange = 1;
                            //console.log('firsttime:',selectedMax,selectedMin,'by',count,'\n');
                            break;
                        }
                        temp=(high-low)/CChartStockAdjustNarrowCount(ct,0);
                        if(roundf(temp*100)!=1 && roundf(temp*10)!=1){
                            if(CChartStockAdjustNotRightNum(temp)){
                                //console.log('odd gap\n');
                                break;
                            }
                        }
                        if(high-low>range){
                            //console.log('not a close range\n');
                            break;
                        }else if(high-low==range){
                            //console.log('same range');
                            //choose the smaller one:
                            //old:
                            maxOffset=selectedMax-max;
                            minOffset=min-selectedMin;
                            oldOffset= fabsf(maxOffset-minOffset);
                            //console.log('old offset:',oldOffset);
                            //new:
                            maxOffset=high-max;
                            minOffset=min-low;
                            newOffset= fabsf(maxOffset-minOffset);
                            //console.log('new offset:',newOffset);
                            if(newOffset>=oldOffset){
                                //console.log('former one is better\n');
                                break;
                            }else if(newOffset==oldOffset && count==4){
                                //console.log('ignore the first init one');
                            }
                        }
                        
                        if(CChartStockAdjustNotRightNum(high)){
                            //console.log('ignore cause of high');
                            break;
                        }
                        if(CChartStockAdjustNotRightNum(low)){
                            //console.log('ignore cause of low');
                            break;
                        }
                        range=high-low;
                        selectedMax=high;
                        selectedMin=low;
                        count=ct;
                        hasRange = 1;
                        //console.log('new select:',selectedMax,selectedMin,'by',count,'\n');
                        break;
                    }
                }
            }
            step*=10;
        }
    }
    //console.log('result:',selectedMax,selectedMin,'by',count);
    count = CChartStockAdjustNarrowCount(count,isVolume);
    rs.min = selectedMin;
    rs.max = selectedMax;
    rs.count = count;
    return rs;
}

