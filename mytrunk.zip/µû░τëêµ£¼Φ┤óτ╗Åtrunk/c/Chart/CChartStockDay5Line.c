//
//  CChartStockDay5Line.c
//  Chart
//
//  Created by zhang hailong on 13-5-20.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStock.h"


void CChartStockDay5LineFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect){
    {
        if(context && chart && chart->style){
            CChartStyleItem item = CChartStyleItemAtIndex(chart->style, chart->styleIndex);
            CChartFill fill = {{&CChartFillClass},CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.backgroundColor)};
            CChartBorder border = {{&CChartBorderClass},CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.borderWidth, 0.0f), CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.borderColor)};
            CChartPoint linePoints[2] = {{0.0f,0.0f},{0.0f,0.0f}};
            CChartLine line = {{&CChartLineClass},{linePoints,sizeof(linePoints) / sizeof(CChartPoint)}
                ,CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.gridWidth, 0.0f)
                ,CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.gridColor)};
            CChartLabel label = {{&CChartLabelClass}};
            
            CChartFloat dv1 = chart->data->maxFullValue == CCHART_NAN ? chart->data->preValue * 0.1f : fabsf(chart->data->maxFullValue  - chart->data->preValue);
            CChartFloat dv2 = chart->data->minFullValue == CCHART_NAN ? chart->data->preValue * 0.1f : fabsf(chart->data->minFullValue - chart->data->preValue);
            CChartFloat dv = MAX(dv1, dv2) / 2.0f;
            CChartFloat v ;
            CChartColor curColor = CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.curColor);
            CChartColor gridColor = CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.gridColor);
            CChartColor fallColor = CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.fallColor);
            CChartColor riseColor = CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.riseColor);
            int i;
            
            char text[128];
            
            
            CChartContextDraw(context, (CChart*) &fill, rect);
            
            chart->data->valueAdjust.min = chart->data->preValue - dv * 2.0f;
            chart->data->valueAdjust.max = chart->data->preValue + dv * 2.0f;
            
            label.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.labelColor);
            label.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
            
            
            for(i=-2;i<=2;i++){
                
                v = chart->data->preValue - i * dv;
                
                
                linePoints[0].x = 0.0f;
                linePoints[1].x = 1.0f;
                linePoints[0].y = linePoints[1].y = CChartStockDataYValue(chart->data, v);
                
                if(i == 0){
                    line.color = curColor;
                }
                else{
                    line.color = gridColor;
                }
                
                CChartContextDraw(context, (CChart *) &line, rect);
                
                CChartFloatToString(v,text);
                
                label.text = text;
                label.location.y = linePoints[0].y;
                label.location.x = 0.0f;
                label.mode = CChartLabelModeLeft;
                
                if(i <=0){
                    label.color = riseColor;
                }
                else{
                    label.color = fallColor;
                }
                
                CChartContextDraw(context, (CChart *) & label, rect);
                
                if(i ==0){
                    label.color = curColor;
                }
                else if(i < 0){
                    label.color = riseColor;
                }
                else{
                    label.color = fallColor;
                }
                
                v = (v - chart->data->preValue) * 100.0f / chart->data->preValue;
                
                CChartFloatToString(v,text);
                
                strcat(text, "%");
                
                label.text = text;
                label.location.y = linePoints[0].y;
                label.location.x = 1.0f;
                label.mode = CChartLabelModeRight;
                
                CChartContextDraw(context, (CChart *) & label, rect);
            }
            
            CChartStockFormColumnsDraw(context,chart,rect,1);
            
            CChartContextDraw(context, (CChart*) &border, rect);
        }
    }
    
    if(context && chart && chart->data){
        
        CChartLine line = {{&CChartLineClass}};
        int i;
        CChartStyleItem item = CChartStyleItemAtIndex(chart->style,chart->styleIndex);
        CChartFloat v;
        CChartStockDataItem dataItem;
        CChartPoint *p;
        CChartTipLabel tipLabel = {{&CChartTipLabelClass}};
        char text[128];
        CChartPoint linePoints[2] = {{0.0f,0.0f},{0.0f,0.0f}};
        
        line.width = CChartStyleItemFloatValue(chart->style, item, &CChartStockFormStylePropertys.lineWidth, 1.0f);
        line.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.lineColor1);
        line.path.points = (CChartPoint *) malloc(sizeof(CChartPoint) * 242);
        line.path.length = 0;
        
        for(i=0;i<chart->data->length;i++){
            
            if(i % 242 == 0 ){
                CChartContextDraw(context, (CChart *) &line, rect);
                line.path.length = 0;
            }
            
            dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location + i);
            
            v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.value, dataItem, CCHART_NAN);
            
            if(v != CCHART_NAN){
                
                p = line.path.points + line.path.length;
                
                p->x = CChartStockDataXValue(chart->data,i );
                p->y = CChartStockDataYValue(chart->data, v);
                
                line.path.length ++;
            }
            else{
                break;
            }
        }
        
        CChartContextDraw(context, (CChart *) &line, rect);
        
        line.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.lineColor2);
        line.path.length = 0;
        
        for(i=0;i<chart->data->length;i++){
            
            if(i % 242 == 0 ){
                CChartContextDraw(context, (CChart *) &line, rect);
                line.path.length = 0;
            }
            
            dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location + i);
            
            v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.avgValue, dataItem, CCHART_NAN);
            
            if(v != CCHART_NAN){
                
                p = line.path.points + line.path.length;
                
                p->x = CChartStockDataXValue(chart->data,i );
                p->y = CChartStockDataYValue(chart->data, v);
                
                line.path.length ++;
            }
            else{
                break;
            }
        }
        
        CChartContextDraw(context, (CChart *) &line, rect);
        
        
        free(line.path.points);
        
        
        if(chart->focusLocation.x >=0.0f && chart->focusLocation.x <= 1.0f){
            
            line.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.focusColor);
            
            i = chart->focusLocation.x * chart->data->length;
            
            if(i >=0 && i < chart->data->length){
                
                dataItem = CChartStockDataItemAtIndex(chart->data, i + chart->data->location);
                
                
                line.path.points = linePoints;
                line.path.length = 2;
                
                v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.value, dataItem, 0.0f);
                
                linePoints[0].y = linePoints[1].y = CChartStockDataYValue(chart->data, v);
                linePoints[0].x = 0.0f;
                linePoints[1].x = 1.0f;
                
                CChartContextDraw(context, (CChart *) & line, rect);
                
                tipLabel.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
                tipLabel.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.labelColor);
                tipLabel.lineColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.borderColor);
                tipLabel.fillColor = tipLabel.lineColor;
                tipLabel.distance = 0.0f;
                
                sprintf(text, "%.2f",v);
                tipLabel.text = text;
                tipLabel.location.y = CChartStockDataYValue(chart->data, v);
                tipLabel.location.x = 0.0f;
                tipLabel.mode = CChartLabelModeLeft;
                
                CChartContextDraw(context, (CChart *) & tipLabel, rect);
                
            }
        }
        
    }
}