//
//  StockInfoChartViewController.h
//  SinaFinance
//
//  Created by zhang hailong on 13-6-24.
//
//

#import <UIKit/UIKit.h>

#import <Chart/IOSChartView.h>

#import <Chart/IOSChartStockDataRealTime.h>

#import "StockChartDataSource.h"

@interface StockInfoChartViewController : UIViewController<IOSChartStockDataSource>

@property(nonatomic,readonly) NSString * symbol;
@property (retain, nonatomic) IBOutlet IOSChartView *chartView;
@property (retain, nonatomic) IBOutlet StockChartDataSource *dataSource;
@property (retain, nonatomic) IBOutletCollection(UIButton) NSArray *tabButtons;
@property (retain, nonatomic) IBOutletCollection(IOSChartStock) NSArray *stocks;

-(void) reloadData:(NSString *) symbol;

- (IBAction)tabAction:(id)sender;

@end
