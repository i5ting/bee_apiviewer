//
//  StockChartDataSource.h
//  SinaFinance
//
//  Created by zhang hailong on 13-6-24.
//
//

#import <Foundation/Foundation.h>

#include <Chart/CChartStockData.h>

@interface StockChartDataSource : NSObject

-(void) installKLineData:(id) data symbol:(NSString *) symbol;

-(void) installRealtimeData:(id) data symbol:(NSString *) symbol;

-(void) installDay5Data:(id) data symbol:(NSString *) symbol;

-(BOOL) hasKLineDataForSymbol:(NSString *) symbol;

-(CChartStockData *) realtime:(NSString *) symbol;

-(CChartStockData *) day5:(NSString *) symbol;

-(CChartStockData *) dayK:(NSString *) symbol;

-(CChartStockData *) year:(NSString *) symbol;

-(CChartStockData *) monthK:(NSString *) symbol;

-(CChartStockData *) weekK:(NSString *) symbol;

-(void) reset;

@end
