//
//  UIView+ParentLayout.h
//  SinaNews
//
//  Created by shieh exbice on 11-11-7.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ParentLayout)

-(void)setAdaptiveParentLayoutWithSize:(CGSize)size;

@end
