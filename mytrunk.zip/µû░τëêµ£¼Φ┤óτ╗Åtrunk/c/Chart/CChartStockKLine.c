//
//  CChartStockKLine.c
//  Chart
//
//  Created by zhang hailong on 13-5-20.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStock.h"

void CChartStockKLineFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect){
    
    {
        if(context && chart && chart->style){
            CChartStyleItem item = CChartStyleItemAtIndex(chart->style, chart->styleIndex);
            CChartFill fill = {{&CChartFillClass},CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.backgroundColor)};
            CChartBorder border = {{&CChartBorderClass},CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.borderWidth, 0.0f), CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.borderColor)};
            CChartPoint linePoints[2] = {{0.0f,0.0f},{0.0f,0.0f}};
            CChartLine line = {{&CChartLineClass},{linePoints,sizeof(linePoints) / sizeof(CChartPoint)}
                ,CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.gridWidth, 0.0f)
                ,CChartStyleItemColorValue(chart->style, item, & CChartStockFormStylePropertys.gridColor)};
            CChartLabel label = {{&CChartLabelClass}};
            
            int c = chart->data->valueAdjust.count;
            CChartFloat dv = (chart->data->valueAdjust.max - chart->data->valueAdjust.min) / chart->data->valueAdjust.count;
            CChartFloat v = chart->data->valueAdjust.min;
            char text[128];
            
            CChartContextDraw(context, (CChart*) &fill, rect);
            
            
            label.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.labelColor);
            label.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
            
            while (c >=0) {
                
                linePoints[0].x = 0.0f;
                linePoints[1].x = 1.0f;
                linePoints[0].y = linePoints[1].y = CChartStockDataYValue(chart->data, v);
                
                CChartContextDraw(context, (CChart *) &line, rect);
                
                
                CChartFloatToString(v,text);
                
                label.text = text;
                label.location.y = linePoints[0].y;
                label.location.x = 0.0f;
                label.mode = CChartLabelModeLeft;
                
                CChartContextDraw(context, (CChart *) & label, rect);
                
                v += dv;
                c --;
            }
            
            CChartStockFormColumnsDraw(context,chart,rect,1);
            
            CChartContextDraw(context, (CChart*) &border, rect);
        }
    }
    
    if(context && chart && chart->data){
        
        CChartKLine kline = {{&CChartKLineClass}};
        CChartLine line = {{&CChartLineClass}};
        
        int i,c;
        CChartFloat width = 0.8f / chart->data->length;
        CChartStyleItem item = CChartStyleItemAtIndex(chart->style,chart->styleIndex);
        CChartColor fallColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.fallColor);
        CChartColor riseColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.riseColor);
        CChartColor preColor;
        CChartFloat preValue,v;
        CChartStockDataProperty * prop;
        CChartStockDataItem dataItem;
        CChartStyleProperty * lineColorProperty;
        CChartPoint *p;
        CChartTipLabel tipLabel = {{&CChartTipLabelClass}};
        char text[128];
        CChartSize textSize;
        CChartPoint linePoints[2] = {{0.0f,0.0f},{0.0f,0.0f}};
        
        dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location - 1);
        
        if(dataItem){
            preValue = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.value, dataItem, 0.0f);
            preColor = riseColor;
        }
        else{
            preValue = 0.0f;
            preColor = riseColor;
        }
        
        for(i=0;i<chart->data->length;i++){
            
            dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location + i);
            
            v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.value, dataItem, CCHART_NAN);
            
            if(v != CCHART_NAN){
                
                kline.location.x = CChartStockDataXValue(chart->data,i );
                kline.location.y = CChartStockDataYValue(chart->data, v);
                kline.width = width;
                
                
                if(v == preValue){
                    kline.color = preColor;
                }
                else if(v > preValue){
                    kline.color = riseColor;
                }
                else{
                    kline.color = fallColor;
                }
                
                preColor = kline.color;
                preValue =v;
                
                
                v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.openValue, dataItem, 0.0f);
                
                kline.source = CChartStockDataYValue(chart->data, v);
                
                v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.lowValue, dataItem, 0.0f);
                
                kline.min = CChartStockDataYValue(chart->data, v);
                
                v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.highValue, dataItem, 0.0f);
                
                kline.max = CChartStockDataYValue(chart->data, v);
                
                CChartContextDraw(context, (CChart *) &kline, rect);
                
            }
        }
        
        line.width = CChartStyleItemFloatValue(chart->style, item, &CChartStockFormStylePropertys.lineWidth, 1.0f);
        line.path.points = (CChartPoint *) malloc(sizeof(CChartPoint) * chart->data->length);
        
        c = chart->data->propertyCount;
        prop = chart->data->propertys;
        
        lineColorProperty = & CChartStockFormStylePropertys.lineColor1;
        line.color = CChartStyleItemColorValue(chart->style, item, lineColorProperty);
        
        while(c >0){
            
            if(prop->type == CChartStockDataPropertyTypeValueMa){
                
                line.path.length =0;
                
                for(i=0;i<chart->data->length;i++){
                    
                    p = line.path.points + line.path.length;
                    
                    dataItem = CChartStockDataItemAtIndex(chart->data, chart->data->location + i);
                    
                    v = CChartStockDataItemPropertyFloatValue(chart->data, prop, dataItem, CCHART_NAN);
                    
                    if(v != CCHART_NAN){
                        
                        p->x = CChartStockDataXValue(chart->data,i );
                        p->y = CChartStockDataYValue(chart->data, v);
                        
                        line.path.length ++;
                    }
                }
                
                CChartContextDraw(context, (CChart *) &line, rect);
                
                if(lineColorProperty != &CChartStockFormStylePropertys.lineColor5){
                    lineColorProperty ++;
                    line.color = CChartStyleItemColorValue(chart->style, item, lineColorProperty);
                }
            }
            
            prop ++;
            c--;
        }
        
        
        free(line.path.points);
        
        
        tipLabel.fontSize = CChartStyleItemFloatValue(chart->style, item, & CChartStockFormStylePropertys.fontSize, 0.0f);
        tipLabel.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.labelColor);
        tipLabel.lineColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.borderColor);
        tipLabel.lineWidth = 1;
        tipLabel.distance = 0.02;
        sprintf(text, "%.2f",chart->data->minValue);
        tipLabel.text = text;
        tipLabel.location.x = CChartStockDataXValue(chart->data,chart->data->minValueIndex - chart->data->location ) ;
        tipLabel.location.y = CChartStockDataYValue(chart->data,chart->data->minValue);
        
        textSize = CChartLabelSize(tipLabel.text, tipLabel.fontSize);
        textSize = CChartContextRelativeSize(context, textSize);
        
        tipLabel.mode =  CChartLabelModeHorizontal;
        
        if(tipLabel.location.y - textSize.height / 2.0f <= 0.02){
            tipLabel.mode |= CChartLabelModeTop;
        }
        
        if(tipLabel.location.x + textSize.width + tipLabel.distance >= 0.98){
            tipLabel.mode |= CChartLabelModeLeft;
        }
        else{
            tipLabel.mode |= CChartLabelModeRight;
        }
        
        CChartContextDraw(context, (CChart *) & tipLabel, rect);
        
        sprintf(text, "%.2f",chart->data->maxValue);
        tipLabel.text = text;
        tipLabel.location.x = CChartStockDataXValue(chart->data,chart->data->maxValueIndex - chart->data->location );
        tipLabel.location.y = CChartStockDataYValue(chart->data,chart->data->maxValue);
        
        textSize = CChartLabelSize(tipLabel.text, tipLabel.fontSize);
        textSize = CChartContextRelativeSize(context, textSize);
        
        tipLabel.mode = CChartLabelModeBottom | CChartLabelModeHorizontal;
        
        if(tipLabel.location.y + textSize.height / 2.0f >= 0.98){
            tipLabel.mode |= CChartLabelModeBottom;
        }
        
        if(tipLabel.location.x + textSize.width + tipLabel.distance >= 0.98){
            tipLabel.mode |= CChartLabelModeLeft;
        }
        else{
            tipLabel.mode |= CChartLabelModeRight;
        }
        
        CChartContextDraw(context, (CChart *) & tipLabel, rect);
        
        
        if(chart->focusLocation.x >=0.0f && chart->focusLocation.x <= 1.0f){
            
            line.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.focusColor);
            
            i = chart->focusLocation.x * chart->data->length;
            
            if(i >=0 && i < chart->data->length){
                
                dataItem = CChartStockDataItemAtIndex(chart->data, i + chart->data->location);
                
                
                line.path.points = linePoints;
                line.path.length = 2;
                
                v = CChartStockDataItemPropertyFloatValue(chart->data, chart->dataPropertys.value, dataItem, 0.0f);
                
                linePoints[0].y = linePoints[1].y = CChartStockDataYValue(chart->data, v);
                linePoints[0].x = 0.0f;
                linePoints[1].x = 1.0f;
                
                CChartContextDraw(context, (CChart *) & line, rect);
                
                tipLabel.color = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.focusLabelColor);
                tipLabel.fillColor = CChartStyleItemColorValue(chart->style, item, &CChartStockFormStylePropertys.focusColor);
                tipLabel.distance = 0.0f;
                
                sprintf(text, "%.2f",v);
                tipLabel.text = text;
                tipLabel.location.y = CChartStockDataYValue(chart->data, v);
                tipLabel.location.x = 0.0f;
                tipLabel.mode = CChartLabelModeLeft;
                
                CChartContextDraw(context, (CChart *) & tipLabel, rect);
                
            }
        }
        
    }
    
}