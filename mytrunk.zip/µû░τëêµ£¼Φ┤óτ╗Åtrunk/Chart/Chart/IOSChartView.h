//
//  IOSChartView.h
//  IOSChart
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <Chart/IOSChart.h>

@interface IOSChartView : UIView<IOSChartDelegate>

@property(nonatomic,retain) IBOutlet IOSChart * chart;

-(void) setNeedsRender;

@end
