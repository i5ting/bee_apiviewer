//
//  CChartGL.c
//  CChart
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChart.h"

#ifdef ANDROID

#include <GLES/gl.h>
#include <GLES/glext.h>

#else

#include <OpenGLES/ES1/gl.h>
#include <OpenGLES/ES1/glext.h>

#endif

typedef struct _CChart2DElement{
    CChartPoint location;
    CChartColor color;
} CChart2DElement;


static void CChartLineClassDraw(CChartContext * context,CChartLine * chart,CChartRect rect){
    if(context && chart && chart->path.length > 1 && chart->width > 0){
        int size = sizeof(CChart2DElement) * chart->path.length ;
        int i = 0;
        CChart2DElement * elements = NULL;
        CChart2DElement * el;
        CChartPoint origin = CChartContextRelativePoint(context,rect.origin);
        CChartPoint p;
        
        CChartContextSetBufferLength(context, size);
        
        elements = (CChart2DElement * )context->buffer.data;
        
        while(i < chart->path.length){

            p = chart->path.points[i];
            
            p.x = p.x * rect.size.width;
            p.y = p.y * rect.size.height;
            
            p = CChartContextRelativePoint(context,p);
            
            p.x += origin.x;
            p.y += origin.y;
            
            el = elements + i;
            el->location = p;
            el->color = chart->color;
            i ++;
        }
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        glLineWidth(chart->width / context->scale);
        
        glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
        
        glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
        
        glDrawArrays(GL_LINE_STRIP, 0, chart->path.length );
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);

    }
}

CChartClass CChartLineClass = {(CChartDraw)CChartLineClassDraw,sizeof(CChartLine)};

static void CChartPillarClassDraw(CChartContext * context,CChartPillar * chart,CChartRect rect){
    if(context && chart){
        
        CChart2DElement elements[4];
        CChartPoint p;
        CChartFloat dx = CChartContextRelativeOfWidth(context, MAX(chart->width * rect.size.width,1.0)) / 2.0f;
        CChartPoint origin = CChartContextRelativePoint(context,rect.origin);
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        p = chart->location;
        
        p.x = p.x * rect.size.width;
        p.y = p.y * rect.size.height;
        
        p = CChartContextRelativePoint(context,p);
        
        p.x += origin.x;
        p.y += origin.y;
        
        if(fabs(p.y - origin.y) * context->viewport.height < 1.0 / context->scale){
            
            elements[0].location =  CChartPointMake( p.x - dx, p.y);
            elements[0].color = chart->color;
            
            elements[1].location =  CChartPointMake( p.x + dx, p.y);
            elements[1].color = chart->color;
            
            glLineWidth(1.0f / context->scale);
            
            glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
            
            glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
            
            glDrawArrays(GL_LINES, 0, 2);
            
        }
        else{
            elements[0].location =  CChartPointMake( p.x - dx, p.y);
            elements[0].color = chart->color;
            
            elements[1].location =  CChartPointMake( p.x + dx, p.y);
            elements[1].color = chart->color;
            
            elements[2].location =  CChartPointMake( p.x + dx, origin.y);
            elements[2].color = chart->color;
            
            elements[3].location =  CChartPointMake( p.x - dx, origin.y);
            elements[3].color = chart->color;
            
            glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
            
            glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
            
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        }
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        
    }
}

CChartClass CChartPillarClass = {(CChartDraw)CChartPillarClassDraw,sizeof(CChartPillar)};

static void CChartFocusClassDraw(CChartContext * context,CChartFocus * chart,CChartRect rect){
    if(context && chart){
        
        CChart2DElement elements[4];
        CChartPoint p;
        CChartFloat dx = CChartContextRelativeOfWidth(context, chart->radius);
        CChartFloat dy = context->viewport.width / context->viewport.height * dx;
        CChartPoint origin = CChartContextRelativePoint(context,rect.origin);
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        p = chart->location;
        
        p.x = p.x * rect.size.width;
        p.y = p.y * rect.size.height;
        
        p = CChartContextRelativePoint(context,p);
        
        p.x += origin.x;
        p.y += origin.y;
        
        elements[0].location =  CChartPointMake(p.x , p.y + dy);
        elements[0].color = chart->color;
        
        elements[1].location =  CChartPointMake(p.x + dx, p.y);
        elements[1].color = chart->color;
        
        elements[2].location =  CChartPointMake(p.x, p.y - dy);
        elements[2].color = chart->color;
        
        elements[3].location =  CChartPointMake(p.x - dx, p.y);
        elements[3].color = chart->color;
        
        glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
        
        glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
        
        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        
    }
}

CChartClass CChartFocusClass = {(CChartDraw)CChartFocusClassDraw,sizeof(CChartFocus)};

static void CChartFillClassDraw(CChartContext * context,CChartFill * chart,CChartRect rect){
    if(context && chart){
        
        CChart2DElement elements[4];
        CChartPoint p = CChartContextRelativePoint(context,rect.origin);
        CChartSize size = CChartContextRelativeSize(context,rect.size);
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        elements[0].location =  CChartPointMake(p.x , p.y + size.height);
        elements[0].color = chart->color;
        
        elements[1].location =  CChartPointMake(p.x + size.width, p.y + size.height);
        elements[1].color = chart->color;
        
        elements[2].location =  CChartPointMake(p.x + size.width,  p.y );
        elements[2].color = chart->color;
        
        elements[3].location =  CChartPointMake(p.x, p.y );
        elements[3].color = chart->color;
        
        glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
        
        glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
        
        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        
    }
}

CChartClass CChartFillClass = {(CChartDraw)CChartFillClassDraw,sizeof(CChartFill)};


static void CChartBorderClassDraw(CChartContext * context,CChartBorder * chart,CChartRect rect){
    if(context && chart && chart->width > 0.0f){
        
        CChart2DElement elements[4];
        CChartPoint p = CChartContextRelativePoint(context,rect.origin);
        CChartSize size = CChartContextRelativeSize(context,rect.size);
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        elements[0].location =  CChartPointMake(p.x , p.y + size.height);
        elements[0].color = chart->color;
        
        elements[1].location =  CChartPointMake(p.x + size.width, p.y + size.height);
        elements[1].color = chart->color;
        
        elements[2].location =  CChartPointMake(p.x + size.width,  p.y );
        elements[2].color = chart->color;
        
        elements[3].location =  CChartPointMake(p.x, p.y );
        elements[3].color = chart->color;
        
        glLineWidth(chart->width / context->scale);
        
        glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
        
        glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
        
        glDrawArrays(GL_LINE_LOOP, 0, 4);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        
    }
}

CChartClass CChartBorderClass = {(CChartDraw)CChartBorderClassDraw,sizeof(CChartBorder)};

static void CChartKLineClassDraw(CChartContext * context,CChartKLine * chart,CChartRect rect){
    if(context && chart){
        
        CChart2DElement elements[4];
        CChartPoint p;
        CChartFloat dx = CChartContextRelativeOfWidth(context, MAX(chart->width * rect.size.width,1.0f)) / 2.0f;
        CChartPoint origin = CChartContextRelativePoint(context,rect.origin);
        CChartFloat source = origin.y + CChartContextRelativeOfHeight(context,rect.size.height * chart->source);
        CChartFloat max = origin.y + CChartContextRelativeOfHeight(context,rect.size.height * chart->max);
        CChartFloat min = origin.y + CChartContextRelativeOfHeight(context,rect.size.height * chart->min);
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        p = chart->location;
        
        p.x = p.x * rect.size.width;
        p.y = p.y * rect.size.height;
        
        p = CChartContextRelativePoint(context,p);
        
        p.x += origin.x;
        p.y += origin.y;
        
        if(fabs(p.y - source) * context->viewport.height < 1.0 / context->scale){
            
            elements[0].location =  CChartPointMake( p.x - dx, p.y);
            elements[0].color = chart->color;
            
            elements[1].location =  CChartPointMake( p.x + dx, p.y);
            elements[1].color = chart->color;
            
            glLineWidth(1.0f / context->scale);
            
            glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
            
            glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
            
            glDrawArrays(GL_LINES, 0, 2);
        }
        else{
            elements[0].location =  CChartPointMake( p.x - dx, p.y);
            elements[0].color = chart->color;
            
            elements[1].location =  CChartPointMake( p.x + dx, p.y);
            elements[1].color = chart->color;
            
            elements[2].location =  CChartPointMake( p.x + dx, source);
            elements[2].color = chart->color;
            
            elements[3].location =  CChartPointMake( p.x - dx, source);
            elements[3].color = chart->color;
            
            glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
            
            glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
            
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        }
        
        
        elements[0].location =  CChartPointMake( p.x, min);
        elements[0].color = chart->color;
        
        elements[1].location =  CChartPointMake( p.x, max);
        elements[1].color = chart->color;
        
        glLineWidth(1.0f / context->scale);
        
        glDrawArrays(GL_LINE_STRIP, 0, 2);
        
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        
    }
}

CChartClass CChartKLineClass = {(CChartDraw)CChartKLineClassDraw,sizeof(CChartKLine)};

static void CChartFillPathClassDraw(CChartContext * context,CChartFillPath * chart,CChartRect rect){
    if(context && chart && chart->path.length > 1){
        int length = chart->path.length * 2;
        int size = sizeof(CChart2DElement) * length ;
        int i = 0;
        CChart2DElement * elements = NULL;
        CChart2DElement * el;
        CChartPoint origin = CChartContextRelativePoint(context,rect.origin);
        CChartPoint p;
        CChartFloat toValue = origin.y + CChartContextRelativeOfHeight(context, chart->toValue * rect.size.height);
        
        CChartContextSetBufferLength(context, size);
        
        elements = (CChart2DElement * )context->buffer.data;
        
        while(i < length){
            
            p = chart->path.points[i / 2];
            
            p.x = p.x * rect.size.width;
            p.y = p.y * rect.size.height;
            
            p = CChartContextRelativePoint(context,p);
            
            p.x += origin.x;
            p.y += origin.y;
            
            el = elements + i + 1;
            el->location = p;
            el->color = chart->fromColor;
            
            p.y = toValue;
            
            el = elements + i;
            el->location = p;
            el->color = chart->toColor;
            
            i += 2;
        }
    
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
        
        glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
        
        glDrawArrays(GL_TRIANGLE_STRIP, 0, length);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);

        
    }
}

CChartClass CChartFillPathClass = {(CChartDraw)CChartFillPathClassDraw,sizeof(CChartFillPath)};


static void CChartTipLabelClassDraw(CChartContext * context,CChartTipLabel * chart,CChartRect rect){
    if(context && chart && chart->text && chart->fontSize >0 ){
       
        CChart2DElement elements[4] = {0};
        CChartSize textSize = CChartLabelSize(chart->text, chart->fontSize);
        CChartLabel label = {{&CChartLabelClass}};
        CChartPoint p = CChartContextRelativePoint(context, CChartPointMake(rect.origin.x + chart->location.x * rect.size.width, rect.origin.y + chart->location.y * rect.size.height));
        CChartSize ds = CChartContextRelativeSize(context, CChartSizeMake(2, 1));
        CChartColor color = chart->fillColor;
        
        if(color.a == 0.0f){
            color = chart->lineColor;
        }
        
        textSize = CChartContextRelativeSize(context, textSize);
        textSize.width += ds.width;
        textSize.height += ds.height;
        
        
        elements[0].location = p;
        elements[0].color = color;
        elements[1].color = color;
        
        if((chart->mode & CChartLabelModeVertical) && (chart->mode & CChartLabelModeTop)){
            elements[1].location = CChartPointMake(p.x, p.y - chart->distance);
        }
        else if((chart->mode & CChartLabelModeVertical) && (chart->mode & CChartLabelModeBottom)){
            elements[1].location = CChartPointMake(p.x, p.y + chart->distance);
        }
        else if(chart->mode & CChartLabelModeLeft){
            
            if(p.x - chart->distance - textSize.width < 0.0f){
                p.x = chart->distance + textSize.width;
            }
            
            elements[0].location = p;
            elements[1].location = CChartPointMake(p.x - chart->distance, p.y);
        }
        else{
            elements[1].location = CChartPointMake(p.x + chart->distance, p.y);
        }
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
        
        glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
        
        glLineWidth(chart->lineWidth / context->scale);
        
        glDrawArrays(GL_LINES, 0, 2);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        
        elements[0].color  = elements[1].color = elements[2].color = elements[3].color = color;
        
        
        label.mode = CChartLabelModeCenter;
        
        if((chart->mode & CChartLabelModeVertical) && ( (chart->mode & CChartLabelModeTop) || (chart->mode & CChartLabelModeBottom))){
            
            label.location.x = chart->location.x;
            
            if((chart->mode & CChartLabelModeBottom)){
                
                elements[0].location.y = p.y - chart->distance - textSize.height;
            
                elements[1].location.y = p.y - chart->distance - textSize.height;
                
                elements[2].location.y = p.y - chart->distance;
                
                elements[3].location.y = p.y - chart->distance;
                
                label.location.y = chart->location.y + chart->distance - ds.height / 2.0f;
                
                label.mode |= CChartLabelModeBottom;
            }
            else{
                elements[0].location.y = p.y + chart->distance;
                
                elements[1].location.y = p.y + chart->distance;
                
                elements[2].location.y = p.y + chart->distance + textSize.height;
                
                elements[3].location.y = p.y + chart->distance + textSize.height;
                
                label.location.y = chart->location.y - chart->distance + ds.height / 2.0f;
                
                label.mode |= CChartLabelModeTop;
                
            }
            
            if(chart->mode & CChartLabelModeLeft){
                elements[0].location.x = p.x - textSize.width;
                elements[1].location.x = p.x;
                elements[2].location.x = p.x;
                elements[3].location.x = p.x - textSize.width;
                label.mode |= CChartLabelModeLeft;
            }
            else if(chart->mode & CChartLabelModeRight){
                elements[0].location.x = p.x ;
                elements[1].location.x = p.x + textSize.width;
                elements[2].location.x = p.x + textSize.width;
                elements[3].location.x = p.x ;
                label.mode |= CChartLabelModeRight;
            }
            else{
                elements[0].location.x = p.x - textSize.width / 2.0f;
                elements[1].location.x = p.x + textSize.width / 2.0f;
                elements[2].location.x = p.x + textSize.width / 2.0f;
                elements[3].location.x = p.x - textSize.width / 2.0f;
            }
        }
        else if(chart->mode & CChartLabelModeLeft){
            
            label.location.y = chart->location.y;
            label.location.x = chart->location.x - chart->distance - ds.width / 2.0f;
            label.mode |= CChartLabelModeLeft;
            
            elements[0].location.x = p.x - chart->distance - textSize.width;
            elements[1].location.x = p.x - chart->distance ;
            elements[2].location.x = p.x - chart->distance;
            elements[3].location.x = p.x - chart->distance - textSize.width;
            

            if(chart->mode & CChartLabelModeTop){
                elements[0].location.y = p.y ;
                elements[1].location.y = p.y ;
                elements[2].location.y = p.y + textSize.height ;
                elements[3].location.y = p.y + textSize.height ;
                label.mode |= CChartLabelModeTop;
                label.location.y += ds.height / 2.0f;
            }
            else if(chart->mode & CChartLabelModeBottom){
                elements[0].location.y = p.y - textSize.height;
                elements[1].location.y = p.y - textSize.height;
                elements[2].location.y = p.y ;
                elements[3].location.y = p.y ;
                label.mode |= CChartLabelModeBottom;
                label.location.y -= ds.height / 2.0f;
            }
            else {
                elements[0].location.y = p.y - textSize.height / 2.0f;
                elements[1].location.y = p.y - textSize.height / 2.0f;
                elements[2].location.y = p.y + textSize.height / 2.0f;
                elements[3].location.y = p.y + textSize.height / 2.0f;
            }
        }
        else{
            
            label.location.y = chart->location.y;
            label.location.x = chart->location.x + chart->distance + ds.width / 2.0f;
            
            label.mode |= CChartLabelModeRight;

            
            elements[0].location.x = p.x + chart->distance;
            elements[0].location.y = p.y - textSize.height / 2.0f;
            
            elements[1].location.x = p.x + chart->distance + textSize.width;
            elements[1].location.y = p.y - textSize.height / 2.0f;
            
            elements[2].location.x = p.x + chart->distance + textSize.width;
            elements[2].location.y = p.y + textSize.height / 2.0f;
            
            elements[3].location.x = p.x + chart->distance;
            elements[3].location.y = p.y + textSize.height / 2.0f;
                        
            if(chart->mode & CChartLabelModeTop){
                elements[0].location.y = p.y ;
                elements[1].location.y = p.y ;
                elements[2].location.y = p.y + textSize.height ;
                elements[3].location.y = p.y + textSize.height ;
                label.mode |= CChartLabelModeTop;
                label.location.y += ds.height / 2.0f;
            }
            else if(chart->mode & CChartLabelModeBottom){
                elements[0].location.y = p.y - textSize.height;
                elements[1].location.y = p.y - textSize.height;
                elements[2].location.y = p.y ;
                elements[3].location.y = p.y ;
                label.mode |= CChartLabelModeBottom;
                label.location.y -= ds.height / 2.0f;
            }
            else {
                elements[0].location.y = p.y - textSize.height / 2.0f;
                elements[1].location.y = p.y - textSize.height / 2.0f;
                elements[2].location.y = p.y + textSize.height / 2.0f;
                elements[3].location.y = p.y + textSize.height / 2.0f;
            }
        }
        
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        
        glVertexPointer(2, GL_FLOAT, sizeof(CChart2DElement), &elements->location);
        
        glColorPointer(4, GL_FLOAT, sizeof(CChart2DElement), &elements->color);
        
        if(chart->fillColor.a == 0.0f){
            glLineWidth(chart->lineWidth / context->scale);
            glDrawArrays(GL_LINE_LOOP, 0, 4);
        }
        else{
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        }
        
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisableClientState(GL_COLOR_ARRAY);
        
        
        label.fontSize = chart->fontSize;
        label.color = chart->color;
        label.text = chart->text;
        
        CChartContextDraw(context, (CChart *) & label, rect);
    }
}

CChartClass CChartTipLabelClass = {(CChartDraw)CChartTipLabelClassDraw,sizeof(CChartTipLabel)};
