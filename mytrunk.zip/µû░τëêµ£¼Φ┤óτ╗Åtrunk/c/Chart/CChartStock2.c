//
//  CChartStock.c
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStock.h"

static void CChartStockFormClassDraw(CChartContext * context,CChartStockForm * form,CChartRect rect){
    if(context && form){
        
        CChartFill fill = {{&CChartFillClass},form->backgroundColor};
        CChartBorder border = {{&CChartBorderClass},form->borderWidth, form->borderColor};
        CChartPoint linePoints[2] = {{0.0f,0.0f},{0.0f,0.0f}};
        CChartLine line = {{&CChartLineClass},{linePoints,sizeof(linePoints) / sizeof(CChartPoint)},form->lineWidth,form->lineColor};
        CChartStockFormRow * row;
        CChartStockFormColumn * column;
        CChartStockFormItem * formItem;
        CChartStockFormValue * formValue;
        CChartLabel label = {{&CChartLabelClass}};
        CChartTipLabel tipLabel = {{&CChartTipLabelClass}};
        CChartSize textSize;
        CChartFloat v1,v2;
        int i;
        
        CChartContextDraw(context, (CChart *) &fill, rect);
        
        for(i=0;i<form->rowCount;i++){
            row = form->rows + i;
            linePoints[0].x = 0.0f;
            linePoints[0].y = row->value;
            linePoints[1].x = 1.0f;
            linePoints[1].y = row->value;
            CChartContextDraw(context, (CChart *) &line, rect);
            
            if(row->leftLabel.text){
                label.location.x = 0.0f;
                label.location.y = row->value;
                label.mode = CChartLabelModeLeft;
                label.fontSize = row->leftLabel.fontSize;
                label.color = row->leftLabel.color;
                label.text = row->leftLabel.text;
                CChartContextDraw(context, (CChart *) &label, rect);
            }
            
            if(row->rightLabel.text){
                label.location.x = 1.0f;
                label.location.y = row->value;
                label.mode = CChartLabelModeRight;
                label.fontSize = row->rightLabel.fontSize;
                label.color = row->rightLabel.color;
                label.text = row->rightLabel.text;
                CChartContextDraw(context, (CChart *) &label, rect);
            }
        }
        
        for(i=0;i<form->columnCount;i++){
            
            column = form->columns + i;
            linePoints[0].x = column->value;
            linePoints[0].y = 0.0f;
            linePoints[1].x = column->value;
            linePoints[1].y = 1.0f;
            CChartContextDraw(context, (CChart *) &line, rect);
            
            if(column->label.text){
                label.location.x = column->value;
                label.location.y = 0.0f;
                if( i== 0){
                    label.mode = CChartLabelModeBottom | CChartLabelModeRight;
                }
                else if( i == form->columnCount -1){
                    label.mode = CChartLabelModeBottom | CChartLabelModeLeft;
                }
                else{
                    label.mode = CChartLabelModeBottom;
                }
                label.fontSize = column->label.fontSize;
                label.color = column->label.color;
                label.text = column->label.text;
                CChartContextDraw(context, (CChart *) &label, rect);
            }
        }
        
        CChartContextDraw(context, (CChart *) &border, rect);
        
        for(i=0;i<form->items.length;i++){
            formItem = (CChartStockFormItem *) (form->items.values + i);
            formItem->form = form;
            CChartContextDraw(context, (CChart *) formItem, rect);
        }
        
        if(form->minTipValue.text && form->minTipValue.fontSize >0){
            
            tipLabel.fontSize = form->minTipValue.fontSize;
            tipLabel.color = form->minTipValue.color;
            tipLabel.lineColor = form->minTipValue.lineColor;
            tipLabel.lineWidth = 1;
            tipLabel.distance = 0.02;
            tipLabel.text = form->minTipValue.text;
            tipLabel.location.x = (form->minTipValue.xValue - form->minXValue) / (form->maxXValue - form->minXValue);
            tipLabel.location.y = (form->minTipValue.yValue - form->minYValue) / (form->maxYValue - form->minYValue);
            
            textSize = CChartLabelSize(tipLabel.text, tipLabel.fontSize);
            textSize = CChartContextRelativeSize(context, textSize);
            
            if(tipLabel.location.x + textSize.width + tipLabel.distance >= 0.98){
                tipLabel.mode = CChartLabelModeLeft;
            }
            else{
                tipLabel.mode = CChartLabelModeRight;
            }
            
            CChartContextDraw(context, (CChart *) & tipLabel, rect);
        }
        
        if(form->maxTipValue.text && form->maxTipValue.fontSize >0){
            
            tipLabel.fontSize = form->maxTipValue.fontSize;
            tipLabel.color = form->maxTipValue.color;
            tipLabel.lineColor = form->maxTipValue.lineColor;
            tipLabel.lineWidth = 1;
            tipLabel.distance = 0.02;
            tipLabel.text = form->maxTipValue.text;
            tipLabel.location.x = (form->maxTipValue.xValue - form->minXValue) / (form->maxXValue - form->minXValue);
            tipLabel.location.y = (form->maxTipValue.yValue - form->minYValue) / (form->maxYValue - form->minYValue);
            
            textSize = CChartLabelSize(tipLabel.text, tipLabel.fontSize);
            textSize = CChartContextRelativeSize(context, textSize);
            
            if(tipLabel.location.x + textSize.width + tipLabel.distance >= 0.98){
                tipLabel.mode = CChartLabelModeLeft;
            }
            else{
                tipLabel.mode = CChartLabelModeRight;
            }
            
            CChartContextDraw(context, (CChart *) & tipLabel, rect);
            
        }
        
        if(form->focusValue.location.x >=0.0f && form->focusValue.location.x <= 1.0f && form->focusValue.xLine.width > 0.0f){
            
            for(i=0;i<form->length;i++){
                formValue = form->xValues + i;
                if(formValue->yValue >= 0.0){
                    v2 = (formValue->xValue - form->minXValue) / (form->maxXValue - form->minXValue);
                    if(i ==0){
                        v1 = v2;
                    }
                    if(v2 >= form->focusValue.location.x){
                        break;
                    }
                }
                else{
                    break;
                }
            }
            
            if(i >= form->length){
                i = form->length - 1;
            }
            else{
                if(v2 - form->focusValue.location.x > form->focusValue.location.x - v1){
                    i = i -1;
                }
            }
            
            if(i >=0 ){
                
                formValue = form->xValues + i;
                
                linePoints[0].x = linePoints[1].x = (formValue->xValue - form->minXValue) / (form->maxXValue - form->minXValue);
                linePoints[0].y = 0.0f;
                linePoints[1].y = 1.0f;
                
                line.width = form->focusValue.xLine.width;
                line.color = form->focusValue.xLine.color;
                
                CChartContextDraw(context, (CChart *) & line, rect);
                
                if(form->focusValue.yLine.width > 0.0f){
                    
                    linePoints[0].y = linePoints[1].y = (formValue->yValue - form->minYValue) / (form->maxYValue - form->minYValue);
                    linePoints[0].x = 0.0f;
                    linePoints[1].x = 1.0f;
                    
                    line.width = form->focusValue.yLine.width;
                    line.color = form->focusValue.yLine.color;
                    
                    CChartContextDraw(context, (CChart *) & line, rect);
                    
                }
                
                if(form->focusValue.xLabel.fontSize > 0.0f && formValue->xText){
                    
                    tipLabel.fontSize = form->focusValue.xLabel.fontSize;
                    tipLabel.color = form->focusValue.xLabel.textColor;
                    tipLabel.lineColor = form->focusValue.xLabel.color;
                    tipLabel.fillColor = form->focusValue.xLabel.color;
                    tipLabel.lineWidth = 1;
                    tipLabel.distance = 0.0f;
                    tipLabel.text = formValue->xText;
                    tipLabel.location.x = (formValue->xValue - form->minXValue) / (form->maxXValue - form->minXValue);
                    tipLabel.location.y = 1.0f;
                    
                    textSize = CChartLabelSize(tipLabel.text, tipLabel.fontSize);
                    textSize = CChartContextRelativeSize(context, textSize);
                    
                    if(tipLabel.location.x + textSize.width + tipLabel.distance >= 0.98){
                        tipLabel.mode = CChartLabelModeLeft;
                    }
                    else{
                        tipLabel.mode = CChartLabelModeRight;
                    }
                    
                    CChartContextDraw(context, (CChart *) & tipLabel, rect);

                }
                
                if(form->focusValue.yLabel.fontSize > 0.0f && formValue->yText){
                    
                    tipLabel.fontSize = form->focusValue.yLabel.fontSize;
                    tipLabel.color = form->focusValue.yLabel.textColor;
                    tipLabel.lineColor = form->focusValue.yLabel.color;
                    tipLabel.fillColor = form->focusValue.yLabel.color;
                    tipLabel.lineWidth = 1;
                    tipLabel.distance = 0.0f;
                    tipLabel.text = formValue->yText;
                    tipLabel.location.y = (formValue->yValue - form->minYValue) / (form->maxYValue - form->minYValue);
                    tipLabel.location.x = 0.0f;
                    tipLabel.mode = CChartLabelModeLeft;
                    
                    CChartContextDraw(context, (CChart *) & tipLabel, rect);
                    
                }
                
            }
        }
        

    }
}

CChartClass CChartStockFormClass = {(CChartDraw)CChartStockFormClassDraw,sizeof(CChartStockForm)};

static void CChartStockClassDraw(CChartContext * context,CChartStock * stockChart,CChartRect rect){
    if(context && stockChart){
        int i;
        CChartStockForm * form;
        CChartRect r;
        CChartFloat x,y;
        
        x = rect.size.width * stockChart->focusValue.location.x;
        y = rect.size.height * stockChart->focusValue.location.y;
        
        for(i=0;i<stockChart->forms.length;i++){
            form = stockChart->forms.values + i;
            form->stock = stockChart;
            r = CChartRectMakeRelative(rect.size, form->rect);
            
            form->focusValue.location = CChartPointMake((x - r.origin.x) / r.size.width, (y - r.origin.y) / r.size.height);
            
            r.origin.x += rect.origin.x;
            r.origin.y += rect.origin.y;
            if(r.origin.x + r.size.width > rect.size.width){
                r.size.width = rect.size.width - r.origin.x;
            }
            if(r.origin.y + r.size.height > rect.size.height){
                r.size.height = rect.size.height - r.origin.y;
            }
        
            CChartContextDraw(context, (CChart *) form, r);
        }
    }
}

CChartClass CChartStockClass = {(CChartDraw) CChartStockClassDraw,sizeof(CChartStock)};


static void CChartStockFormItemLineClassDraw(CChartContext * context,CChartStockFormItemLine * formItem,CChartRect rect){
    if(context && formItem){
        
        CChartStockForm * form = formItem->base.form;
        CChartFloat xMinValue = form->minXValue;
        CChartFloat xMaxValue = form->maxXValue;
        CChartFloat yMinValue = form->minYValue;
        CChartFloat yMaxValue = form->maxYValue;
        CChartFloat xValue,yValue;
        
        CChartPoint *p;
        CChartUInteger i;
        CChartLine line = {{&CChartLineClass},{NULL,0},formItem->width,formItem->color};
        CChartStockFormItemLineValue * v;
        CChartStockFormValue * formXValue;
        
        line.path.points = malloc(sizeof(CChartPoint) * form->length) ;
        
        if(formItem->values){
			for(i=0;i<form->length;i++){
				v = formItem->values + i;
				if(v->value >= 0.0f){
					formXValue = form->xValues  + i;
					xValue = formXValue->xValue;
					yValue = v->value;

					p = line.path.points + line.path.length;
					p->x = (xValue - xMinValue) / (xMaxValue - xMinValue);
					p->y = (yValue - yMinValue) / (yMaxValue - yMinValue);

					line.path.length ++;
				}
			}

			CChartContextDraw(context, (CChart *) &line, rect);
        }
        
        free(line.path.points);
        
    }
}


CChartClass CChartStockFormItemLineClass = {(CChartDraw) CChartStockFormItemLineClassDraw,sizeof(CChartStockFormItemLine)};

static void CChartStockFormItemKLineClassDraw(CChartContext * context,CChartStockFormItemKLine * formItem,CChartRect rect){
    if(context && formItem){
        
        CChartStockForm * form = formItem->base.form;
        CChartFloat xMinValue = form->minXValue;
        CChartFloat xMaxValue = form->maxXValue;
        CChartFloat yMinValue = form->minYValue;
        CChartFloat yMaxValue = form->maxYValue;

        CChartUInteger i;
        CChartKLine kline = {{&CChartKLineClass}};
        
        CChartStockFormValue * xValue;
        CChartStockFormItemKLineValue * v;
        
        if(formItem->values){
			for(i=0;i<form->length;i++){

				v = formItem->values + i;

				if(v->value >= 0.0){
					xValue = form->xValues + i;

					kline.location.x = (xValue->xValue - xMinValue) / (xMaxValue - xMinValue);
					kline.location.y = (v->value - yMinValue) / (yMaxValue - yMinValue);
					kline.source = (v->startValue - yMinValue) / (yMaxValue - yMinValue);
					kline.min = (v->minValue - yMinValue) / (yMaxValue - yMinValue);
					kline.max = (v->maxValue - yMinValue) / (yMaxValue - yMinValue);
					kline.width = formItem->width;
					kline.color = v->colorValue;

					CChartContextDraw(context, (CChart *) &kline, rect);
				}
			}
        }
        
    }

}


CChartClass CChartStockFormItemKLineClass = {(CChartDraw) CChartStockFormItemKLineClassDraw,sizeof(CChartStockFormItemKLine)};

static void CChartStockFormItemPillarClassDraw(CChartContext * context,CChartStockFormItemPillar * formItem,CChartRect rect){
    if(context && formItem){
        
        CChartStockForm * form = formItem->base.form;
        CChartFloat xMinValue = form->minXValue;
        CChartFloat xMaxValue = form->maxXValue;
        CChartFloat yMinValue = form->minYValue;
        CChartFloat yMaxValue = form->maxYValue;
        
        CChartUInteger i;
        CChartPillar pillar = {{&CChartPillarClass}};
        CChartStockFormItemPillarValue * v;
        CChartStockFormValue * xValue;
        
        if(formItem->values){
            
			for(i=0;i<form->length;i++){

				v = formItem->values + i;

				if(v->value >= 0.0f){

					xValue = form->xValues + i;
					pillar.location.x = (xValue->xValue - xMinValue) / (xMaxValue - xMinValue);
					pillar.location.y = (v->value - yMinValue) / (yMaxValue - yMinValue);
					pillar.width = formItem->width;
					pillar.color = v->colorValue;
                    
					CChartContextDraw(context, (CChart *) &pillar, rect);
				}
			}
        }
    }
}

CChartClass CChartStockFormItemPillarClass = {(CChartDraw) CChartStockFormItemPillarClassDraw,sizeof(CChartStockFormItemPillar)};
