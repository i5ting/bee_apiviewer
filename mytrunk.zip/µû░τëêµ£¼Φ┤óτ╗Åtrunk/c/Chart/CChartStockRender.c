//
//  CChartStockRender.c
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStockRender.h"


void CChartStockRenderDelete(CChartStockRender * const render){
    CChartMakerDelete(&render->maker);
    CChartMakerDelete(&render->dataMaker);
    memset(render,0,sizeof(CChartStockRender));
}

void CChartStockRenderCreate(CChartStockRender * const render,CChartDataObject dataObject){
    
    CChartStock * stock = &render->chart;
    CChartStockForm * form;
    CChartDataObject formDataObjects;
    CChartDataObject formDataObject;
    CChartDataObject formItemDataObjects;
    CChartDataObject formItemDataObject;
    
    CChartString formItemType;
    CChartStockFormItemLine * itemLine;
    CChartStockFormItemKLine * itemKLine;
    CChartStockFormItemPillar * itemPillar;
    
    int i,n,length;
    
    stock->base.clazz = &CChartStockClass;
    
    formDataObjects = CChartDataObjectValueForKeyPath(dataObject,"forms");
    
    stock->forms.length = CChartDataObjectUIntegerValueForKeyPath(formDataObjects, "length",0);
    
    if(stock->forms.length >0){
        
        stock->forms.values = CChartMakerCreate(&render->maker, CChartStockForm,stock->forms.length);
        
        for(i=0;i<stock->forms.length;i++){
            
            form = stock->forms.values + i;
            form->base.clazz = &CChartStockFormClass;
            
            CChartDataObjectPoolBegin();
            
            formDataObject = CChartDataObjectValueAtIndex(formDataObjects, i);
        
            form->rect = CChartDataObjectRelativeRectValue(formDataObject);
            
            form->dataKey = CChartMakerCreateString(&render->maker, CChartDataObjectStringValueForKeyPath(formDataObject, "dataKey",NULL));
            
            form->backgroundColor = CChartDataObjectColorValueForKeyPath(formDataObject, "backgroundColor");
            form->borderColor = CChartDataObjectColorValueForKeyPath(formDataObject, "borderColor");
            form->borderWidth = CChartDataObjectFloatValueForKeyPath(formDataObject, "borderWidth",0);
            form->lineColor = CChartDataObjectColorValueForKeyPath(formDataObject, "lineColor");
            form->lineWidth = CChartDataObjectFloatValueForKeyPath(formDataObject, "lineWidth",0);
            form->fallColor = CChartDataObjectColorValueForKeyPath(formDataObject, "fallColor");
            form->riseColor = CChartDataObjectColorValueForKeyPath(formDataObject, "riseColor");
            form->curColor = CChartDataObjectColorValueForKeyPath(formDataObject, "curColor");
            form->timeColor = CChartDataObjectColorValueForKeyPath(formDataObject, "timeColor");
            form->fontSize = CChartDataObjectFloatValueForKeyPath(formDataObject, "fontSize",12);
            form->maxTipValue.fontSize = form->minTipValue.fontSize = form->fontSize;
            form->maxTipValue.color = form->minTipValue.color = form->curColor;
            form->maxTipValue.lineColor = form->minTipValue.lineColor = form->borderColor;
            form->focusValue.xLine.color = CChartDataObjectColorValueForKeyPath(formDataObject, "focusValue.xLine.color");
            form->focusValue.xLine.width = CChartDataObjectFloatValueForKeyPath(formDataObject, "focusValue.xLine.width",0.0f);
            form->focusValue.yLine.color = CChartDataObjectColorValueForKeyPath(formDataObject, "focusValue.yLine.color");
            form->focusValue.yLine.width = CChartDataObjectFloatValueForKeyPath(formDataObject, "focusValue.yLine.width",0.0f);
            
            form->focusValue.xLabel.fontSize = CChartDataObjectFloatValueForKeyPath(formDataObject, "focusValue.xLabel.fontSize",0.0f);
            form->focusValue.xLabel.color = CChartDataObjectColorValueForKeyPath(formDataObject, "focusValue.xLabel.color");
            form->focusValue.xLabel.textColor = CChartDataObjectColorValueForKeyPath(formDataObject, "focusValue.xLabel.textColor");
            
            form->focusValue.yLabel.fontSize = CChartDataObjectFloatValueForKeyPath(formDataObject, "focusValue.yLabel.fontSize",0.0f);
            form->focusValue.yLabel.color = CChartDataObjectColorValueForKeyPath(formDataObject, "focusValue.yLabel.color");
            form->focusValue.yLabel.textColor = CChartDataObjectColorValueForKeyPath(formDataObject, "focusValue.yLabel.textColor");
            
            formItemDataObjects = CChartDataObjectValueForKeyPath(formDataObject,"items");
            
            length = CChartDataObjectUIntegerValueForKeyPath(formItemDataObjects, "length",0);
            
            if(length >0){
                
                form->items.values = CChartMakerCreate(&render->maker, CChartStockFormItemUnion,length);
                
                for(n=0;n<length;n++){
                    
                    CChartDataObjectPoolBegin();
                    
                    formItemDataObject =  CChartDataObjectValueAtIndex(formItemDataObjects, n);
                    
                    formItemType = CChartDataObjectStringValueForKeyPath(formItemDataObject, "type", "");
   
                    if(strcmp(formItemType,"line") ==0){
                        
                        itemLine = &form->items.values[form->items.length].line;
                        itemLine->base.base.clazz = & CChartStockFormItemLineClass;
                        itemLine->dataKey = CChartMakerCreateString(&render->maker, CChartDataObjectStringValueForKeyPath(formItemDataObject,"dataKey",NULL));
                        
                        itemLine->color = CChartDataObjectColorValueForKeyPath(formItemDataObject, "color");
                        itemLine->width = CChartDataObjectFloatValueForKeyPath(formItemDataObject, "width",0);
                        

                        
                        form->items.length ++;
                    }
                    else if(strcmp(formItemType, "kline") == 0){
                        
                        itemKLine = &form->items.values[form->items.length].kline;
                        itemKLine->base.base.clazz = & CChartStockFormItemKLineClass;
                        
                        itemKLine->dataKey = CChartMakerCreateString(&render->maker,CChartDataObjectStringValueForKeyPath(formItemDataObject,"dataKey",NULL));
                        
                        itemKLine->fallColor = CChartDataObjectColorValueForKeyPath(formItemDataObject, "fallColor");
                        itemKLine->riseColor = CChartDataObjectColorValueForKeyPath(formItemDataObject, "riseColor");
                        
                        form->items.length ++;
                    }
                    else if(strcmp(formItemType, "pillar") == 0){
                        
                        itemPillar = &form->items.values[form->items.length].pillar;
                        itemPillar->base.base.clazz = & CChartStockFormItemPillarClass;
                        
                        itemPillar->dataKey = CChartMakerCreateString(&render->maker,CChartDataObjectStringValueForKeyPath(formItemDataObject,"dataKey",NULL));
                        itemPillar->fallColor = CChartDataObjectColorValueForKeyPath(formItemDataObject, "fallColor");
                        itemPillar->riseColor = CChartDataObjectColorValueForKeyPath(formItemDataObject, "riseColor");
                        
                        form->items.length ++;
                    }
                    
                    CChartDataObjectPoolEnd();
                }
                
            }
            
            CChartDataObjectPoolEnd();
        }
    }

}

void CChartStockRenderDataUninstall(CChartStockRender * const render){
    int i = 0,n;
    CChartStockForm * form;
    CChartStockFormItemUnion * formItem;
    
    while(i < render->chart.forms.length){
        
        form = render->chart.forms.values + i;
        
        form->rows = NULL;
        form->rowCount = 0;
        form->columns = NULL;
        form->columnCount = 0;
        
        form->xValues = NULL;
        form->length = 0;
        
        n = 0;
        
        while(n < form->items.length){
            
            formItem = form->items.values + n;
            
            if(formItem->chart.clazz ==  & CChartStockFormItemLineClass){
                formItem->line.values = NULL;
            }
            else if(formItem->chart.clazz == & CChartStockFormItemKLineClass){
                formItem->kline.values = NULL;
            }
            else if(formItem->chart.clazz == & CChartStockFormItemPillarClass){
                formItem->pillar.values = NULL;
            }
            
            n++;
        }
        
        i ++;
    }
    
    CChartMakerDelete(&render->dataMaker);
}

void CChartStockRenderDataInstallTimeSharing(CChartStockRender * const render,CChartContext * context,CChartRect rect,CChartDataObject dataObject){

    int i = 0,n,j,length;
    CChartStockForm * form;
    CChartStockFormItemUnion * formItem;
    CChartDataObject items,item;
    CChartStockFormItemLineValue * lineValue;
    CChartStockFormItemPillarValue * pillarValue;
    CChartFloat maxValue,minValue,v,preValue;
    CChartColor fallColor,riseColor,preColor;
    char key[64];
    char text[128];
    
    render->dataObject = dataObject;
    render->rect = rect;
    render->context = context;
    
    while(i < render->chart.forms.length){
        
        form = render->chart.forms.values + i;
        
        CChartDataObjectPoolBegin();
        
        if(form->dataKey){
            
            if(strcmp(form->dataKey, "time-sharing") == 0){
                
                items = CChartDataObjectValueForKeyPath(dataObject, "result.data.data.min");
                
                form->rowCount = 5;
                form->rows = CChartMakerCreate(&render->dataMaker, CChartStockFormRow, form->rowCount);
                for(n=0;n<5;n++){
                    form->rows[n].value = 0.25 * n;
                }
                
                form->columnCount = 5;
                form->columns = CChartMakerCreate(&render->dataMaker, CChartStockFormColumn, form->columnCount);
                for(n=0;n<5;n++){
                    form->columns[n].value = 0.25 * n;
                }
                
                form->columns[0].label.text = "09:30";
                form->columns[0].label.color = form->timeColor;
                form->columns[0].label.fontSize = form->fontSize;
                
                form->columns[1].label.text = "10:30";
                form->columns[1].label.color = form->timeColor;
                form->columns[1].label.fontSize = form->fontSize;
                
                form->columns[2].label.text = "11:30/13:30";
                form->columns[2].label.color = form->timeColor;
                form->columns[2].label.fontSize = form->fontSize;
                
                form->columns[3].label.text = "14:30";
                form->columns[3].label.color = form->timeColor;
                form->columns[3].label.fontSize = form->fontSize;
                
                form->columns[4].label.text = "15:30";
                form->columns[4].label.color = form->timeColor;
                form->columns[4].label.fontSize = form->fontSize;
                
                form->length = 160;
                form->xValues = CChartMakerCreate(&render->dataMaker, CChartStockFormValue, form->length);
                
                for(n=0;n<form->length;n++){
                    
                    CChartDataObjectPoolBegin();
                    
                    form->xValues[n].xValue = n ;
                    
                    sprintf(key, "%d",n +1);
                    
                    item = CChartDataObjectValueForKeyPath(items,key);
                    
                    form->xValues[n].yValue = CChartDataObjectFloatValueForKeyPath(item,"price",-1.0);
                    
                    form->xValues[n].xText = CChartMakerCreateString(&render->dataMaker, CChartDataObjectStringValueForKeyPath(item,"mintime",NULL));
                    
                    sprintf(text, "%.2f",form->xValues[n].yValue);
                    
                    form->xValues[n].yText = CChartMakerCreateString(&render->dataMaker, text);
                    
                    CChartDataObjectPoolEnd();
                }
                
  
                form->minXValue = -1;
                form->maxXValue = form->length;
                
                length = CChartDataObjectUIntegerValueForKeyPath(items, "length",0);
                
                n = 0;
                
                minValue = maxValue = 0.0;
                
                while(n < length){
                    
                    CChartDataObjectPoolBegin();
                    
                    sprintf(key, "%d",n +1);
                    
                    item = CChartDataObjectValueForKeyPath(items,key);
                    
                    v = CChartDataObjectFloatValueForKeyPath(item,"price",0.0);
                    
                    if(n == 0){
                        minValue = maxValue = v;
                    }
                    else {
                        if(v < minValue){
                            minValue = v;
                        }
                        if(v > maxValue){
                            maxValue = v;
                        }
                    }
                    
                    v = CChartDataObjectFloatValueForKeyPath(item,"avg_price",0.0);
                    
                    if(v < minValue){
                        minValue = v;
                    }
                    if(v > maxValue){
                        maxValue = v;
                    }
                    
                    CChartDataObjectPoolEnd();
                    
                    n++;
                }
                
                v = (maxValue - minValue) * 0.2;
                
                form->minYValue = minValue - v;
                form->maxYValue = maxValue + v;
                
                n = 0;
                
                while(n < form->items.length){
                    
                    formItem = form->items.values + n;
    
                    if(formItem->chart.clazz ==  & CChartStockFormItemLineClass){
                        
                        formItem->line.values = CChartMakerCreate(&render->dataMaker, CChartStockFormItemLineValue, form->length);
                        
                        for(j=0;j<form->length;j++){
                            lineValue = formItem->line.values + j;
                            CChartDataObjectPoolBegin();
                            sprintf(key, "%d",j +1);
                            item = CChartDataObjectValueForKeyPath(items,key);
                            if(item){
                                lineValue->value = CChartDataObjectFloatValueForKeyPath(item, formItem->line.dataKey, 0.0f);
                            }
                            else{
                                lineValue->value = -1;
                            }
                            CChartDataObjectPoolEnd();
                        }
                        
                    }
                    
                    n++;
                }
                 
                
            }
            else if(strcmp(form->dataKey, "volume") == 0){
                
                items = CChartDataObjectValueForKeyPath(dataObject, "result.data.data.min");
                
                form->rowCount = 0;
                form->rows = NULL;
                
                form->columnCount = 5;
                form->columns = CChartMakerCreate(&render->dataMaker, CChartStockFormColumn, form->columnCount);
                for(n=0;n<5;n++){
                    form->columns[n].value = 0.25 * n;
                }
                
                form->length = 160;
                form->xValues = CChartMakerCreate(&render->dataMaker, CChartStockFormValue, form->length);
                
                for(n=0;n<form->length;n++){
                    
                    CChartDataObjectPoolBegin();
                    
                    form->xValues[n].xValue = n;
                    
                    sprintf(key, "%d",n +1);
                    
                    item = CChartDataObjectValueForKeyPath(items,key);
                    
                    form->xValues[n].yValue = CChartDataObjectFloatValueForKeyPath(item,"volume",-1.0);
                    
                    form->xValues[n].xText = CChartMakerCreateString(&render->dataMaker, CChartDataObjectStringValueForKeyPath(item,"mintime",NULL));
                    
                    sprintf(text, "%.2f",form->xValues[n].yValue);
                    
                    form->xValues[n].yText = CChartMakerCreateString(&render->dataMaker, text);
                    
                    CChartDataObjectPoolEnd();
                }
                
                
                
                form->minXValue = -1;
                form->maxXValue = form->length;
                
                length = CChartDataObjectUIntegerValueForKeyPath(items, "length",0);
                
                n = 0;
                
                minValue = maxValue = 0.0;
                
                while(n < length){
                    
                    CChartDataObjectPoolBegin();
                    
                    sprintf(key, "%d",n +1);
                    
                    item = CChartDataObjectValueForKeyPath(items,key);
                    
                    v = CChartDataObjectFloatValueForKeyPath(item,"volume",0.0);
                    
                    if(n == 0){
                        minValue = maxValue = v;
                    }
                    else {
                        if(v < minValue){
                            minValue = v;
                        }
                        if(v > maxValue){
                            maxValue = v;
                        }
                    }
    
                    CChartDataObjectPoolEnd();
                    
                    n++;
                }
                
                v = (maxValue - minValue) * 0.2;
                
                form->minYValue = 0;
                form->maxYValue = maxValue + v;
                
                n = 0;
                
                while(n < form->items.length){
                    
                    formItem = form->items.values + n;
                    
                    if(formItem->chart.clazz ==  & CChartStockFormItemPillarClass){
                        
                        fallColor = formItem->pillar.fallColor;
                        riseColor = formItem->pillar.riseColor;
                        
                        formItem->pillar.width = 0.5 / form->length ;
                        
                        formItem->pillar.values = CChartMakerCreate(&render->dataMaker, CChartStockFormItemPillarValue, form->length);
                        
                        preValue = 0.0;
                        preColor = riseColor;
                        
                        for(j=0;j<form->length;j++){
                            
                            CChartDataObjectPoolBegin();
                            
                            pillarValue = formItem->pillar.values + j;
                            sprintf(key, "%d",j +1);
                            item = CChartDataObjectValueForKeyPath(items,key);
                            if(item){
                                v = CChartDataObjectFloatValueForKeyPath(item,"price",0.0f);
                                if(v == preValue){
                                    pillarValue->colorValue = preColor;
                                }
                                else if(v > preValue){
                                    pillarValue->colorValue = riseColor;
                                }
                                else{
                                    pillarValue->colorValue = fallColor;
                                }
                                preValue = v;
                                preColor = pillarValue->colorValue;
                                pillarValue->value = CChartDataObjectFloatValueForKeyPath(item, formItem->pillar.dataKey, 0.0f);
                            }
                            else{
                                pillarValue->value = -1;
                            }
                            
                            CChartDataObjectPoolEnd();
                        }
                        
                    }
                    
                    n++;
                }

            }
        }
        
        CChartDataObjectPoolEnd();
        
        i ++;
    }

}

void CChartStockRenderDataInstallKLine(CChartStockRender * const render,CChartContext * context,CChartRect rect,CChartDataObject dataObject,CChartUInteger location,CChartUInteger length){
    int i = 0,n,j,c,k;
    CChartStockForm * form;
    CChartStockFormItemUnion * formItem;
    CChartDataObject items,item;
    CChartStockFormItemLineValue * lineValue;
    CChartStockFormItemPillarValue * pillarValue;
    CChartStockFormItemKLineValue * klineValue;
    CChartFloat maxValue,minValue,v,preValue,minIndex,maxIndex;
    CChartColor fallColor,riseColor,preColor;
    char tip[128];
    char text[128];
    
    render->dataObject = dataObject;
    render->rect = rect;
    render->context = context;
    
    if(length <=0){
        return;
    }
    
    while(i < render->chart.forms.length){
        
        form = render->chart.forms.values + i;
       
        CChartDataObjectPoolBegin();
        
        if(form->dataKey){
            
            if(strcmp(form->dataKey, "kline") == 0){
                
                items = CChartDataObjectValueForKeyPath(dataObject, "result.data.data");
                
                form->rowCount = 5;
                form->rows = CChartMakerCreate(&render->dataMaker, CChartStockFormRow, form->rowCount);
                for(n=0;n<5;n++){
                    form->rows[n].value = 0.25 * n;
                }
                
                
                form->columnCount = 5;
                form->columns = CChartMakerCreate(&render->dataMaker, CChartStockFormColumn, form->columnCount);
                for(n=0;n<5;n++){
                    form->columns[n].value = 0.25 * n;
                }
                
                form->length = length;
                form->xValues = CChartMakerCreate(&render->dataMaker, CChartStockFormValue, form->length);
                
                for(n=0;n<form->length;n++){
                    
                    CChartDataObjectPoolBegin();
                    
                    form->xValues[n].xValue = n ;
                    
                    item = CChartDataObjectValueAtIndex(items, n +location);
                    
                    form->xValues[n].yValue = CChartDataObjectFloatValueForKeyPath(item,"close",-1.0);
                    
                    form->xValues[n].xText = CChartMakerCreateString(&render->dataMaker, CChartDataObjectStringValueForKeyPath(item,"day",NULL));
                    
                    sprintf(text, "%.2f",form->xValues[n].yValue);
                    
                    form->xValues[n].yText = CChartMakerCreateString(&render->dataMaker, text);
                    
                    CChartDataObjectPoolEnd();

                }
                
                form->minXValue = - 1.0f;
                form->maxXValue = form->length ;
                
                n = 0;
                
                minValue = maxValue = 0.0;
                minIndex = maxIndex = 0;
                
                while(n < form->length){
                    
                    CChartDataObjectPoolBegin();
                    
                    item = CChartDataObjectValueAtIndex(items, n +location);
                    
                    v = CChartDataObjectFloatValueForKeyPath(item,"high",0.0);
                    
                    if(n == 0){
                        minValue = maxValue = v;
                        minIndex = maxIndex = n;
                    }
                    else {
                        if(v < minValue){
                            minValue = v;
                            minIndex = n;
                        }
                        if(v > maxValue){
                            maxValue = v;
                            maxIndex = n;
                        }
                    }
                    
                    v = CChartDataObjectFloatValueForKeyPath(item,"low",0.0);
                    
                    if(v < minValue){
                        minValue = v;
                        minIndex = n;
                    }
                    if(v > maxValue){
                        maxValue = v;
                        maxIndex = n;
                    }
                    
                    CChartDataObjectPoolEnd();
                    
                    n++;
                }
                
                form->minTipValue.xValue = minIndex;
                form->minTipValue.yValue = minValue;
                
                sprintf(tip, "%.2f",minValue);
                
                form->minTipValue.text = CChartMakerCreateString(&render->dataMaker, tip);
                
                form->maxTipValue.xValue = maxIndex;
                form->maxTipValue.yValue = maxValue;
                
                sprintf(tip, "%.2f",maxValue);
                
                form->maxTipValue.text = CChartMakerCreateString(&render->dataMaker, tip);
                
                n = 0;
                
                while(n < form->items.length){
                    
                    formItem = form->items.values + n;
                    
                    CChartDataObjectPoolBegin();
                    
                    if(formItem->chart.clazz ==  & CChartStockFormItemKLineClass){
                        
                        fallColor = formItem->kline.fallColor;
                        riseColor = formItem->kline.riseColor;
                        
                        formItem->kline.values = CChartMakerCreate(&render->dataMaker, CChartStockFormItemKLineValue, form->length);
                        formItem->kline.width = 0.5 / form->length;
                        
                        if((int)location - 1 >=0){
                            item = CChartDataObjectValueAtIndex(items,location -1);
                            preValue = CChartDataObjectFloatValueForKeyPath(item, "close", 0.0f);
                            preColor = riseColor;
                        }
                        else{
                            preValue = 0.0;
                            preColor = riseColor;
                        }
                        
                        for(j=0;j<form->length;j++){
                            
                            CChartDataObjectPoolBegin();
                            
                            klineValue = formItem->kline.values + j;
                            item = CChartDataObjectValueAtIndex(items,j + location);
                            if(item){
                                klineValue->value = CChartDataObjectFloatValueForKeyPath(item, "close", 0.0f);
                                klineValue->startValue = CChartDataObjectFloatValueForKeyPath(item, "open", 0.0f);
                                klineValue->minValue = CChartDataObjectFloatValueForKeyPath(item, "low", 0.0f);
                                klineValue->maxValue = CChartDataObjectFloatValueForKeyPath(item, "high", 0.0f);
                                
                                if(klineValue->value == preValue){
                                    klineValue->colorValue = preColor;
                                }
                                else if(klineValue->value > preValue){
                                    klineValue->colorValue = riseColor;
                                }
                                else{
                                    klineValue->colorValue = fallColor;
                                }
                                
                                preValue = klineValue->value;
             
                            }
                            else{
                                klineValue->value = -1;
                            }
                            
                            CChartDataObjectPoolEnd();
                        }
                        
                    }
                    else if(formItem->chart.clazz ==  & CChartStockFormItemLineClass){
                        
                        c = atoi(formItem->line.dataKey);
                        
                        formItem->line.values = CChartMakerCreate(&render->dataMaker, CChartStockFormItemLineValue, form->length);
                        
                        for(j=0;j<form->length;j++){
                            
                            CChartDataObjectPoolBegin();
                            
                            lineValue = formItem->line.values + j;
                            item = CChartDataObjectValueAtIndex(items,j + location);
                            if(item){
                                
                                lineValue->value = CChartDataObjectFloatValueForKeyPath(item, "close", 0.0f);
                                
                                k = 1;
                                
                                while(k < c){
                                    
                                    if(j + (int)location - k >=0){
                                        item = CChartDataObjectValueAtIndex(items,j + location - k);
                                        lineValue->value += CChartDataObjectFloatValueForKeyPath(item, "close", 0.0f);
                                    }
                                    else{
                                        break;
                                    }
                                    k ++;
                                }
                                
                                lineValue->value = lineValue->value / k;
                                
                                if(lineValue->value > maxValue){
                                    maxValue = lineValue->value;
                                }
                                if(lineValue->value < minValue){
                                    minValue = lineValue->value;
                                }
                            }
                            else{
                                lineValue->value = -1;
                            }
                            
                            CChartDataObjectPoolEnd();
                        }
                        
                    }
                    
                    CChartDataObjectPoolEnd();
                    
                    n++;
                }
                
                v = (maxValue - minValue) * 0.2;
                
                form->minYValue = minValue - v;
                form->maxYValue = maxValue + v;
                
            }
            else if(strcmp(form->dataKey, "volume") == 0){
                
                items = CChartDataObjectValueForKeyPath(dataObject, "result.data.data");
                
                form->rowCount = 0;
                form->rows = NULL;
                
                form->columnCount = 5;
                form->columns = CChartMakerCreate(&render->dataMaker, CChartStockFormColumn, form->columnCount);
                for(n=0;n<5;n++){
                    form->columns[n].value = 0.25 * n;
                }
                
                form->length = length;
                form->xValues = CChartMakerCreate(&render->dataMaker, CChartStockFormValue, form->length);
                
                for(n=0;n<form->length;n++){
                    form->xValues[n].xValue = n;
                    
                    CChartDataObjectPoolBegin();
                    
                    item = CChartDataObjectValueAtIndex(items, n + location);
                    
                    form->xValues[n].yValue = CChartDataObjectFloatValueForKeyPath(item,"volume",-1.0);
                    
                    form->xValues[n].xText = CChartMakerCreateString(&render->dataMaker, CChartDataObjectStringValueForKeyPath(item,"day",NULL));
                    
                    if((int)(form->xValues[n].yValue / 10000000000.0f)){
                        sprintf(text, "%.2f 亿",form->xValues[n].yValue/ 10000000000.0f);
                    }
                    else if((int)(form->xValues[n].yValue / 1000000.0f)){
                        sprintf(text, "%.2f 万",form->xValues[n].yValue/ 1000000.0f);
                    }
                    else{
                        sprintf(text, "%.2f",form->xValues[n].yValue);
                    }
                    
                    form->xValues[n].yText = CChartMakerCreateString(&render->dataMaker, text);
                    
                    CChartDataObjectPoolEnd();
                }
 
                
                form->minXValue = -1;
                form->maxXValue = length;
                
                n = 0;
                
                minValue = maxValue = 0.0;
                
                while(n < form->length){
                    
                    CChartDataObjectPoolBegin();
                    
                    item = CChartDataObjectValueAtIndex(items, n + location);
                    
                    v = CChartDataObjectFloatValueForKeyPath(item,"volume",0.0);
                    
                    if(n == 0){
                        minValue = maxValue = v;
                    }
                    else {
                        if(v < minValue){
                            minValue = v;
                        }
                        if(v > maxValue){
                            maxValue = v;
                        }
                    }
                    
                    CChartDataObjectPoolEnd();
                    
                    n++;
                }
                
                v = (maxValue - minValue) * 0.2;
                
                form->minYValue = 0;
                form->maxYValue = maxValue + v;
                
                n = 0;
                
                while(n < form->items.length){
                    
                    formItem = form->items.values + n;
                    
                    CChartDataObjectPoolBegin();
                    
                    if(formItem->chart.clazz ==  & CChartStockFormItemPillarClass){
                        
                        fallColor = formItem->pillar.fallColor;
                        riseColor = formItem->pillar.riseColor;
                        
                        formItem->pillar.width = 0.5 / form->length ;
                        
                        formItem->pillar.values = CChartMakerCreate(&render->dataMaker, CChartStockFormItemPillarValue, form->length);
                        
                        
                        if((int)location - 1 >=0){
                            item = CChartDataObjectValueAtIndex(items,location -1);
                            preValue = CChartDataObjectFloatValueForKeyPath(item, "close", 0.0f);
                            preColor = riseColor;
                        }
                        else{
                            preValue = 0.0;
                            preColor = riseColor;
                        }
                        
                        for(j=0;j<form->length;j++){
                            
                            CChartDataObjectPoolBegin();
                            
                            pillarValue = formItem->pillar.values + j;
                            item = CChartDataObjectValueAtIndex(items, j + location);
                            if(item){
                                v = CChartDataObjectFloatValueForKeyPath(item,"close",0.0f);
                                if(v == preValue){
                                    pillarValue->colorValue = preColor;
                                }
                                else if(v > preValue){
                                    pillarValue->colorValue = riseColor;
                                }
                                else{
                                    pillarValue->colorValue = fallColor;
                                }
                                preValue = v;
                                preColor = pillarValue->colorValue;
                                pillarValue->value = CChartDataObjectFloatValueForKeyPath(item, "volume", 0.0f);
                            }
                            else{
                                pillarValue->value = -1;
                            }
                            
                            CChartDataObjectPoolEnd();
                        }
                        
                    }
                    
                    CChartDataObjectPoolEnd();
                    
                    n++;
                }
                
            }
        }
        
        CChartDataObjectPoolEnd();
        
        i ++;
    }
}

CChartBoolean CChartStockRenderIsDataInstall(CChartStockRender * const render,CChartContext * context,CChartRect rect,CChartDataObject dataObject){
    return render->context == context && CChartRectEqual(render->rect,rect) && render->dataObject == dataObject;
}
