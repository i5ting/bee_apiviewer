//
//  IOSChartStock.h
//  IOSChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <Chart/IOSChart.h>
#import <Chart/IOSChartData.h>
#import <Chart/IOSChartStockData.h>

#include <Chart/CChartStock.h>
#include <Chart/CChartStockData.h>
#include <Chart/CChartStockStyle.h>


@interface IOSChartStock : IOSChart

@property(nonatomic,readonly) CChartStyle * cStyle;
@property(nonatomic,readonly) CChartStock * cChart;
@property(nonatomic,assign,getter = isDisabledScroll) BOOL disabledScroll;
@property(nonatomic,assign,getter = isDisabledScale) BOOL disabledScale;
@property(nonatomic,assign,getter = isDisabledFocus) BOOL disabledFocus;
@property(nonatomic,assign) NSInteger minLength;
@property(nonatomic,assign) NSInteger maxLength;

@property(nonatomic,assign) IBOutlet id dataSource;
@property(nonatomic,retain) IBOutlet IOSChartStockData * data;

@property(nonatomic,retain) IBOutlet id nibLayoutData;
@property(nonatomic,retain) NSString * plistLayout;

-(void) loadLayoutData:(id) layoutData;

@end

@protocol IOSChartStockDataSource <NSObject>

-(CChartStockData *) IOSChartStockData:(IOSChartStock *) chartStock;

@end
