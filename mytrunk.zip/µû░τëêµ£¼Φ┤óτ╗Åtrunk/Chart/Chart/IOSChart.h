//
//  IOSChart.h
//  IOSChart
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <Chart/CChart.h>


@interface IOSChart : NSObject

@property(nonatomic,retain) id left;
@property(nonatomic,retain) id top;
@property(nonatomic,retain) id right;
@property(nonatomic,retain) id bottom;
@property(nonatomic,retain) id width;
@property(nonatomic,retain) id height;
@property(nonatomic,assign) id delegate;

-(CChartRect) frame:(CChartContext *) chartContext;

-(void) drawChart:(CChartContext *) chartContext;


-(void) scrollBegin;

-(void) scrollValueChanged:(CGPoint) value;

-(void) scrollEnd;

-(void) focusBegin:(CGPoint) value;

-(void) focusValueChanged:(CGPoint) value;

-(void) focusEnd;

-(void) scaleBegin;

-(void) scaleValueChanged:(CGFloat) scale;

-(void) scaleEnd;

@end

@protocol IOSChartDelegate

@optional

-(void) IOSChartSetNeedRender:(IOSChart *) chart;

@end