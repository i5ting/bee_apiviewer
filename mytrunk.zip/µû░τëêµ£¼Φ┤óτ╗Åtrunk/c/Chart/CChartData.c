//
//  CChartData.c
//  CChart
//
//  Created by zhang hailong on 13-5-8.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartData.h"


CChartFloat CChartDataObjectFloatValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartFloat defaultValue){
    return CChartDataObjectFloatValue(CChartDataObjectValueForKeyPath(object, keyPath),defaultValue);
}

CChartUInteger CChartDataObjectUIntegerValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartUInteger defaultValue){
    return CChartDataObjectUIntegerValue(CChartDataObjectValueForKeyPath(object, keyPath),defaultValue);
}

CChartString CChartDataObjectStringValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartString defaultValue){
    return CChartDataObjectStringValue(CChartDataObjectValueForKeyPath(object, keyPath),defaultValue);
}

CChartColor CChartDataObjectColorValue(CChartDataObject object){
    CChartColor c = {0.0f,0.0f,0.0f,0.0f};
    CChartString v = CChartDataObjectStringValue(object,NULL);
    CChartUInteger r = 0,g=0,b=0;
    CChartFloat a = 1.0f;
    if(v){
        sscanf(v, "#%02x%02x%02x %f",&r,&g,&b,&a);
        c.r = (CChartFloat) r / 0xff;
        c.g = (CChartFloat) g / 0xff;
        c.b = (CChartFloat) b / 0xff;
        c.a = a;
    }
    return c;
}

CChartColor CChartDataObjectColorValueForKeyPath(CChartDataObject object,CChartString keyPath){
    return CChartDataObjectColorValue(CChartDataObjectValueForKeyPath(object,keyPath));
}

CChartDouble CChartDataObjectDoubleValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartDouble defaultValue){
    return CChartDataObjectDoubleValue(CChartDataObjectValueForKeyPath(object,keyPath), defaultValue);
}

CChartInt64 CChartDataObjectInt64ValueForKeyPath(CChartDataObject object,CChartString keyPath,CChartInt64 defaultValue){
    return CChartDataObjectInt64Value(CChartDataObjectValueForKeyPath(object,keyPath), defaultValue);
}

CChartRelativeRect CChartDataObjectRelativeRectValue(CChartDataObject object){
    CChartRelativeRect r = {
        {
            CChartDataObjectFloatValueForKeyPath(object,"left",-1.0f)
            ,CChartDataObjectFloatValueForKeyPath(object,"top",-1.0f)
            ,CChartDataObjectFloatValueForKeyPath(object,"right",-1.0f)
            ,CChartDataObjectFloatValueForKeyPath(object,"bottom",-1.0f)
        }
        ,{
            CChartDataObjectFloatValueForKeyPath(object,"width",-1.0f)
            ,CChartDataObjectFloatValueForKeyPath(object,"height",-1.0f)
        }
    };
    
    return r;
}
