//
//  IOSChartStockDataDayK.m
//  Chart
//
//  Created by zhang hailong on 13-5-17.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartStockDataDayK.h"

@interface IOSChartStockDataDayK(){
    NSDateFormatter * _dateFormatter;
}

@end

@implementation IOSChartStockDataDayK

@synthesize source = _source;

-(id) init{
    if((self = [super init])){
        _dateFormatter = [[NSDateFormatter alloc] init];
    }
    return self;
}

-(void) dealloc{
    [_dateFormatter release];
    [_source release];
    [super dealloc];
}

-(CChartStockData *) cData{
    CChartStockData * data = [super cData];
    if(data->data == NULL){
        CChartStockDataProperty propertys[] = {
            {"close",CChartStockDataPropertyTypeValue,sizeof(CChartFloat)},
            {"open",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"low",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"high",CChartStockDataPropertyTypePrice,sizeof(CChartFloat)},
            {"volume",CChartStockDataPropertyTypeVolume,sizeof(CChartFloat)},
            {"ma5",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),5},
            {"ma10",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),10},
            {"ma30",CChartStockDataPropertyTypeValueMa,sizeof(CChartFloat),30},
            {"timestamp",CChartStockDataPropertyTypeDateTime,sizeof(CChartDateTime)},
        };
        
        CChartStockDataCreate(data, propertys, sizeof(propertys) / sizeof(CChartStockDataProperty));
        
        NSArray * items  = [self.source dataObjectForKeyPath:@"result.data.data"];
        
        CChartStockDataSetDataSize(data, [items count]);
        
        CChartStockDataProperty * prop;
        int c;
        CChartDateTime timestamp = {0};
        
        NSCalendar * calendar = [NSCalendar currentCalendar];
        
        [_dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"];
        
        for( int i=0;i<[items count];i++){
            
            id item = [items objectAtIndex:i];
            
            CChartStockDataItem dataItem = CChartStockDataItemAtIndex(data, i);
            
            prop = data->propertys;
            c  = data->propertyCount;
            
            while(c >0){
                
                if(prop->type == CChartStockDataPropertyTypeDateTime){
                    memset(&timestamp, 0, sizeof(timestamp));
                    NSString * day = [item valueForKey:@"date"];
                    if([day isKindOfClass:[NSString class]]){
                        
                        NSDate * date = [_dateFormatter dateFromString:day];
                        NSDateComponents * comp = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit fromDate:date];
                        
                        timestamp.date.year = comp.year;
                        timestamp.date.month = comp.month;
                        timestamp.date.day = comp.day;
                        timestamp.date.week = comp.weekday;
                        
                        CChartStockDataItemSetPropertyDateTimeValue(data, prop, dataItem, timestamp);
                    }
                }
                else{
                    
                    CChartStockDataItemSetPropertyFloatValue(data, prop, dataItem, [[item valueForKey:[NSString stringWithCString:prop->name encoding:NSUTF8StringEncoding]] floatValue]);
                }
                
                prop ++;
                c --;
            }
        }
        
        if([items count] >100){
            CChartStockDataSetRange(data, [items count] - 100, 100,5);
        }
        else{
            CChartStockDataSetRange(data, 0, [items count],5);
        }
        
    }
    return data;
}

@end
