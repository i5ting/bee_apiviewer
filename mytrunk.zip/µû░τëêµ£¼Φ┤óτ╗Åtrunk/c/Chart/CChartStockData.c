//
//  CChartStockData.c
//  Chart
//
//  Created by zhang hailong on 13-5-14.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChartStockData.h"


CChartStockDataProperty * CChartStockDataGetProperty(CChartStockData * const data,CChartString name){
    int c = data->propertyCount;
    CChartStockDataProperty * prop = data->propertys;
    while(c >0){
        
        if(prop->name == name || strcmp(prop->name, name) ==0){
            return prop;
        }
        prop ++;
        c --;
    }
    return NULL;
}


CChartFloat CChartStockDataItemPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartFloat defaultValue){
    
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeValue:
            case CChartStockDataPropertyTypePrice:
            case CChartStockDataPropertyTypeVolume:
            case CChartStockDataPropertyTypeValueMa:
            case CChartStockDataPropertyTypeVolumeMa:
            {
                return * (CChartFloat *)((char *)dataItem + property->offset);
            }
                break;
                
            default:
                break;
        }
    }
    
    return defaultValue;
}

CChartDate CChartStockDataItemPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDate defaultValue){
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeDate:
            {
                return * (CChartDate *)((char *)dataItem + property->offset);
            }
                break;
            case CChartStockDataPropertyTypeDateTime:
            {
                CChartDateTime v = * (CChartDateTime *)((char *)dataItem + property->offset);
                return v.date;
            }
                break;
            default:
                break;
        }
    }
    
    return defaultValue;
}

CChartTime CChartStockDataItemPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartTime defaultValue){
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeTime:
            {
                return * (CChartTime *)((char *)dataItem + property->offset);
            }
                break;
            case CChartStockDataPropertyTypeDateTime:
            {
                CChartDateTime v = * (CChartDateTime *)((char *)dataItem + property->offset);
                return v.time;
            }
                break;
            default:
                break;
        }
    }
    
    return defaultValue;
}

CChartDateTime CChartStockDataItemPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDateTime defaultValue){
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeTime:
            {
                CChartTime v = * (CChartTime *)((char *)dataItem + property->offset);
                CChartDateTime r = {{0},v};
                return r;
            }
                break;
            case CChartStockDataPropertyTypeDate:
            {
                CChartDate v = * (CChartDate *)((char *)dataItem + property->offset);
                CChartDateTime r = {v,{0}};
                return r;
            }
                break;
            case CChartStockDataPropertyTypeDateTime:
            {
                return * (CChartDateTime *)((char *)dataItem + property->offset);
            }
                break;
            default:
                break;
        }
    }
    
    return defaultValue;
}


void CChartStockDataItemSetPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartFloat value){
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeValue:
            case CChartStockDataPropertyTypePrice:
            case CChartStockDataPropertyTypeVolume:
            case CChartStockDataPropertyTypeValueMa:
            case CChartStockDataPropertyTypeVolumeMa:
            {
                * (CChartFloat *)((char *)dataItem + property->offset) = value;
            }
                break;
                
            default:
                break;
        }
    }
}

void CChartStockDataItemSetPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDate value){
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeDate:
            {
                * (CChartDate *)((char *)dataItem + property->offset) = value;
            }
                break;
            case CChartStockDataPropertyTypeDateTime:
            {
                CChartDateTime * v = (CChartDateTime *)((char *)dataItem + property->offset);
                v->date = value;
            }
                break;
            default:
                break;
        }
    }
}

void CChartStockDataItemSetPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartTime value){
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeTime:
            {
                * (CChartTime *)((char *)dataItem + property->offset) = value;
            }
                break;
            case CChartStockDataPropertyTypeDateTime:
            {
                CChartDateTime * v = (CChartDateTime *)((char *)dataItem + property->offset);
                v->time = value;
            }
                break;
            default:
                break;
        }
    }
}

void CChartStockDataItemSetPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartStockDataItem dataItem,CChartDateTime value){
    if(data && dataItem && property){
        switch (property->type) {
            case CChartStockDataPropertyTypeDateTime:
            {
                * (CChartDateTime *)((char *)dataItem + property->offset) = value;
            }
                break;
            case CChartStockDataPropertyTypeDate:
            {
                CChartDate * v = (CChartDate *)((char *)dataItem + property->offset);
                * v = value.date;
            }
                break;
            default:
                break;
        }
    }
}

CChartStockDataItem CChartStockDataItemAtIndex(CChartStockData * const data,CChartInteger index){
    if(index >=0 && index <data->size){
        return (char *)data->data + data->itemSize * index;
    }
    return NULL;
}

CChartFloat CChartStockDataPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartFloat defaultValue){
    return CChartStockDataItemPropertyFloatValue(data, property, CChartStockDataItemAtIndex(data, index), defaultValue);
}

CChartDate CChartStockDataPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDate defaultValue){
    return CChartStockDataItemPropertyDateValue(data, property, CChartStockDataItemAtIndex(data, index), defaultValue);
}

CChartTime CChartStockDataPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartTime defaultValue){
    return CChartStockDataItemPropertyTimeValue(data, property, CChartStockDataItemAtIndex(data, index), defaultValue);
}

CChartDateTime CChartStockDataPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDateTime defaultValue){
    return CChartStockDataItemPropertyDateTimeValue(data, property, CChartStockDataItemAtIndex(data, index), defaultValue);
}


void CChartStockDataSetPropertyFloatValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartFloat value){
    CChartStockDataItemSetPropertyFloatValue(data,property,CChartStockDataItemAtIndex(data,index),value);
}

void CChartStockDataSetPropertyDateValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDate value){
    CChartStockDataItemSetPropertyDateValue(data,property,CChartStockDataItemAtIndex(data,index),value);
}

void CChartStockDataSetPropertyTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartTime value){
    CChartStockDataItemSetPropertyTimeValue(data,property,CChartStockDataItemAtIndex(data,index),value);
}

void CChartStockDataSetPropertyDateTimeValue(CChartStockData * const data,CChartStockDataProperty * property,CChartInteger index,CChartDateTime value){
    CChartStockDataItemSetPropertyDateTimeValue(data,property,CChartStockDataItemAtIndex(data,index),value);
}


void CChartStockDataCreate(CChartStockData * const data,CChartStockDataProperty * propertys,CChartUInteger propertyCount){
    
    CChartStockDataProperty * p = (CChartStockDataProperty *) malloc(sizeof(CChartStockDataProperty) * propertyCount);
    CChartStockDataProperty * prop = propertys;
    
    data->itemSize = 0;
    data->propertys = p;
    data->propertyCount = propertyCount;
    memset(data->propertys, 0, sizeof(CChartStockDataProperty) * propertyCount);
    
    while(propertyCount >0){
        
        * p = * prop;
        p->offset = data->itemSize;
        data->itemSize += p->size;
        p ++;
        prop ++;
        propertyCount --;
    }
    
}

void CChartStockDataDelete(CChartStockData * const data){
    if(data->data){
        free(data->data);
    }
    if(data->propertys){
        free(data->propertys);
    }
    memset(data, 0, sizeof(CChartStockData));
}

void CChartStockDataSetDataSize(CChartStockData * const data,CChartUInteger size){
    if(data->data){
        if(size > data->size){
            data->data = realloc(data->data, data->itemSize * size);
            memset((char *)data->data + data->size * data->itemSize, 0, (size - data->size) * data->itemSize);
        }
    }
    else {
        data->data = malloc(data->itemSize * size);
        memset(data->data, 0, size * data->itemSize);
    }
    data->size = size;
}

void CChartStockDataSetRange(CChartStockData * const data,CChartInteger location,CChartUInteger length,CChartUInteger columns){
    
    int i,n,c;
    CChartFloat minValue,maxValue,minVolume,maxVolume,value,v;
    CChartUInteger maxMa =0;
    CChartStockDataProperty * prop;
    CChartStockDataProperty * valueProperty = NULL;
    CChartStockDataProperty * volumeProperty = NULL;
    CChartStockDataProperty * timestampProperty = NULL;
    CChartStockDataItem item;
    CChartDateTime beginTimestamp,endTimestamp;
    data->columns.count = columns;
    data->columns.days = data->columns.months = 0;
    data->location = location;
    data->length = length;
    data->minValue = data->maxValue
    = data->minFullValue = data->maxFullValue
    = data->minVolume = data->maxVolume
    = data->minFullVolume = data->maxFullVolume = CCHART_NAN;
    
    if(data->size == 0){
        return;
    }
    
    prop = data->propertys;
    c = data->propertyCount;
    
    while (c >0 && (valueProperty == NULL || volumeProperty == NULL || timestampProperty == NULL)) {
        
        
        switch (prop->type) {
            case CChartStockDataPropertyTypeValue:
            {
                valueProperty = prop;
            }
                break;
            case CChartStockDataPropertyTypeVolume:
            {
                volumeProperty = prop;
            }
                break;
            case CChartStockDataPropertyTypeTime:
            case CChartStockDataPropertyTypeDateTime:
            case CChartStockDataPropertyTypeDate:
            {
                timestampProperty = prop;
            }
                break;
            default:
                break;
        }
        
        
        prop ++;
        c --;
    }
    
    if(timestampProperty){
        beginTimestamp = CChartStockDataPropertyDateTimeValue(data, timestampProperty, 0, CChartDateTimeEmpty);
        endTimestamp = CChartStockDataPropertyDateTimeValue(data, timestampProperty, data->size -1, CChartDateTimeEmpty);
        data->columns.months = (endTimestamp.date.year * 12 + endTimestamp.date.month) - (beginTimestamp.date.year * 12 + beginTimestamp.date.month);
        data->columns.months = data->columns.months * data->length / data->size;
        data->columns.months = data->columns.months / columns;
    }
    
    for(i=0;i<data->length;i++){
        
        item =CChartStockDataItemAtIndex(data, i + location);
        
        if(item == NULL){
            continue;
        }
        
        minValue = maxValue = CCHART_NAN;
        minVolume = maxVolume = CCHART_NAN;
        
        prop = data->propertys;
        c = data->propertyCount;

        while (c >0) {
            

            switch (prop->type) {
                case CChartStockDataPropertyTypeValue:
                case CChartStockDataPropertyTypePrice:
                {
                    v = CChartStockDataItemPropertyFloatValue(data, prop, item, CCHART_NAN);
                    if(v != CCHART_NAN){
                        if(minValue == CCHART_NAN || v < minValue){
                            minValue = v;
                        }
                        if(maxValue == CCHART_NAN || v > maxValue){
                            maxValue = v;
                        }
                    }
                }
                    break;
                case CChartStockDataPropertyTypeVolume:
                {
                    v = CChartStockDataItemPropertyFloatValue(data, prop, item, CCHART_NAN);
                    if(v != CCHART_NAN){
                        if(minVolume == CCHART_NAN || v < minVolume){
                            minVolume = v;
                        }
                        if(maxVolume == CCHART_NAN || v > maxVolume){
                            maxVolume = v;
                        }
                    }
                }
                    break;
                default:
                    break;
            }
 
            
            prop ++;
            c --;
        }
        
        if(minValue != CCHART_NAN){
            if(data->minValue == CCHART_NAN || minValue < data->minValue){
                data->minValue = minValue;
                data->minValueIndex = i + data->location;
            }
        }
        
        if(maxValue != CCHART_NAN){
            if(data->maxValue == CCHART_NAN || maxValue > data->maxValue){
                data->maxValue = maxValue;
                data->maxValueIndex = i + data->location;
            }
        }
        
        if(minVolume != CCHART_NAN){
            if(data->minVolume == CCHART_NAN || minVolume < data->minVolume){
                data->minVolume = minVolume;
            }
        }
        
        if(maxVolume != CCHART_NAN){
            if(data->maxVolume == CCHART_NAN || maxVolume > data->maxVolume){
                data->maxVolume = maxVolume;
            }
        }
                
        prop = data->propertys;
        c = data->propertyCount;
        
        maxMa = 0;
        
        while (c >0) {
            
            switch (prop->type) {
                case CChartStockDataPropertyTypeValueMa:
                {
                    CChartStockDataSetPropertyFloatValue(data, prop, i + location, CCHART_NAN);
                    if(prop->value >  maxMa){
                        maxMa = prop->value;
                    }
                }
                    break;
                default:
                    break;
            }
            
            
            prop ++;
            c --;
        }
        
        if(maxMa >0 && valueProperty){
            
            value = CChartStockDataPropertyFloatValue(data, valueProperty, i + location, CCHART_NAN);
            
            if(value != CCHART_NAN){
            
                for(n = 1;n <= maxMa;n ++){
                    
                    v = value / n ;
                    
                    prop = data->propertys;
                    c = data->propertyCount;
                     
                    while (c >0) {
                        
                        switch (prop->type) {
                            case CChartStockDataPropertyTypeValueMa:
                            {
                                if(prop->value == n){
                                    CChartStockDataSetPropertyFloatValue(data, prop, i + location, v);
                                    if(v < minValue){
                                        minValue = v;
                                    }
                                    if(v > maxValue){
                                        maxValue = v;
                                    }
                                }
                            }
                                break;
                            default:
                                break;
                        }
                        
                        
                        prop ++;
                        c --;
                    }
                    
                    if(n == maxMa){
                        break;
                    }
                    
                    if(i - n + (int)location >=0){
                        item = CChartStockDataItemAtIndex(data, i - n + (int)location);
                        v = CChartStockDataItemPropertyFloatValue(data, valueProperty, item, CCHART_NAN);
                        if(v == CCHART_NAN){
                            break;
                        }
                        value += v;
                    }
                    else{
                        
                        prop = data->propertys;
                        c = data->propertyCount;
                        
                        while (c >0) {
                            
                            switch (prop->type) {
                                case CChartStockDataPropertyTypeValueMa:
                                {
                                    value = CChartStockDataPropertyFloatValue(data, prop, i + location, CCHART_NAN);
                                    if(value == CCHART_NAN){
                                        CChartStockDataSetPropertyFloatValue(data, prop, i + location, v);
                                        if(v < minValue){
                                            minValue = v;
                                        }
                                        if(v > maxValue){
                                            maxValue = v;
                                        }
                                    }

                                }
                                    break;
                                default:
                                    break;
                            }
                            
                            
                            prop ++;
                            c --;
                        }
                        break;
                    }
                    
                }
                
            }
        }
        
        
        maxMa = 0;
        
        while (c >0) {
            
            switch (prop->type) {
                case CChartStockDataPropertyTypeVolumeMa:
                {
                    CChartStockDataSetPropertyFloatValue(data, prop, i + location, CCHART_NAN);
                    if(prop->value >  maxMa){
                        maxMa = prop->value;
                    }
                }
                    break;
                default:
                    break;
            }
            
            
            prop ++;
            c --;
        }
        
        if(maxMa >0 && volumeProperty){
            
            value = CChartStockDataPropertyFloatValue(data, volumeProperty, i + location, CCHART_NAN);
            
            if(value != CCHART_NAN){
                
                for(n = 1;n <= maxMa;n ++){
                    
                    v = value / n ;
                    
                    prop = data->propertys;
                    c = data->propertyCount;
                    
                    while (c >0) {
                        
                        switch (prop->type) {
                            case CChartStockDataPropertyTypeVolumeMa:
                            {
                                if(prop->value == n){
                                    CChartStockDataSetPropertyFloatValue(data, prop, i + location, v);
                                    if(v < minVolume){
                                        minVolume = v;
                                    }
                                    if(v > maxVolume){
                                        maxVolume = v;
                                    }
                                }
    
                            }
                                break;
                            default:
                                break;
                        }
                        
                        
                        prop ++;
                        c --;
                    }
                    
                    if(n == maxMa){
                        break;
                    }
                    
                    if(i - n + (int)location >=0){
                        item = CChartStockDataItemAtIndex(data, i - n + (int)location);
                        v = CChartStockDataItemPropertyFloatValue(data, volumeProperty, item, CCHART_NAN);
                        if(v == CCHART_NAN){
                            break;
                        }
                        value += v;
                    }
                    else{
                        
                        prop = data->propertys;
                        c = data->propertyCount;
                        
                        while (c >0) {
                            
                            switch (prop->type) {
                                case CChartStockDataPropertyTypeVolumeMa:
                                {
                                    value = CChartStockDataPropertyFloatValue(data, prop, i + location, CCHART_NAN);
                                    if(value == CCHART_NAN){
                                        CChartStockDataSetPropertyFloatValue(data, prop, i + location, v);
                                        if(v < minVolume){
                                            minVolume = v;
                                        }
                                        if(v > maxVolume){
                                            maxVolume = v;
                                        }
                                    }
                                    
                                }
                                    break;
                                default:
                                    break;
                            }
                            
                            
                            prop ++;
                            c --;
                        }
                        break;
                    }
                    
                }
                
            }
        }
        
        if(data->minFullValue == CCHART_NAN || minValue < data->minFullValue){
            data->minFullValue = minValue;
        }
        
        if(data->maxFullValue == CCHART_NAN || maxValue > data->maxFullValue){
            data->maxFullValue = maxValue;
        }
        
        if(data->minFullVolume == CCHART_NAN || minVolume < data->minFullVolume){
            data->minFullVolume = minVolume;
        }
        
        if(data->maxFullVolume == CCHART_NAN || maxVolume > data->maxFullVolume){
            data->maxFullVolume = maxVolume;
        }
        
    }
    
    data->valueAdjust = CChartStockAdjust(data->minFullValue, data->maxFullValue, 2, 0);
    data->volumeAdjust = CChartStockAdjust(0, data->maxFullVolume, 0, 1);
    
    

}

CChartFloat CChartStockDataXValue(CChartStockData * const data,CChartInteger index){
    return (index + 0.4) / data->length;
}

CChartFloat CChartStockDataYValue(CChartStockData * const data,CChartFloat value){
    return (value - data->valueAdjust.min) / (data->valueAdjust.max - data->valueAdjust.min);
}

CChartFloat CChartStockDataYVolume(CChartStockData * const data,CChartFloat volume){
    return (volume - data->volumeAdjust.min) / (data->volumeAdjust.max - data->volumeAdjust.min) ;
}


typedef struct {
    unsigned int version;
    unsigned int classSize;
    unsigned int size;
} CChartStockDataHead;

CChartBoolean CChartStockDataLoadFile(CChartStockData * const data,CChartString filePath){
    
    CChartStockDataHead head;
    FILE * fno;
    CChartStockDataProperty * propertys;
    int c;
    
    fno = fopen(filePath, "r");
    
    if(fno == NULL){
        return 0;
    }
    
    if(sizeof(CChartStockDataHead) != fread(&head, 1, sizeof(CChartStockDataHead), fno)){
        fclose(fno);
        return 0;
    }
    
    if(head.version != CCHART_STOCK_DATA_VERSION){
        fclose(fno);
        return 0;
    }
    
    propertys = (CChartStockDataProperty *) malloc(head.classSize);
    
    if(head.classSize != fread(propertys, 1, head.classSize, fno)){
        free(propertys);
        fclose(fno);
        return 0;
    }
    
    if(data->propertys){
        free(data->propertys);
    }
    
    data->propertys = propertys;
    data->propertyCount = head.classSize / sizeof(CChartStockDataProperty);
    data->itemSize = 0;

    c = data->propertyCount;
    
    while(c >0){
        
        data->itemSize += propertys->size;
        
        c --;
        propertys ++;
    }
    
    
    CChartStockDataSetDataSize(data, head.size);
    
    if(head.size * data->itemSize != fread(data->data, 1, head.size * data->itemSize, fno)){
        fclose(fno);
        return 0;
    }
    
    fclose(fno);
    
    return 1;
}

CChartBoolean CChartStockDataSaveFile(CChartStockData * const data,CChartString filePath){
    
    if(data && data->itemSize >0){
        
        CChartStockDataHead head = {CCHART_STOCK_DATA_VERSION,data->propertyCount * sizeof(CChartStockDataProperty),data->size};
        
        FILE * fno = fopen(filePath, "w");
        
        if(fno == NULL){
            fclose(fno);
            return 0;
        }
        
        if(sizeof(CChartStockDataHead) != fwrite(&head, 1, sizeof(CChartStockDataHead), fno)){
            fclose(fno);
            return 0;
        }
        
        if(sizeof(CChartStockDataProperty) * data->propertyCount
           != fwrite(data->propertys, 1, sizeof(CChartStockDataProperty) * data->propertyCount, fno)){
            fclose(fno);
            return 0;
        }
        
        if(data->size >0){
            if(data->size * data->itemSize
               != fwrite(data->data, 1, data->size * data->itemSize, fno)){
                fclose(fno);
                return 0;
            }
        }
        
        fclose(fno);
        
        return 1;
    }
    
    return 0;
    
}

CChartBoolean CChartStockDataFileValidate(CChartString filePath){
    
    CChartStockDataHead head;
    FILE * fno;
    
    fno = fopen(filePath, "r");
    
    if(fno == NULL){
        return 0;
    }
    
    if(sizeof(CChartStockDataHead) != fread(&head, 1, sizeof(CChartStockDataHead), fno)){
        fclose(fno);
        return 0;
    }
    
    if(head.version != CCHART_STOCK_DATA_VERSION){
        fclose(fno);
        return 0;
    }

    fclose(fno);
    
    return 1;
}

