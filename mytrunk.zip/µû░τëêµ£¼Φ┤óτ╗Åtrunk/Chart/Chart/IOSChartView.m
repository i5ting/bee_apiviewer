//
//  IOSChartView.m
//  IOSChart
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartView.h"

#import "IOSChartLayer.h"

#define FRAME_SPEED (1.0 / 60.0)

@interface IOSChartViewContentLayer : CALayer

@property(nonatomic,retain) id contentValue;

@end

@implementation IOSChartViewContentLayer

@synthesize contentValue = _contentValue;

-(void) dealloc{
    [_contentValue release];
    [super dealloc];
}

-(void) setContentValue:(id)contentValue{
    if(_contentValue != contentValue){
        [contentValue retain];
        [_contentValue release];
        _contentValue = contentValue;
        if([self.delegate respondsToSelector:@selector(setContentValue:)]){
            [self.delegate setContentValue:contentValue];
        }
    }

}

+ (BOOL)needsDisplayForKey:(NSString *)key{
    if([key isEqualToString:@"contentValue"]){
        return YES;
    }
    return [super needsDisplayForKey:key];
}

@end

@interface IOSChartView(){
    IOSChartLayer * _chartLayer;
    
    struct {
        CGPoint location;
        CGPoint preLocaiton;
        CGPoint dp;
        CGPoint speed;
        NSUInteger length;
        NSTimeInterval preTimestamp;
    } panAction;
}

-(void) setContentValue:(id) value;

@property(nonatomic,retain) CADisplayLink * displayLink;

@end

@implementation IOSChartView

@synthesize displayLink = _displayLink;

+(Class) layerClass{
    return [IOSChartViewContentLayer class];
}

-(void) resizeC3DLayer{
    
    if(_chartLayer){
        CGSize size = self.bounds.size;
        UIScreen * screen = [UIScreen mainScreen];
        
        float scale = 1.0;
        if([screen respondsToSelector:@selector(scale)]){
            scale = [screen scale];
        }
        
        scale *= 1.5;
        
        CGSize s = CGSizeMake(size.width * scale, size.height * scale);
        scale = 1.0 / scale;
        _chartLayer.frame = CGRectMake((size.width - s.width) / 2.0, (size.height - s.height) / 2.0, s.width, s.height);
        _chartLayer.scale = scale;
    }
}


-(void) initChartLayer{
    _chartLayer = [[IOSChartLayer alloc] init];
    _chartLayer.backgroundColor = self.layer.backgroundColor;
    [self.layer addSublayer:_chartLayer];
    [self resizeC3DLayer];
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick)];
    [_displayLink setFrameInterval:FRAME_SPEED];
    
    UIPanGestureRecognizer * panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panAction:)];
    
    [self addGestureRecognizer:panGestureRecognizer];
    
    [panGestureRecognizer release];
    
    UILongPressGestureRecognizer * longPressGestureRecognizer =[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    
    [longPressGestureRecognizer setMinimumPressDuration:0.3];
    
    [self addGestureRecognizer:longPressGestureRecognizer];
    
    [longPressGestureRecognizer release];
    
    UIPinchGestureRecognizer * pinchGestureRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchAction:)];
    
    [self addGestureRecognizer:pinchGestureRecognizer];
    
    [pinchGestureRecognizer release];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initChartLayer];
    }
    return self;
}

-(id) initWithCoder:(NSCoder *)aDecoder{
    if((self = [super initWithCoder:aDecoder])){
        [self initChartLayer];
    }
    return self;
}

-(void) setFrame:(CGRect)frame{
    [super setFrame:frame];
    [self resizeC3DLayer];
}

-(void) dealloc{
    [_displayLink invalidate];
    [_displayLink removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [_displayLink release];
    [[_chartLayer chart] setDelegate:nil];
    [_chartLayer release];
    [super dealloc];
}

-(IOSChart *) chart{
    return [_chartLayer chart];
}

-(void) setChart:(IOSChart *)chart{
    [[_chartLayer chart] setDelegate:nil];
    [_chartLayer setChart:chart];
    [chart setDelegate:self];
}

-(void) setNeedsRender{
    [_chartLayer setNeedsRender];
}

-(void) tick{
    [_chartLayer tick];
}

-(void) willMoveToWindow:(UIWindow *)newWindow{
    [super willMoveToWindow:newWindow];
    if(newWindow){
        [_displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        [self tick];
    }
    else{
        [_displayLink removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    }
}

-(void) setBackgroundColor:(UIColor *)backgroundColor{
    [super setBackgroundColor:backgroundColor];
    [_chartLayer setBackgroundColor:backgroundColor.CGColor];
}

-(void) panAction:(UIPanGestureRecognizer *) gestureRecognizer{
    if(gestureRecognizer.state == UIGestureRecognizerStateBegan){
        
        [self.layer removeAnimationForKey:@"contentValue"];
        
        panAction.location = [gestureRecognizer locationInView:self];
        panAction.preLocaiton = panAction.location;
        panAction.preTimestamp = CFAbsoluteTimeGetCurrent();
        panAction.speed  = CGPointZero;
        panAction.length = 0;
        panAction.dp = CGPointZero;
        
        [[_chartLayer chart] scrollBegin];
    }
    else if(gestureRecognizer.state == UIGestureRecognizerStateChanged){
        CGSize size = self.bounds.size;
        CGPoint p = [gestureRecognizer locationInView:self];
        [[_chartLayer chart] scrollValueChanged:CGPointMake((p.x - panAction.location.x) / size.width,(p.y - panAction.location.y) / size.height)];
        
        CGPoint dp = CGPointMake(p.x - panAction.preLocaiton.x,p.y - panAction.preLocaiton.y);
        CGFloat dt = CFAbsoluteTimeGetCurrent() - panAction.preTimestamp;
        
        if(panAction.dp.x * dp.x <0.0f ){
            panAction.speed.x = 0.0f;
            panAction.speed.y = 0.0f;
            panAction.length = 0;
        }
        panAction.speed.x += dp.x / dt;
        panAction.speed.y += dp.y / dt;
        panAction.length ++;
        
        panAction.dp = dp;
        panAction.preLocaiton = p;
        panAction.preTimestamp =  CFAbsoluteTimeGetCurrent();
    }
    else{
        
        CGFloat dt = CFAbsoluteTimeGetCurrent() - panAction.preTimestamp;
        
        if((fabsf(panAction.speed.x) > 0.0 || fabsf(panAction.speed.y) > 0.0) && panAction.length >0 && dt < 0.01){
            
            CGPoint p = [gestureRecognizer locationInView:self];

            CGPoint speed = CGPointMake(panAction.speed.x / panAction.length, panAction.speed.y / panAction.length);
            
            CGFloat t = 1.2;
            
            speed = CGPointMake(speed.x * t, speed.y * t);
            
            CABasicAnimation * anim = [CABasicAnimation animationWithKeyPath:@"contentValue"];
            [anim setDuration:t];
            [anim setFromValue:[NSValue valueWithCGPoint:p]];
            [anim setToValue:[NSValue valueWithCGPoint:CGPointMake(p.x + speed.x
                                                                   , p.y + speed.y )]];
            [anim setRemovedOnCompletion:YES];
            [anim setDelegate:self];
            [anim setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut]];
            [self.layer addAnimation:anim forKey:@"contentValue"];
        }
        else{
            [[_chartLayer chart] scrollEnd];
        }
    }
}

-(void) longPressAction:(UIPanGestureRecognizer *) gestureRecognizer{
    if(gestureRecognizer.state == UIGestureRecognizerStateBegan){
        CGSize size = self.bounds.size;
        CGPoint p = [gestureRecognizer locationInView:self];
        [[_chartLayer chart] focusBegin:CGPointMake(p.x / size.width, 1.0 - p.y / size.height)];
    }
    else if(gestureRecognizer.state == UIGestureRecognizerStateChanged){
        CGSize size = self.bounds.size;
        CGPoint p = [gestureRecognizer locationInView:self];
        [[_chartLayer chart] focusValueChanged:CGPointMake(p.x / size.width, 1.0 - p.y / size.height)];
    }
    else{
        [[_chartLayer chart] focusEnd];
    }
}

-(void) pinchAction:(UIPinchGestureRecognizer *) gestureRecognizer{
    if(gestureRecognizer.state == UIGestureRecognizerStateBegan){
        [[_chartLayer chart] scaleBegin];
    }
    else if(gestureRecognizer.state == UIGestureRecognizerStateChanged){
        [[_chartLayer chart] scaleValueChanged: gestureRecognizer.scale];
    }
    else{
        [[_chartLayer chart] scaleEnd];
    }
}

-(void) IOSChartSetNeedRender:(IOSChart *) chart{
    [self setNeedsRender];
}

-(void) setContentValue:(id) value{
    CGSize size = self.bounds.size;
    CGPoint p = [value CGPointValue];
    [[_chartLayer chart] scrollValueChanged:CGPointMake((p.x - panAction.location.x) / size.width,(p.y - panAction.location.y) / size.height)];    
}

-(void) animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    if(flag){
        [[_chartLayer chart] scrollEnd];
    }
}

@end
