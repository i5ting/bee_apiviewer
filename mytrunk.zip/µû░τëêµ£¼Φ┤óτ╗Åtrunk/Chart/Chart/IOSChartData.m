//
//  IOSChartData.m
//
//  Created by zhang hailong on 13-5-7.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#import "IOSChartData.h"

#include <Chart/CChartData.h>

@implementation NSObject(IOSChartData)

-(id) dataObjectForKey:(NSString *) key{
    if([self isKindOfClass:[NSArray class]]){
        if([key isEqualToString:@"length"]){
            return [NSNumber numberWithInt:[(NSArray *)self count]];
        }
        if([key hasPrefix:@"@"]){
            int i = [[key substringFromIndex:1] intValue];
            if(i >=0 && i < [(NSArray *)self count]){
                return [(NSArray *)self objectAtIndex:i];
            }
            return nil;
        }
    }
    else if([self isKindOfClass:[NSDictionary class]]){
        if([key isEqualToString:@"length"]){
            return [NSNumber numberWithInt:[(NSDictionary *)self count]];
        }
        if([key hasPrefix:@"@"]){
            [self valueForKey:[key substringFromIndex:1]];
        }
    }
    return [self valueForKey:key];
}


-(id) dataObjectForKeyPath:(NSString *) keyPath{
    const char * cKeyPath = [keyPath UTF8String];
    char * p = (char *) cKeyPath ;
    
    while(p){
        
        if(*p == '.'){
            break;
        }
        
        if(*p == '\0'){
            break;
        }
        p ++;
    }
    
    if(*p == '.'){
        id v = [self dataObjectForKey:[keyPath substringToIndex:p - cKeyPath]];
        return CChartDataObjectValueForKeyPath(v, p +1);
    }
    else{
        return [self dataObjectForKey:keyPath];
    }
}

@end

CChartFloat CChartDataObjectFloatValue(CChartDataObject object,CChartFloat defaultValue){
    id v = (id) object;
    
    if(v == nil){
        return defaultValue;
    }
    
    if([v isKindOfClass:[NSNull class]]){
        return 0.0f;
    }
    return [v floatValue];
}

CChartUInteger CChartDataObjectUIntegerValue(CChartDataObject object,CChartUInteger defaultValue){
    id v = (id) object;
    if(v == nil){
        return defaultValue;
    }
    if([v isKindOfClass:[NSNull class]]){
        return 0;
    }
    return [v intValue];
}

CChartString CChartDataObjectStringValue(CChartDataObject object,CChartString defaultValue){
    id v = (id) object;
    if(v == nil){
        return defaultValue;
    }
    if([v isKindOfClass:[NSString class]]){
        return [v UTF8String];
    }
    else if(v){
        return [[NSString stringWithFormat:@"%@",v] UTF8String];
    }
    return NULL;
}

CChartDouble CChartDataObjectDoubleValue(CChartDataObject object,CChartDouble defaultValue){
    id v = (id) object;
    if(v == nil){
        return defaultValue;
    }
    if([v isKindOfClass:[NSNull class]]){
        return 0;
    }
    return [v doubleValue];
}

CChartInt64 CChartDataObjectInt64Value(CChartDataObject object,CChartInt64 defaultValue){
    id v = (id) object;
    if(v == nil){
        return defaultValue;
    }
    if([v isKindOfClass:[NSNull class]]){
        return 0;
    }
    return [v longLongValue];
}

CChartDataObject CChartDataObjectValueAtIndex(CChartDataObject object,CChartUInteger index){
    id v = (id) object;
    if([v isKindOfClass:[NSArray class]]){
        if(index < [v count]){
            return [v objectAtIndex:index];
        }
    }
    else if([v isKindOfClass:[NSDictionary class]]){
        return [v valueForKey:[NSString stringWithFormat:@"%d",index]];
    }
    return nil;
}

CChartDataObject CChartDataObjectValueForKeyPath(CChartDataObject object,CChartString keyPath){
    if(object && keyPath){
        
        return [(id)object dataObjectForKeyPath:[NSString stringWithCString:keyPath encoding:NSUTF8StringEncoding]];
    }
    return nil;
}

void CChartDataObjectPoolBegin(){
    
}


void CChartDataObjectPoolEnd(){
    
}
