//
//  ArticleDeclareView.h
//  SinaNews
//
//  Created by fabo on 12-10-18.
//
//

#import <UIKit/UIKit.h>

@interface DeclareView : UIView
@property(nonatomic,retain)NSString* declareString;
@property(nonatomic,assign)CGRect stringBounds;
@property(nonatomic,retain)UIFont* font;
@property(nonatomic,retain)UIColor* fontColor;
@property(nonatomic,assign)NSInteger margin;
@property(nonatomic,assign)UITextAlignment textAlignment;

-(void)setString:(NSString*)string stringRect:(CGRect)bound margin:(NSInteger)amargin font:(UIFont*)afont fontColor:(UIColor*)acolor textAlignment:(UITextAlignment)alignment;
@end
