//
//  CChart.c
//  CChart
//
//  Created by zhang hailong on 13-5-6.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#include "CChart.h"

CChartBoolean CChartTrue = 1;
CChartBoolean CChartFalse = 0;

CChartDateTime CChartDateTimeEmpty = {{0,0,0},{0,0,0}};

CChartBoolean CChartDateTimeEqual(CChartDateTime datetime1,CChartDateTime datetime2,CChartDateTimeUnit unit){
    if((CChartDateTimeUnitYear & unit) && datetime1.date.year != datetime2.date.year){
        return CChartFalse;
    }
    if((CChartDateTimeUnitMonth & unit) && datetime1.date.month != datetime2.date.month){
        return CChartFalse;
    }
    if((CChartDateTimeUnitDay & unit) && datetime1.date.day != datetime2.date.day){
        return CChartFalse;
    }
    if((CChartDateTimeUnitHour & unit) && datetime1.time.hour != datetime2.time.hour){
        return CChartFalse;
    }
    if((CChartDateTimeUnitMinute & unit) && datetime1.time.minute != datetime2.time.minute){
        return CChartFalse;
    }
    if((CChartDateTimeUnitSecond & unit) && datetime1.time.second != datetime2.time.second){
        return CChartFalse;
    }
    return CChartTrue;
}

CChartBoolean CChartDateTimeIsEmpty(CChartDateTime datetime){
    return datetime.date.year == 0 && datetime.date.month ==0 && datetime.date.day ==0
        && datetime.time.hour == 0 && datetime.time.minute ==0 && datetime.time.second ==0;
}

CChartInteger CChartDataTimeCompare(CChartDateTime datetime1,CChartDateTime datetime2,CChartDateTimeUnit unit){
    if((CChartDateTimeUnitYear & unit) && datetime1.date.year != datetime2.date.year){
        return (CChartInteger)datetime1.date.year - (CChartInteger)datetime2.date.year;
    }
    if((CChartDateTimeUnitMonth & unit) && datetime1.date.month != datetime2.date.month){
        return (CChartInteger)datetime1.date.month - (CChartInteger)datetime2.date.month;
    }
    if((CChartDateTimeUnitDay & unit) && datetime1.date.day != datetime2.date.day){
        return (CChartInteger)datetime1.date.day - (CChartInteger)datetime2.date.day;
    }
    if((CChartDateTimeUnitHour & unit) && datetime1.time.hour != datetime2.time.hour){
        return (CChartInteger)datetime1.time.hour - (CChartInteger)datetime2.time.hour;
    }
    if((CChartDateTimeUnitMinute & unit) && datetime1.time.minute != datetime2.time.minute){
        return (CChartInteger)datetime1.time.minute - (CChartInteger)datetime2.time.minute;
    }
    if((CChartDateTimeUnitSecond & unit) && datetime1.time.second != datetime2.time.second){
        return (CChartInteger)datetime1.time.second - (CChartInteger)datetime2.time.second;
    }
    return CChartTrue;
}


CChartPoint CChartPointMake(CChartFloat x,CChartFloat y){
    CChartPoint p = {x,y};
    return p;
}

CChartSize CChartSizeMake(CChartFloat width,CChartFloat height){
    CChartSize p = {width,height};
    return p;
}

CChartRect CChartRectMake(CChartFloat x,CChartFloat y,CChartFloat width,CChartFloat height){
    CChartRect r = {{x,y},{width,height}};
    return r;
}

static CChartFloat CChartRectMakeRelativeValue(CChartFloat v ,CChartFloat ofValue,CChartFloat defaultValue){
    if(v < 0.0f){
        return defaultValue;
    }
    else if(v < 1.0f){
        return ofValue * v;
    }
    return v;
}

CChartRect CChartRectMakeRelative(CChartRect frame,CChartRelativeRect rect){
    
    CChartFloat w = CChartRectMakeRelativeValue(rect.size.width,frame.size.width,-1.0f);
    CChartFloat h = CChartRectMakeRelativeValue(rect.size.height,frame.size.height,-1.0f);
    CChartFloat l,r,t,b;
    CChartFloat x = 0;
    CChartFloat y = 0;

    
    if(w == -1){
        l = CChartRectMakeRelativeValue(rect.inset.left,frame.size.width,0.0f);
        r = CChartRectMakeRelativeValue(rect.inset.right,frame.size.width,0.0f);
        w = frame.size.width - l - r;
        x = l;
    }
    else{
        l = CChartRectMakeRelativeValue(rect.inset.left,frame.size.width,-1.0f);
        r = CChartRectMakeRelativeValue(rect.inset.right,frame.size.width,-1.0f);
        if(l == -1.0f){
            if(r == -1.0f){
                x = (frame.size.width - w) / 2.0;
            }
            else{
                x = frame.size.width - r;
            }
        }
        else {
            x = l;
        }
    }
    
    if(h == -1){
        
        t = CChartRectMakeRelativeValue(rect.inset.top,frame.size.height,0.0f);
        b = CChartRectMakeRelativeValue(rect.inset.bottom,frame.size.height,0.0f);
        h = frame.size.height - t - b;
        y = t;
    }
    else{
        t = CChartRectMakeRelativeValue(rect.inset.top,frame.size.height,-1.0f);
        b = CChartRectMakeRelativeValue(rect.inset.bottom,frame.size.height,-1.0f);
        
        if(t == -1.0f){
            if(b == -1.0f){
                y = (frame.size.height - h) / 2.0;
            }
            else{
                y = frame.size.height - b;
            }
        }
        else {
            y = t;
        }
    }
    
    return CChartRectMake(frame.origin.x + x, frame.origin.y + frame.size.height - h - y, w, h);
    
}

CChartBoolean CChartRectEqual(CChartRect rect1,CChartRect rect2){
    return rect1.origin.x == rect2.origin.x && rect1.origin.y == rect2.origin.y && rect1.size.width == rect2.size.width && rect1.size.height == rect2.size.height;
}

CChartFloat CChartContextRelativeOfWidth(CChartContext * context,CChartFloat value){
    return value / context->scale / context->viewport.width;
}

CChartFloat CChartContextRelativeOfHeight(CChartContext * context,CChartFloat value){
    return value / context->scale / context->viewport.height;
}

CChartPoint CChartContextRelativePoint(CChartContext * context,CChartPoint value){
    CChartPoint p = {value.x / context->scale / context->viewport.width
        ,value.y / context->scale / context->viewport.height};
    return p;
}

CChartSize CChartContextRelativeSize(CChartContext * context,CChartSize value){
    CChartSize s = {value.width / context->scale / context->viewport.width
        ,value.height / context->scale / context->viewport.height};
    return s;
}

CChartFloat CChartContextAbsoluteOfWidth(CChartContext * context,CChartFloat value){
    return context->viewport.width * context->scale * value;
}

CChartFloat CChartContextAbsoluteOfHeight(CChartContext * context,CChartFloat value){
    return context->viewport.height * context->scale * value;
}

CChartPoint CChartContextAbsolutePoint(CChartContext * context,CChartPoint value){
    CChartPoint p = {value.x * context->scale * context->viewport.width
        ,value.y * context->scale * context->viewport.height};
    return p;
}

void CChartFloatToString(CChartFloat value,char * text){
    int iv = roundf( value);
    if((int) roundf(value * 100) == iv * 100){
        sprintf(text, "%d",iv);
    }
    else{
        sprintf(text, "%.2f",value);
    }
}

static char CChartDateTimeToStringWeeks[][8] = {
    "周日",
    "周一",
    "周二",
    "周三",
    "周四",
    "周五",
    "周六"
};

void CChartDateTimeToString(CChartDateTime datetime,CChartDateTimeUnit unit, char * text){
    if(unit & CChartDateTimeUnitYear){
        if(unit & CChartDateTimeUnitSecond){
            sprintf(text, "%04u/%02u/%02u %02u:%02u:%02u",datetime.date.year,datetime.date.month,datetime.date.day,datetime.time.hour,datetime.time.minute,datetime.time.second);
        }
        else if(unit & CChartDateTimeUnitHour){
            sprintf(text, "%04u/%02u/%02u %02u:%02u",datetime.date.year,datetime.date.month,datetime.date.day,datetime.time.hour,datetime.time.minute);
        }
        else if(unit & CChartDateTimeUnitWeek){
            sprintf(text, "%04u/%02u/%02u %s",datetime.date.year,datetime.date.month,datetime.date.day,CChartDateTimeToStringWeeks[ (datetime.date.week -1) % 7]);
        }
        else if(unit & CChartDateTimeUnitDay){
            sprintf(text, "%04u/%02u/%02u",datetime.date.year,datetime.date.month,datetime.date.day);
        }
        else if(unit & CChartDateTimeUnitMonth){
            sprintf(text, "%04u/%02u",datetime.date.year,datetime.date.month);
        }
        else{
            sprintf(text, "%04u",datetime.date.year);
        }
    }
    else if(unit & CChartDateTimeUnitMonth){
        if(unit & CChartDateTimeUnitHour){
            sprintf(text, "%02u/%02u %02u:%02u",datetime.date.month,datetime.date.day,datetime.time.hour,datetime.time.minute);
        }
        else if(unit & CChartDateTimeUnitSecond){
            sprintf(text, "%02u/%02u %02u:%02u:%02u",datetime.date.month,datetime.date.day,datetime.time.hour,datetime.time.minute,datetime.time.second);
        }
        else{
            sprintf(text, "%02u/%02u",datetime.date.month,datetime.date.day);
        }
    }
    else if(unit & CChartDateTimeUnitHour){
        sprintf(text, "%02u:%02u",datetime.time.hour,datetime.time.minute);
    }
    else if(unit & CChartDateTimeUnitSecond){
        sprintf(text, "%02u:%02u:%02u",datetime.time.hour,datetime.time.minute,datetime.time.second);
    }
    else if(datetime.date.year){
        sprintf(text, "%04u/%02u/%02u",datetime.date.year, datetime.date.month,datetime.date.day);
    }
    else if(datetime.date.month){
        sprintf(text, "%02u/%02u",datetime.date.month,datetime.date.day);
    }
    else {
        sprintf(text, "%02u:%02u",datetime.time.hour,datetime.time.minute);
    }
}

void CChartContextDraw(CChartContext * context,CChart * chart,CChartRect rect){
	if(context && chart && chart->clazz){
		(*chart->clazz->draw)(context,chart,rect);
	}
}

void CChartContextCleanup(CChartContext * context){
    if(context->buffer.data){
        free(context->buffer.data);
        context->buffer.data = NULL;
        context->buffer.length = 0;
    }
}

void CChartContextSetBufferLength(CChartContext * context,CChartUInteger length){
    if(context->buffer.length < length){
        if(context->buffer.data){
            context->buffer.data = realloc(context->buffer.data, length);
        }
        else{
            context->buffer.data = malloc(length);
        }
        context->buffer.length = length;
    }
}

CChartTime CChartTimeAdd(CChartTime time,CChartTime add){
    CChartTime t = {time.hour + add.hour,time.minute + add.minute,time.second + add.second};
    t.minute += t.second / 60;
    t.second = t.second % 60;
    t.hour += t.minute / 60;
    t.minute = t.minute % 60;
    t.hour = t.hour % 24;
    return t;
}

CChartBoolean CChartTimeEqual(CChartTime time1,CChartTime time2){
    return time1.hour == time2.hour && time1.minute == time2.minute && time1.second == time2.second;
}
