//
//  CChartStock.h
//  Chart
//
//  Created by zhang hailong on 13-5-15.
//  Copyright (c) 2013年 hailong.org. All rights reserved.
//

#ifndef Chart_CChartStock_h
#define Chart_CChartStock_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include <Chart/CChart.h>
#include <Chart/CChartStockData.h>
#include <Chart/CChartStyle.h>
    
    
    
    struct _CChartStockStylePropertys{
        CChartStyleProperty forms;
        CChartStyleProperty rect;
        CChartStyleProperty backgroundColor;
        CChartStyleProperty borderColor;
        CChartStyleProperty borderWidth;
        CChartStyleProperty lineWidth;
        CChartStyleProperty focusColor;
        CChartStyleProperty focusLabelColor;
        CChartStyleProperty labelColor;
        CChartStyleProperty fillColor;
        CChartStyleProperty fontSize;
        struct {
            CChartStyleProperty value;
            CChartStyleProperty volume;
            CChartStyleProperty openValue;
            CChartStyleProperty lowValue;
            CChartStyleProperty highValue;
            CChartStyleProperty avgValue;
            CChartStyleProperty timestamp;
        } dataKeys;
    } ;
    
    
    struct _CChartStockFormStylePropertys{
        CChartStyleProperty drawFun;
        CChartStyleProperty rect;
        CChartStyleProperty backgroundColor;
        CChartStyleProperty borderColor;
        CChartStyleProperty borderWidth;
        CChartStyleProperty gridColor;
        CChartStyleProperty gridWidth;
        CChartStyleProperty fontSize;
        CChartStyleProperty curColor;
        CChartStyleProperty fallColor;
        CChartStyleProperty riseColor;
        CChartStyleProperty labelColor;
        CChartStyleProperty lineWidth;
        CChartStyleProperty focusColor;
        CChartStyleProperty focusLabelColor;
        CChartStyleProperty columnType;
        CChartStyleProperty lineColor1;
        CChartStyleProperty lineColor2;
        CChartStyleProperty lineColor3;
        CChartStyleProperty lineColor4;
        CChartStyleProperty lineColor5;
    } ;
    
    
    extern struct _CChartStockStylePropertys CChartStockStylePropertys;
    
    extern struct _CChartStockFormStylePropertys CChartStockFormStylePropertys;
    
    extern struct _CChartStockFormItemStylePropertys CChartStockFormItemStylePropertys;
    
    extern CChartStyleClass CChartStockStyleClass;
    
    extern CChartStyleClass CChartStockFormStyleClass;
    
    void CChartStockClassInitialize();

    
    typedef struct _CChartStockLayer {
        CChart base;
        CChartStyle * style;
        CChartUInteger styleIndex;
        CChartStockData * data;
        CChartPoint focusLocation;
        struct {
            CChartStockDataProperty * value;
            CChartStockDataProperty * volume;
            CChartStockDataProperty * openValue;
            CChartStockDataProperty * lowValue;
            CChartStockDataProperty * highValue;
            CChartStockDataProperty * avgValue;
            CChartStockDataProperty * timestamp;
        } dataPropertys;
    } CChartStockLayer;
    
    typedef CChartStockLayer CChartStock;
    
    void CChartStockDataBind(CChartStock * const stock,CChartStyle * style,CChartStockData * data);
    
    extern CChartClass CChartStockClass;
    
    void CChartStockVolumeFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect);
    
    void CChartStockKLineFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect);

    void CChartStockRealTimeFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect);
    
    void CChartStockYearLineFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect);
    
    void CChartStockDay5LineFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect);
    
    void CChartStockFormColumnsDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect,CChartBoolean hasLabel);
    
    void CChartStockMALabelFormLayerDraw(struct _CChartContext * context,CChartStockLayer * chart,CChartRect rect);
    
#ifdef __cplusplus
}
#endif


#endif
